﻿namespace TuProductoOnline
{
    partial class AddClients
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddClients));
            this.btnAddCliente = new System.Windows.Forms.Button();
            this.txtIDClient = new System.Windows.Forms.TextBox();
            this.lblCédula = new System.Windows.Forms.Label();
            this.txtPhoneClient = new System.Windows.Forms.TextBox();
            this.lblDirección = new System.Windows.Forms.Label();
            this.txtAdressClient = new System.Windows.Forms.TextBox();
            this.lblPhone = new System.Windows.Forms.Label();
            this.txtSurnameClient = new System.Windows.Forms.TextBox();
            this.lblApellido = new System.Windows.Forms.Label();
            this.txtNameClient = new System.Windows.Forms.TextBox();
            this.lblNombre = new System.Windows.Forms.Label();
            this.ErrorProviderAddClient = new System.Windows.Forms.ErrorProvider(this.components);
            this.ErrorProviderAddClient1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.ErrorProviderAddClient2 = new System.Windows.Forms.ErrorProvider(this.components);
            this.ErrorProviderAddClient3 = new System.Windows.Forms.ErrorProvider(this.components);
            this.pnlTopBorder = new System.Windows.Forms.Panel();
            this.btnCancel = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.ErrorProviderAddClient)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErrorProviderAddClient1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErrorProviderAddClient2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErrorProviderAddClient3)).BeginInit();
            this.SuspendLayout();
            // 
            // btnAddCliente
            // 
            this.btnAddCliente.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.btnAddCliente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.btnAddCliente.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.btnAddCliente.Location = new System.Drawing.Point(290, 154);
            this.btnAddCliente.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnAddCliente.Name = "btnAddCliente";
            this.btnAddCliente.Size = new System.Drawing.Size(99, 31);
            this.btnAddCliente.TabIndex = 6;
            this.btnAddCliente.Text = "Registrar";
            this.btnAddCliente.UseVisualStyleBackColor = false;
            this.btnAddCliente.Click += new System.EventHandler(this.btnAddClient_Click);
            // 
            // txtIDClient
            // 
            this.txtIDClient.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtIDClient.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtIDClient.ForeColor = System.Drawing.Color.White;
            this.txtIDClient.Location = new System.Drawing.Point(36, 157);
            this.txtIDClient.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtIDClient.MaxLength = 9;
            this.txtIDClient.Name = "txtIDClient";
            this.txtIDClient.Size = new System.Drawing.Size(162, 26);
            this.txtIDClient.TabIndex = 5;
            this.txtIDClient.TextChanged += new System.EventHandler(this.txtIDClient_TextChanged);
            // 
            // lblCédula
            // 
            this.lblCédula.AutoSize = true;
            this.lblCédula.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.lblCédula.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblCédula.Location = new System.Drawing.Point(87, 136);
            this.lblCédula.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCédula.Name = "lblCédula";
            this.lblCédula.Size = new System.Drawing.Size(52, 15);
            this.lblCédula.TabIndex = 40;
            this.lblCédula.Text = "Cédula";
            // 
            // txtPhoneClient
            // 
            this.txtPhoneClient.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtPhoneClient.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPhoneClient.ForeColor = System.Drawing.Color.White;
            this.txtPhoneClient.Location = new System.Drawing.Point(227, 47);
            this.txtPhoneClient.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtPhoneClient.MaxLength = 11;
            this.txtPhoneClient.Name = "txtPhoneClient";
            this.txtPhoneClient.Size = new System.Drawing.Size(162, 26);
            this.txtPhoneClient.TabIndex = 3;
            this.txtPhoneClient.TextChanged += new System.EventHandler(this.txtPhoneClient_TextChanged);
            // 
            // lblDirección
            // 
            this.lblDirección.AutoSize = true;
            this.lblDirección.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.lblDirección.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblDirección.Location = new System.Drawing.Point(268, 80);
            this.lblDirección.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDirección.Name = "lblDirección";
            this.lblDirección.Size = new System.Drawing.Size(68, 15);
            this.lblDirección.TabIndex = 38;
            this.lblDirección.Text = "Dirección";
            // 
            // txtAdressClient
            // 
            this.txtAdressClient.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtAdressClient.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAdressClient.ForeColor = System.Drawing.Color.White;
            this.txtAdressClient.Location = new System.Drawing.Point(227, 100);
            this.txtAdressClient.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtAdressClient.Name = "txtAdressClient";
            this.txtAdressClient.Size = new System.Drawing.Size(162, 26);
            this.txtAdressClient.TabIndex = 4;
            this.txtAdressClient.TextChanged += new System.EventHandler(this.txtAdressClient_TextChanged);
            // 
            // lblPhone
            // 
            this.lblPhone.AutoSize = true;
            this.lblPhone.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.lblPhone.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblPhone.Location = new System.Drawing.Point(271, 27);
            this.lblPhone.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Size = new System.Drawing.Size(63, 15);
            this.lblPhone.TabIndex = 36;
            this.lblPhone.Text = "Teléfono";
            // 
            // txtSurnameClient
            // 
            this.txtSurnameClient.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtSurnameClient.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSurnameClient.ForeColor = System.Drawing.Color.White;
            this.txtSurnameClient.Location = new System.Drawing.Point(36, 100);
            this.txtSurnameClient.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtSurnameClient.Name = "txtSurnameClient";
            this.txtSurnameClient.Size = new System.Drawing.Size(159, 26);
            this.txtSurnameClient.TabIndex = 2;
            this.txtSurnameClient.TextChanged += new System.EventHandler(this.txtSurnameClient_TextChanged);
            // 
            // lblApellido
            // 
            this.lblApellido.AutoSize = true;
            this.lblApellido.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.lblApellido.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblApellido.Location = new System.Drawing.Point(86, 79);
            this.lblApellido.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblApellido.Name = "lblApellido";
            this.lblApellido.Size = new System.Drawing.Size(59, 15);
            this.lblApellido.TabIndex = 34;
            this.lblApellido.Text = "Apellido";
            // 
            // txtNameClient
            // 
            this.txtNameClient.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtNameClient.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtNameClient.ForeColor = System.Drawing.Color.White;
            this.txtNameClient.Location = new System.Drawing.Point(36, 47);
            this.txtNameClient.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtNameClient.Name = "txtNameClient";
            this.txtNameClient.Size = new System.Drawing.Size(159, 26);
            this.txtNameClient.TabIndex = 1;
            this.txtNameClient.TextChanged += new System.EventHandler(this.txtNameClient_TextChanged);
            // 
            // lblNombre
            // 
            this.lblNombre.AutoSize = true;
            this.lblNombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.lblNombre.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblNombre.Location = new System.Drawing.Point(87, 26);
            this.lblNombre.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(58, 15);
            this.lblNombre.TabIndex = 32;
            this.lblNombre.Text = "Nombre";
            // 
            // ErrorProviderAddClient
            // 
            this.ErrorProviderAddClient.ContainerControl = this;
            // 
            // ErrorProviderAddClient1
            // 
            this.ErrorProviderAddClient1.ContainerControl = this;
            // 
            // ErrorProviderAddClient2
            // 
            this.ErrorProviderAddClient2.ContainerControl = this;
            // 
            // ErrorProviderAddClient3
            // 
            this.ErrorProviderAddClient3.ContainerControl = this;
            // 
            // pnlTopBorder
            // 
            this.pnlTopBorder.BackColor = System.Drawing.Color.Transparent;
            this.pnlTopBorder.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTopBorder.Location = new System.Drawing.Point(0, 0);
            this.pnlTopBorder.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pnlTopBorder.Name = "pnlTopBorder";
            this.pnlTopBorder.Size = new System.Drawing.Size(424, 23);
            this.pnlTopBorder.TabIndex = 47;
            this.pnlTopBorder.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlTopBorder_MouseDown);
            this.pnlTopBorder.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pnlTopBorder_MouseMove);
            this.pnlTopBorder.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pnlTopBorder_MouseUp);
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.btnCancel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.btnCancel.Location = new System.Drawing.Point(290, 206);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(99, 31);
            this.btnCancel.TabIndex = 73;
            this.btnCancel.Text = "Cancelar";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // AddClients
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(234)))), ((int)(((byte)(199)))));
            this.ClientSize = new System.Drawing.Size(424, 269);
            this.ControlBox = false;
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.pnlTopBorder);
            this.Controls.Add(this.btnAddCliente);
            this.Controls.Add(this.txtIDClient);
            this.Controls.Add(this.lblCédula);
            this.Controls.Add(this.txtPhoneClient);
            this.Controls.Add(this.lblDirección);
            this.Controls.Add(this.txtAdressClient);
            this.Controls.Add(this.lblPhone);
            this.Controls.Add(this.txtSurnameClient);
            this.Controls.Add(this.lblApellido);
            this.Controls.Add(this.txtNameClient);
            this.Controls.Add(this.lblNombre);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "AddClients";
            this.Opacity = 0.99D;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            ((System.ComponentModel.ISupportInitialize)(this.ErrorProviderAddClient)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErrorProviderAddClient1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErrorProviderAddClient2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErrorProviderAddClient3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnAddCliente;
        private System.Windows.Forms.TextBox txtIDClient;
        private System.Windows.Forms.Label lblCédula;
        private System.Windows.Forms.TextBox txtPhoneClient;
        private System.Windows.Forms.Label lblDirección;
        private System.Windows.Forms.TextBox txtAdressClient;
        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.TextBox txtSurnameClient;
        private System.Windows.Forms.Label lblApellido;
        private System.Windows.Forms.TextBox txtNameClient;
        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.ErrorProvider ErrorProviderAddClient;
        private System.Windows.Forms.ErrorProvider ErrorProviderAddClient1;
        private System.Windows.Forms.ErrorProvider ErrorProviderAddClient2;
        private System.Windows.Forms.ErrorProvider ErrorProviderAddClient3;
        private System.Windows.Forms.Panel pnlTopBorder;
        private System.Windows.Forms.Button btnCancel;
    }
}