﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace TuProductoOnline
{
    public partial class AddClients : Form
    {
        public AddClients()
        {
            InitializeComponent();
            

        }
        
        //Esta dirección almacena la ruta del archivo Clients.json , utilizando el método GetFullPath().
        private static string _pathclient = Path.GetFullPath(Path.Combine(Application.StartupPath, "..\\..", "Clients.json"));
               
        // Este método "GetFullPath()" se utiliza para leer todo el archivo "Clients.json" y devolverlo como una cadena de texto.
        public static string GetClientsFromFile()
        {
            string clientsJsonFromFile; // Se declara una variable de tipo string llamada clientsJsonFromFile        
            using (var reader = new StreamReader(_pathclient)) // Se utiliza un bloque using para crear un objeto StreamReader que leerá el archivo "Clients.json".
            {
                clientsJsonFromFile = reader.ReadToEnd(); // Se usa el método ReadToEnd() del objeto StreamReader para leer todo el archivo y almacenarlo en la variable
            }              
            return clientsJsonFromFile; // Se devuelve la cadena de texto clientsJsonFromFile.
        }

        //Botón de Añadir Cliente
        private void btnAddClient_Click(object sender, EventArgs e)
        {
            //Validaciones de éste boton
            DelteErrorProviderClient();

            if(CheckerAdd())
            {
                //Parte de añadir el cliente
                // La variable clientsFromFile almacenará el contenido del archivo "Clients.json" como una cadena de texto.
                var clientsFromFile = GetClientsFromFile();

                // La variable clients almacenará una lista de objetos de tipo Client, que se crearán a partir del contenido de clientsFromFile.
                // Para hacer esto, se utiliza el método DeserializeObject() de la clase JsonConvert para convertir la cadena de texto en una lista de objetos de tipo Client.
                var clients = JsonConvert.DeserializeObject<List<Client>>(clientsFromFile);

                //Despliega un cuadro de diálogo de confirmación 
                DialogResult result = MessageBox.Show("¿Está seguro de que desea añadir este Cliente?", "Confirmación", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                //Valida
                if (result == DialogResult.Yes)
                {
                    int count = 0; //Contador cliente
                    foreach (Client client in clients.ToList())  //Recorre la lista para detectar id 
                    {
                        if (txtIDClient.Text == client.Id.ToString())
                        {
                            count++;
                        }
                    }
                    if (count >= 1) 
                    {
                        MessageBox.Show("Este Cliente ya esta Registrado");   //Si existe el cliente
                    }
                    else
                    {
                        if (clients == null)
                        {
                            List<Client> client = new List<Client> //Crea cliente
                            {
                               new Client
                               {
                                 Name=txtNameClient.Text,
                                 LastName=txtSurnameClient.Text,
                                 Id=Convert.ToInt64(txtIDClient.Text),
                                 Phone=Convert.ToInt64(txtPhoneClient.Text),
                                 Address=txtAdressClient.Text
                               }
                            };
                            //JsonConvert.SerializeObject se utiliza para serializar la lista de clientes en formato JSON
                            //El método ToArray() se utiliza para convertir la lista de clientes en una matriz de objetos Client
                            //El segundo parámetro, Formatting.Indented, se utiliza para dar formato al resultado JSON para que sea más legible
                            //La función File.WriteAllText se utiliza para escribir el resultado JSON. El primer parámetro, _pathclient, es la ruta para el archivo.
                            //El segundo parámetro, clientlist, es el contenido que se escribirá en el archivo.
                            //la función ClientLoad  probablemente se encarga de leer el archivo desde el sistema de archivos y actualizar la lista de clientes 
                            string clientlist = JsonConvert.SerializeObject(client.ToArray(), Formatting.Indented);
                            File.WriteAllText(_pathclient, clientlist);
                            
                        }
                        else
                        {
                            //Añade cliente
                            Client client = new Client
                            {
                                Name = txtNameClient.Text,
                                LastName = txtSurnameClient.Text,
                                Id = long.Parse(txtIDClient.Text),
                                Phone = long.Parse(txtPhoneClient.Text),
                                Address = txtAdressClient.Text
                            };
                            clients.Add(client);
                            string clientlist = JsonConvert.SerializeObject(clients.ToArray(), Formatting.Indented);
                            File.WriteAllText(_pathclient, clientlist);
                            
                        }
                        var usersFromFile = LoginMenu.GetUsersFromFile();
                        var users = JsonConvert.DeserializeObject<List<Employee>>(usersFromFile);

                        foreach (Employee employee in users)
                        {
                            if (employee.ActiveSession == true)
                            {
                                employee.LastAddedClient = new Client
                                {
                                    Name = txtNameClient.Text,
                                    LastName = txtSurnameClient.Text,
                                    Id = long.Parse(txtIDClient.Text),
                                    Phone = long.Parse(txtPhoneClient.Text),
                                    Address = txtAdressClient.Text
                                };
                                employee.AddedClients++;
                                string userlist = JsonConvert.SerializeObject(users.ToArray(), Formatting.Indented);
                                File.WriteAllText(LoginMenu._pathuser, userlist);
                                break;
                            }

                        }
                        ClientManageMenu cli = new ClientManageMenu();
                        foreach (Form form in Application.OpenForms)
                        {
                            if (form is ClientManageMenu)
                            {
                                cli = (ClientManageMenu)form;
                                break;
                            }
                        }
                        cli.ClientLoad();
                        this.Close();
                    }
                }//Fin del if interno

            }//Fin del if principal   
        }//Fin Botón de Añadir Cliente

        
        //Boton para regresar al menu de gestion de clientes
        private void btnComeAddCliente_Click(object sender, EventArgs e)
        {
            this.Close();
            ClientManageMenu.ActiveForm.Show();   //falta arreglar
        }
        //Metodo paa validar datos
        public bool CheckerAdd()
        {
            bool validar = true;   
            if(txtNameClient.Text == string.Empty)
            {
                validar = false;
                ErrorProviderAddClient.SetError(txtNameClient, "Ingresar un nombre");
            }
            if (txtPhoneClient.Text == string.Empty)
            {
                validar = false;
                ErrorProviderAddClient.SetError(txtPhoneClient, "Ingresar un telefono");
            }
            if (txtIDClient.Text == string.Empty)
            {
                validar = false;
                ErrorProviderAddClient.SetError(txtIDClient, "Ingresar un ID");
            }
            if (txtSurnameClient.Text == string.Empty)
            {
                validar = false;
                ErrorProviderAddClient.SetError(txtSurnameClient, "Ingresar un apellido");
            }
            if (txtAdressClient.Text == string.Empty)
            {
                validar = false;
                ErrorProviderAddClient.SetError(txtAdressClient, "Ingresar una direccion");
            }
            return validar;
        }

        public void DelteErrorProviderClient()
        {
            ErrorProviderAddClient.SetError(txtNameClient, "");
            ErrorProviderAddClient.SetError(txtAdressClient, "");
            ErrorProviderAddClient.SetError(txtSurnameClient, "");
            ErrorProviderAddClient.SetError(txtPhoneClient, "");
            ErrorProviderAddClient.SetError(txtIDClient, "");
        }
        private void CheckCampos()
        {
            long validationIDclient;
            bool IDValido = long.TryParse(txtIDClient.Text, out validationIDclient);
            bool nombreValido = ValidarNombre(txtNameClient.Text);
            bool apellidoValido = ValidarApellido(txtSurnameClient.Text);
            bool telefonoValido = ValidarTelefono(txtPhoneClient.Text);
            bool direccionValida = ValidarDireccion(txtAdressClient.Text);

            if (IDValido && nombreValido && apellidoValido && telefonoValido && direccionValida)
            {
                btnAddCliente.Enabled = true;
                ErrorProviderAddClient.Clear();
            }
            else
            {
                btnAddCliente.Enabled = false;
                ErrorProviderAddClient.SetError(btnAddCliente, "Por favor, complete todos los campos correctamente.");
                if (!nombreValido)
                {
                    ErrorProviderAddClient.SetError(txtNameClient, "El nombre solo debe contener letras y espacios.");
                }
                if (!apellidoValido)
                {
                    ErrorProviderAddClient.SetError(txtSurnameClient, "El apellido solo debe contener letras y espacios.");
                }
                if (!IDValido)
                {
                    ErrorProviderAddClient.SetError(txtIDClient, "El ID solo debe contener números.");
                }
                if (!telefonoValido)
                {
                    ErrorProviderAddClient.SetError(txtPhoneClient, "El número de teléfono solo debe contener números.");
                }
                if (!direccionValida)
                {
                    ErrorProviderAddClient.SetError(txtAdressClient, "La dirección no es válida.");
                }
            }
        }
        private void txtIDClient_TextChanged(object sender, EventArgs e)
        {
            CheckCampos();
        }
        private void txtPhoneClient_TextChanged(object sender, EventArgs e)
        {
            CheckCampos();
        }
        private void txtAdressClient_TextChanged(object sender, EventArgs e)
        {
            CheckCampos();
        }
        private void txtNameClient_TextChanged(object sender, EventArgs e)
        {
            CheckCampos();
        }
        private void txtSurnameClient_TextChanged(object sender, EventArgs e)
        {
            CheckCampos();
        }
        private bool ValidarNombre(string nombre)
        {
            foreach (char c in nombre)
            {
                if (!Char.IsLetter(c) && !Char.IsWhiteSpace(c))
                {
                    return false;
                }
            }
            return true;
        }

        private bool ValidarApellido(string apellido)
        {
            foreach (char c in apellido)
            {
                if (!Char.IsLetter(c) && !Char.IsWhiteSpace(c))
                {
                    return false;
                }
            }
            return true;
        }

        private bool ValidarTelefono(string telefono)
        {
            foreach (char c in telefono)
            {
                if (!Char.IsDigit(c))
                {
                    return false;
                }
            }
            return true;
        }

        private bool ValidarDireccion(string direccion)
        {
            foreach (char c in direccion)
            {
                if (!Char.IsLetterOrDigit(c) && !Char.IsWhiteSpace(c) && !Char.IsPunctuation(c))
                {
                    return false;
                }
            }
            return true;
        }

        int m, mx, my;
        private void pnlTopBorder_MouseDown(object sender, MouseEventArgs e)
        {
            m = 1;
            mx = e.X;
            my = e.Y;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pnlTopBorder_MouseMove(object sender, MouseEventArgs e)
        {
            if (m == 1)
            {
                this.SetDesktopLocation(MousePosition.X - mx, MousePosition.Y - my);
            }
        }

        private void pnlTopBorder_MouseUp(object sender, MouseEventArgs e)
        {
            m = 0;
        }
    }
}

