﻿namespace TuProductoOnline
{
    partial class AddProduct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddProduct));
            this.txtIdProduct = new System.Windows.Forms.TextBox();
            this.lblIdProduct = new System.Windows.Forms.Label();
            this.lblDescriptionProduct = new System.Windows.Forms.Label();
            this.lblNameProduct = new System.Windows.Forms.Label();
            this.txtNameProduct = new System.Windows.Forms.TextBox();
            this.lblPriceProduct = new System.Windows.Forms.Label();
            this.txtPriceProduct = new System.Windows.Forms.TextBox();
            this.cbCategoryProduct = new System.Windows.Forms.ComboBox();
            this.txtMeassuresProduct = new System.Windows.Forms.TextBox();
            this.lblMeassuresProduct = new System.Windows.Forms.Label();
            this.lblLicenceProduct = new System.Windows.Forms.Label();
            this.txtLicenceProduct = new System.Windows.Forms.TextBox();
            this.lblVersionProduct = new System.Windows.Forms.Label();
            this.txtVersionProduct = new System.Windows.Forms.TextBox();
            this.lblModelProduct = new System.Windows.Forms.Label();
            this.txtModelProduct = new System.Windows.Forms.TextBox();
            this.btnAddProduct = new System.Windows.Forms.Button();
            this.txtDescriptionProduct = new System.Windows.Forms.RichTextBox();
            this.btnCancelProduct = new System.Windows.Forms.Button();
            this.txtCantityProduct = new System.Windows.Forms.TextBox();
            this.lblCantity = new System.Windows.Forms.Label();
            this.lblCategoryProduct = new System.Windows.Forms.Label();
            this.pnlTopBorder = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // txtIdProduct
            // 
            this.txtIdProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtIdProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtIdProduct.Enabled = false;
            this.txtIdProduct.ForeColor = System.Drawing.Color.White;
            this.txtIdProduct.Location = new System.Drawing.Point(304, 128);
            this.txtIdProduct.MaxLength = 10;
            this.txtIdProduct.Name = "txtIdProduct";
            this.txtIdProduct.ReadOnly = true;
            this.txtIdProduct.Size = new System.Drawing.Size(100, 20);
            this.txtIdProduct.TabIndex = 4;
            // 
            // lblIdProduct
            // 
            this.lblIdProduct.AutoSize = true;
            this.lblIdProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIdProduct.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblIdProduct.Location = new System.Drawing.Point(329, 98);
            this.lblIdProduct.Name = "lblIdProduct";
            this.lblIdProduct.Size = new System.Drawing.Size(52, 15);
            this.lblIdProduct.TabIndex = 1;
            this.lblIdProduct.Text = "Código";
            // 
            // lblDescriptionProduct
            // 
            this.lblDescriptionProduct.AutoSize = true;
            this.lblDescriptionProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescriptionProduct.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblDescriptionProduct.Location = new System.Drawing.Point(48, 222);
            this.lblDescriptionProduct.Name = "lblDescriptionProduct";
            this.lblDescriptionProduct.Size = new System.Drawing.Size(83, 15);
            this.lblDescriptionProduct.TabIndex = 3;
            this.lblDescriptionProduct.Text = "Descripción";
            // 
            // lblNameProduct
            // 
            this.lblNameProduct.AutoSize = true;
            this.lblNameProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNameProduct.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblNameProduct.Location = new System.Drawing.Point(59, 98);
            this.lblNameProduct.Name = "lblNameProduct";
            this.lblNameProduct.Size = new System.Drawing.Size(58, 15);
            this.lblNameProduct.TabIndex = 5;
            this.lblNameProduct.Text = "Nombre";
            // 
            // txtNameProduct
            // 
            this.txtNameProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtNameProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtNameProduct.ForeColor = System.Drawing.Color.White;
            this.txtNameProduct.Location = new System.Drawing.Point(37, 128);
            this.txtNameProduct.MaxLength = 20;
            this.txtNameProduct.Name = "txtNameProduct";
            this.txtNameProduct.Size = new System.Drawing.Size(100, 20);
            this.txtNameProduct.TabIndex = 2;
            this.txtNameProduct.TextChanged += new System.EventHandler(this.txtNameProduct_TextChanged);
            this.txtNameProduct.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNameProduct_KeyPress);
            // 
            // lblPriceProduct
            // 
            this.lblPriceProduct.AutoSize = true;
            this.lblPriceProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPriceProduct.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblPriceProduct.Location = new System.Drawing.Point(199, 98);
            this.lblPriceProduct.Name = "lblPriceProduct";
            this.lblPriceProduct.Size = new System.Drawing.Size(48, 15);
            this.lblPriceProduct.TabIndex = 7;
            this.lblPriceProduct.Text = "Precio";
            // 
            // txtPriceProduct
            // 
            this.txtPriceProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtPriceProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPriceProduct.ForeColor = System.Drawing.Color.White;
            this.txtPriceProduct.Location = new System.Drawing.Point(171, 128);
            this.txtPriceProduct.MaxLength = 10;
            this.txtPriceProduct.Name = "txtPriceProduct";
            this.txtPriceProduct.Size = new System.Drawing.Size(100, 20);
            this.txtPriceProduct.TabIndex = 3;
            this.txtPriceProduct.TextChanged += new System.EventHandler(this.txtNameProduct_TextChanged);
            this.txtPriceProduct.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPriceProduct_KeyPress);
            // 
            // cbCategoryProduct
            // 
            this.cbCategoryProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.cbCategoryProduct.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbCategoryProduct.ForeColor = System.Drawing.Color.White;
            this.cbCategoryProduct.FormattingEnabled = true;
            this.cbCategoryProduct.Items.AddRange(new object[] {
            "Hardware",
            "Software",
            "Device"});
            this.cbCategoryProduct.Location = new System.Drawing.Point(161, 47);
            this.cbCategoryProduct.Name = "cbCategoryProduct";
            this.cbCategoryProduct.Size = new System.Drawing.Size(121, 21);
            this.cbCategoryProduct.TabIndex = 1;
            this.cbCategoryProduct.SelectedIndexChanged += new System.EventHandler(this.cbCategory_SelectedIndexChanged);
            // 
            // txtMeassuresProduct
            // 
            this.txtMeassuresProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtMeassuresProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtMeassuresProduct.ForeColor = System.Drawing.Color.White;
            this.txtMeassuresProduct.Location = new System.Drawing.Point(171, 188);
            this.txtMeassuresProduct.MaxLength = 20;
            this.txtMeassuresProduct.Name = "txtMeassuresProduct";
            this.txtMeassuresProduct.Size = new System.Drawing.Size(100, 20);
            this.txtMeassuresProduct.TabIndex = 6;
            this.txtMeassuresProduct.Visible = false;
            this.txtMeassuresProduct.TextChanged += new System.EventHandler(this.txtNameProduct_TextChanged);
            // 
            // lblMeassuresProduct
            // 
            this.lblMeassuresProduct.AutoSize = true;
            this.lblMeassuresProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMeassuresProduct.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblMeassuresProduct.Location = new System.Drawing.Point(190, 161);
            this.lblMeassuresProduct.Name = "lblMeassuresProduct";
            this.lblMeassuresProduct.Size = new System.Drawing.Size(62, 15);
            this.lblMeassuresProduct.TabIndex = 10;
            this.lblMeassuresProduct.Text = "Medidas";
            this.lblMeassuresProduct.Visible = false;
            // 
            // lblLicenceProduct
            // 
            this.lblLicenceProduct.AutoSize = true;
            this.lblLicenceProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLicenceProduct.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblLicenceProduct.Location = new System.Drawing.Point(190, 161);
            this.lblLicenceProduct.Name = "lblLicenceProduct";
            this.lblLicenceProduct.Size = new System.Drawing.Size(61, 15);
            this.lblLicenceProduct.TabIndex = 12;
            this.lblLicenceProduct.Text = "Licencia";
            this.lblLicenceProduct.Visible = false;
            // 
            // txtLicenceProduct
            // 
            this.txtLicenceProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtLicenceProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtLicenceProduct.ForeColor = System.Drawing.Color.White;
            this.txtLicenceProduct.Location = new System.Drawing.Point(171, 188);
            this.txtLicenceProduct.MaxLength = 20;
            this.txtLicenceProduct.Name = "txtLicenceProduct";
            this.txtLicenceProduct.Size = new System.Drawing.Size(100, 20);
            this.txtLicenceProduct.TabIndex = 6;
            this.txtLicenceProduct.Visible = false;
            this.txtLicenceProduct.TextChanged += new System.EventHandler(this.txtNameProduct_TextChanged);
            // 
            // lblVersionProduct
            // 
            this.lblVersionProduct.AutoSize = true;
            this.lblVersionProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVersionProduct.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblVersionProduct.Location = new System.Drawing.Point(326, 161);
            this.lblVersionProduct.Name = "lblVersionProduct";
            this.lblVersionProduct.Size = new System.Drawing.Size(55, 15);
            this.lblVersionProduct.TabIndex = 14;
            this.lblVersionProduct.Text = "Version";
            this.lblVersionProduct.Visible = false;
            // 
            // txtVersionProduct
            // 
            this.txtVersionProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtVersionProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtVersionProduct.ForeColor = System.Drawing.Color.White;
            this.txtVersionProduct.Location = new System.Drawing.Point(304, 188);
            this.txtVersionProduct.MaxLength = 20;
            this.txtVersionProduct.Name = "txtVersionProduct";
            this.txtVersionProduct.Size = new System.Drawing.Size(100, 20);
            this.txtVersionProduct.TabIndex = 7;
            this.txtVersionProduct.Visible = false;
            this.txtVersionProduct.TextChanged += new System.EventHandler(this.txtNameProduct_TextChanged);
            // 
            // lblModelProduct
            // 
            this.lblModelProduct.AutoSize = true;
            this.lblModelProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblModelProduct.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblModelProduct.Location = new System.Drawing.Point(198, 161);
            this.lblModelProduct.Name = "lblModelProduct";
            this.lblModelProduct.Size = new System.Drawing.Size(47, 15);
            this.lblModelProduct.TabIndex = 16;
            this.lblModelProduct.Text = "Model";
            this.lblModelProduct.Visible = false;
            // 
            // txtModelProduct
            // 
            this.txtModelProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtModelProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtModelProduct.ForeColor = System.Drawing.Color.White;
            this.txtModelProduct.Location = new System.Drawing.Point(171, 188);
            this.txtModelProduct.MaxLength = 20;
            this.txtModelProduct.Name = "txtModelProduct";
            this.txtModelProduct.Size = new System.Drawing.Size(100, 20);
            this.txtModelProduct.TabIndex = 6;
            this.txtModelProduct.Visible = false;
            this.txtModelProduct.TextChanged += new System.EventHandler(this.txtNameProduct_TextChanged);
            // 
            // btnAddProduct
            // 
            this.btnAddProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.btnAddProduct.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnAddProduct.Enabled = false;
            this.btnAddProduct.FlatAppearance.BorderSize = 0;
            this.btnAddProduct.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddProduct.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.btnAddProduct.Location = new System.Drawing.Point(327, 396);
            this.btnAddProduct.Name = "btnAddProduct";
            this.btnAddProduct.Size = new System.Drawing.Size(77, 23);
            this.btnAddProduct.TabIndex = 9;
            this.btnAddProduct.Text = "Añadir Producto";
            this.btnAddProduct.UseVisualStyleBackColor = false;
            this.btnAddProduct.Click += new System.EventHandler(this.btnRegistrar_Click);
            // 
            // txtDescriptionProduct
            // 
            this.txtDescriptionProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtDescriptionProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDescriptionProduct.ForeColor = System.Drawing.Color.White;
            this.txtDescriptionProduct.Location = new System.Drawing.Point(37, 252);
            this.txtDescriptionProduct.MaxLength = 200;
            this.txtDescriptionProduct.Name = "txtDescriptionProduct";
            this.txtDescriptionProduct.Size = new System.Drawing.Size(367, 96);
            this.txtDescriptionProduct.TabIndex = 8;
            this.txtDescriptionProduct.Text = "";
            this.txtDescriptionProduct.TextChanged += new System.EventHandler(this.txtNameProduct_TextChanged);
            // 
            // btnCancelProduct
            // 
            this.btnCancelProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.btnCancelProduct.FlatAppearance.BorderSize = 0;
            this.btnCancelProduct.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancelProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelProduct.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.btnCancelProduct.Location = new System.Drawing.Point(37, 396);
            this.btnCancelProduct.Name = "btnCancelProduct";
            this.btnCancelProduct.Size = new System.Drawing.Size(75, 23);
            this.btnCancelProduct.TabIndex = 10;
            this.btnCancelProduct.Text = "Cancelar";
            this.btnCancelProduct.UseVisualStyleBackColor = false;
            this.btnCancelProduct.Click += new System.EventHandler(this.btnCancelProduct_Click);
            // 
            // txtCantityProduct
            // 
            this.txtCantityProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtCantityProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCantityProduct.ForeColor = System.Drawing.Color.White;
            this.txtCantityProduct.Location = new System.Drawing.Point(37, 188);
            this.txtCantityProduct.MaxLength = 3;
            this.txtCantityProduct.Name = "txtCantityProduct";
            this.txtCantityProduct.Size = new System.Drawing.Size(100, 20);
            this.txtCantityProduct.TabIndex = 5;
            this.txtCantityProduct.TextChanged += new System.EventHandler(this.txtNameProduct_TextChanged);
            this.txtCantityProduct.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCantity_KeyPress);
            // 
            // lblCantity
            // 
            this.lblCantity.AutoSize = true;
            this.lblCantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCantity.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblCantity.Location = new System.Drawing.Point(54, 161);
            this.lblCantity.Name = "lblCantity";
            this.lblCantity.Size = new System.Drawing.Size(64, 15);
            this.lblCantity.TabIndex = 21;
            this.lblCantity.Text = "Cantidad";
            // 
            // lblCategoryProduct
            // 
            this.lblCategoryProduct.AutoSize = true;
            this.lblCategoryProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCategoryProduct.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblCategoryProduct.Location = new System.Drawing.Point(188, 19);
            this.lblCategoryProduct.Name = "lblCategoryProduct";
            this.lblCategoryProduct.Size = new System.Drawing.Size(69, 15);
            this.lblCategoryProduct.TabIndex = 22;
            this.lblCategoryProduct.Text = "Categoria";
            // 
            // pnlTopBorder
            // 
            this.pnlTopBorder.BackColor = System.Drawing.Color.Transparent;
            this.pnlTopBorder.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTopBorder.Location = new System.Drawing.Point(0, 0);
            this.pnlTopBorder.Name = "pnlTopBorder";
            this.pnlTopBorder.Size = new System.Drawing.Size(439, 20);
            this.pnlTopBorder.TabIndex = 23;
            this.pnlTopBorder.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlTopBorder_MouseDown);
            this.pnlTopBorder.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pnlTopBorder_MouseMove);
            this.pnlTopBorder.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pnlTopBorder_MouseUp);
            // 
            // AddProduct
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(234)))), ((int)(((byte)(199)))));
            this.ClientSize = new System.Drawing.Size(439, 449);
            this.ControlBox = false;
            this.Controls.Add(this.pnlTopBorder);
            this.Controls.Add(this.lblCategoryProduct);
            this.Controls.Add(this.lblCantity);
            this.Controls.Add(this.txtCantityProduct);
            this.Controls.Add(this.btnCancelProduct);
            this.Controls.Add(this.txtDescriptionProduct);
            this.Controls.Add(this.btnAddProduct);
            this.Controls.Add(this.txtModelProduct);
            this.Controls.Add(this.lblVersionProduct);
            this.Controls.Add(this.txtVersionProduct);
            this.Controls.Add(this.txtLicenceProduct);
            this.Controls.Add(this.txtMeassuresProduct);
            this.Controls.Add(this.cbCategoryProduct);
            this.Controls.Add(this.lblPriceProduct);
            this.Controls.Add(this.txtPriceProduct);
            this.Controls.Add(this.lblNameProduct);
            this.Controls.Add(this.txtNameProduct);
            this.Controls.Add(this.lblDescriptionProduct);
            this.Controls.Add(this.lblIdProduct);
            this.Controls.Add(this.txtIdProduct);
            this.Controls.Add(this.lblModelProduct);
            this.Controls.Add(this.lblLicenceProduct);
            this.Controls.Add(this.lblMeassuresProduct);
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(455, 465);
            this.MinimumSize = new System.Drawing.Size(455, 465);
            this.Name = "AddProduct";
            this.Opacity = 0.99D;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtIdProduct;
        private System.Windows.Forms.Label lblIdProduct;
        private System.Windows.Forms.Label lblDescriptionProduct;
        private System.Windows.Forms.Label lblNameProduct;
        private System.Windows.Forms.TextBox txtNameProduct;
        private System.Windows.Forms.Label lblPriceProduct;
        private System.Windows.Forms.TextBox txtPriceProduct;
        private System.Windows.Forms.ComboBox cbCategoryProduct;
        private System.Windows.Forms.TextBox txtMeassuresProduct;
        private System.Windows.Forms.Label lblMeassuresProduct;
        private System.Windows.Forms.Label lblLicenceProduct;
        private System.Windows.Forms.TextBox txtLicenceProduct;
        private System.Windows.Forms.Label lblVersionProduct;
        private System.Windows.Forms.TextBox txtVersionProduct;
        private System.Windows.Forms.Label lblModelProduct;
        private System.Windows.Forms.TextBox txtModelProduct;
        private System.Windows.Forms.Button btnAddProduct;
        private System.Windows.Forms.RichTextBox txtDescriptionProduct;
        private System.Windows.Forms.Button btnCancelProduct;
        private System.Windows.Forms.TextBox txtCantityProduct;
        private System.Windows.Forms.Label lblCantity;
        private System.Windows.Forms.Label lblCategoryProduct;
        private System.Windows.Forms.Panel pnlTopBorder;
    }
}