﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TuProductoOnline
{
    public partial class AddProduct : Form
    {
        public AddProduct()
        {
            InitializeComponent();
            

        }
       //Esta dirección almacena la ruta del archivo Products.json , utilizando el método GetFullPath().
        private static string _pathproduct = Path.GetFullPath(Path.Combine(Application.StartupPath, "..\\..", "Products.json"));
        
        //es un evento que se activa cuando se selecciona un elemento en un ComboBox llamado cbCategory
        private void cbCategory_SelectedIndexChanged(object sender, EventArgs e)
        { 
            //Verifica que el ComboBox sea igual a la Categoría
            //El .Show se utiliza para mostrar una ventana o un formulario en la pantalla
            //El .Hide se utiliza para ocultar una ventana o un formulario en la pantalla
            if ((string)cbCategoryProduct.SelectedItem == "Hardware")
            {
                txtIdProduct.Text = IdHardware();
                txtMeassuresProduct.Show();
                lblMeassuresProduct.Show();
                txtModelProduct.Hide();
                lblModelProduct.Hide();
                txtLicenceProduct.Hide();
                lblLicenceProduct.Hide();
                txtVersionProduct.Hide();
                lblVersionProduct.Hide();

            }
            if ((string)cbCategoryProduct.SelectedItem == "Software")
            {
                txtIdProduct.Text = IdSoftware();
                txtMeassuresProduct.Hide();
                lblMeassuresProduct.Hide();
                txtModelProduct.Hide();
                lblModelProduct.Hide();
                txtLicenceProduct.Show();
                lblLicenceProduct.Show();
                txtVersionProduct.Show();
                lblVersionProduct.Show();
            }
            if ((string)cbCategoryProduct.SelectedItem == "Device")
            {
                txtIdProduct.Text = IdDevice();
                txtMeassuresProduct.Hide();
                lblMeassuresProduct.Hide();
                txtModelProduct.Show();
                lblModelProduct.Show();
                txtLicenceProduct.Hide();
                lblLicenceProduct.Hide();
                txtVersionProduct.Hide();
                lblVersionProduct.Hide();
            }
        }

        //Botón de Registrar
        private void btnRegistrar_Click(object sender, EventArgs e)
        {

            var productsfromfile = ProductManageMenu.GetProductsFromFile(); //metodo que lee el Json
            var products = JsonConvert.DeserializeObject<List<Product>>(productsfromfile); //deserializa(convierte) Json a lista
            
            DialogResult result = MessageBox.Show("¿Está seguro de que desea agregar este producto?", "Confirmación", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                int count = 0;
                foreach (Product product in products.ToList())
                {
                    if (txtNameProduct.Text == product.Name && txtDescriptionProduct.Text == product.Description)
                    {
                        count++;
                    }

                }
                if (count >= 1)
                {
                    MessageBox.Show("Este Producto ya esta Registrado");   //Si existe el producto
                }

                else
                {
                    if ((string)cbCategoryProduct.SelectedItem == "Hardware")
                    {

                        if (products == null)
                        {
                            List<Product> product = new List<Product>();
                            product.Add(new Product()
                            {
                                Id = "H0001",
                                Name = txtNameProduct.Text,
                                Description = txtDescriptionProduct.Text,
                                Price = float.Parse(txtPriceProduct.Text),
                                Type = "Hardware",
                                Cantity = int.Parse(txtCantityProduct.Text),
                                Hard = new Hardware()
                                {
                                    IsHarware = true,
                                    Meassures = txtMeassuresProduct.Text,
                                }

                            }); ;

                            string productJson = JsonConvert.SerializeObject(product.ToArray(), Formatting.Indented);
                            File.WriteAllText(_pathproduct, productJson);
                        }
                        else
                        {

                            Product product = new Product()
                            {
                                Id = IdHardware(),
                                Name = txtNameProduct.Text,
                                Description = txtDescriptionProduct.Text,
                                Price = float.Parse(txtPriceProduct.Text),
                                Type = "Hardware",
                                Cantity = int.Parse(txtCantityProduct.Text),
                                Hard = new Hardware()
                                {
                                    Meassures = txtMeassuresProduct.Text,
                                    IsHarware = true,
                                }
                            };
                            products.Add(product);

                            string productJson = JsonConvert.SerializeObject(products.ToArray(), Formatting.Indented);
                            //Serializa el objeto en forma de users(Una lista) y lo guarda en la variable
                            File.WriteAllText(_pathproduct, productJson);
                        }
                    }

                    if ((string)cbCategoryProduct.SelectedItem == "Software")
                    {

                        if (products == null)
                        {
                            List<Product> product1 = new List<Product>();
                            product1.Add(new Product
                            {
                                Id = "S0001",
                                Name = txtNameProduct.Text,
                                Description = txtDescriptionProduct.Text,
                                Price = float.Parse(txtPriceProduct.Text),
                                Type = "Software",
                                Cantity = int.Parse(txtCantityProduct.Text),
                                Soft = new Software
                                {
                                    IsSoftware = true,
                                    Version = txtVersionProduct.Text,
                                    Licence = txtLicenceProduct.Text,
                                }
                            });

                            string productJson = JsonConvert.SerializeObject(product1.ToArray(), Formatting.Indented);
                            File.WriteAllText(_pathproduct, productJson);

                        }

                        else
                        {
                            Product product1 = new Product()
                            {
                                Id = IdSoftware(),
                                Name = txtNameProduct.Text,
                                Description = txtDescriptionProduct.Text,
                                Price = float.Parse(txtPriceProduct.Text),
                                Type = "Software",
                                Cantity = int.Parse(txtCantityProduct.Text),
                                Soft = new Software
                                {
                                    IsSoftware = true,
                                    Version = txtVersionProduct.Text,
                                    Licence = txtLicenceProduct.Text,
                                }
                            };
                            products.Add(product1);

                           

                            string productJson = JsonConvert.SerializeObject(products.ToArray(), Formatting.Indented);//Serializa el objeto en forma de users(Una lista) y lo guarda en la variable
                            File.WriteAllText(_pathproduct, productJson);
                        }
                    }
                    if ((string)cbCategoryProduct.SelectedItem == "Device")
                    {

                        if (products == null)
                        {
                            List<Product> product2 = new List<Product>();

                            product2.Add(new Product()
                            {
                                Id = "D0001",
                                Name = txtNameProduct.Text,
                                Description = txtDescriptionProduct.Text,
                                Price = float.Parse(txtPriceProduct.Text),
                                Type = "Device",
                                Cantity = int.Parse(txtCantityProduct.Text),
                                Devi = new Device
                                {
                                    IsDevice = true,
                                    Model = txtModelProduct.Text,
                                }
                            });

                            string productJson = JsonConvert.SerializeObject(product2.ToArray(), Formatting.Indented);
                            File.WriteAllText(_pathproduct, productJson);
                        }

                        else
                        {
                            Product product2 = new Product()
                            {
                                Id = IdDevice(),
                                Name = txtNameProduct.Text,
                                Description = txtDescriptionProduct.Text,
                                Price = float.Parse(txtPriceProduct.Text),
                                Type = "Device",
                                Cantity = int.Parse(txtCantityProduct.Text),
                                Devi = new Device
                                {
                                    IsDevice = true,
                                    Model = txtModelProduct.Text,

                                }


                            };
                            products.Add(product2);


                            string productJson = JsonConvert.SerializeObject(products.ToArray(), Formatting.Indented);//Serializa el objeto en forma de users(Una lista) y lo guarda en la variable
                            File.WriteAllText(_pathproduct, productJson);
                        }
                    }

                    MessageBox.Show("El producto ha sido añadido correctamente");
                    ProductManageMenu pro = new ProductManageMenu();
                    foreach (Form form in Application.OpenForms)
                    {
                        if (form is ProductManageMenu)
                        {
                            pro = (ProductManageMenu)form;
                            break;
                        }
                    }
                    pro.ProductLoad();
                   
                    this.Close();

                }
            }
        }

        private void btnCancelProduct_Click(object sender, EventArgs e)
        {
            this.Close();

        }
        //se utiliza para restringir la entrada de caracteres en un
        //cuadro de texto a solo letras, espacios y caracteres de control.
        private void txtNameProduct_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsSeparator(e.KeyChar))
            {
                e.Handled = true;
            }
        }
        //se utiliza para restringir la entrada de caracteres en un cuadro de texto a solo números
        //y caracteres de control como la tecla "Backspace" o "Delete"
        private void txtPriceProduct_KeyPress(object sender, KeyPressEventArgs e)
        {
            OnlyNumber(e, false);
        }
        private static void OnlyNumber(KeyPressEventArgs e, bool isdecimal)
        {
            string accepted;
            if (!isdecimal)
            {
                accepted = "0123456789," + Convert.ToChar(8);

            }
            else
            {
                accepted = "0123456789," + Convert.ToChar(8);

            }
            if (accepted.Contains("" + e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void txtCantity_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }
        //es una función que se utiliza para generar un nuevo identificador
        //de hardware para un producto basado en una lista de productos existentes
        public string IdHardware()
        {
            var productsfromfile = ProductManageMenu.GetProductsFromFile(); //lee Json

            var products = JsonConvert.DeserializeObject<List<Product>>(productsfromfile);
            int count = 1;
            
            if (products == null)
            {
                return "H0001";
            }
            else
            {
                foreach (Product product in products)
                {
                    if ("H" + count.ToString("D4") == product.Id)
                    {
                        count++;
                    }
                }
                return "H" + count.ToString("D4");
            }
        }
        //es una función que se utiliza para generar un nuevo identificador
        //de sofware para un producto basado en una lista de productos existentes
        public string IdSoftware()
        {
            var productsfromfile = ProductManageMenu.GetProductsFromFile();

            var products = JsonConvert.DeserializeObject<List<Product>>(productsfromfile);
            int count = 1;

            if (products == null)
            {
                return "S0001";
            }
            else
            {
                foreach (Product product in products)
                {
                    if ("S" + count.ToString("D4") == product.Id)
                    {
                        count++;
                    }
                }
                return "S" + count.ToString("D4");
            }
        }
        //es una función que se utiliza para generar un nuevo identificador
        //de device para un producto basado en una lista de productos existentes
        public string IdDevice()
        {
            var productsfromfile = ProductManageMenu.GetProductsFromFile();

            var products = JsonConvert.DeserializeObject<List<Product>>(productsfromfile);
            int count = 1;

            if (products == null)
            {
                return "D0001";
            }
            else
            {
                foreach (Product product in products)
                {
                    if ("D" + count.ToString("D4") == product.Id)
                    {
                        count++;
                    }
                }
                return "D" + count.ToString("D4");
            }
        }

        public void TextChecker()
        {
            if ((string)cbCategoryProduct.SelectedItem == "Device")
            {
                if (txtNameProduct.Text != string.Empty && txtDescriptionProduct.Text != string.Empty && txtCantityProduct.Text != string.Empty && txtPriceProduct.Text != string.Empty && txtModelProduct.Text != string.Empty)
                {
                    btnAddProduct.Enabled = true;
                }
                else { btnAddProduct.Enabled = false; }
            }
            if ((string)cbCategoryProduct.SelectedItem == "Hardware")
            {
                if (txtNameProduct.Text != string.Empty && txtDescriptionProduct.Text != string.Empty && txtCantityProduct.Text != string.Empty && txtPriceProduct.Text != string.Empty && txtMeassuresProduct.Text != string.Empty)
                {
                    btnAddProduct.Enabled = true;
                }
                else { btnAddProduct.Enabled = false; }
            }
            if ((string)cbCategoryProduct.SelectedItem == "Software")
            {
                if (txtNameProduct.Text != string.Empty && txtDescriptionProduct.Text != string.Empty && txtCantityProduct.Text != string.Empty && txtPriceProduct.Text != string.Empty && txtVersionProduct.Text != string.Empty && txtLicenceProduct.Text!=string.Empty)
                {
                    btnAddProduct.Enabled = true;
                }
                else { btnAddProduct.Enabled = false; }
            }
        }

        private void txtNameProduct_TextChanged(object sender, EventArgs e)
        {
            TextChecker();
        }
        int m, mx, my;
        private void pnlTopBorder_MouseDown(object sender, MouseEventArgs e)
        {
            m = 1;
            mx = e.X;
            my = e.Y;
        }

        private void pnlTopBorder_MouseMove(object sender, MouseEventArgs e)
        {
            if (m == 1)
            {
                this.SetDesktopLocation(MousePosition.X - mx, MousePosition.Y - my);
            }
        }

        private void pnlTopBorder_MouseUp(object sender, MouseEventArgs e)
        {
            m = 0;
        }
    }
}
