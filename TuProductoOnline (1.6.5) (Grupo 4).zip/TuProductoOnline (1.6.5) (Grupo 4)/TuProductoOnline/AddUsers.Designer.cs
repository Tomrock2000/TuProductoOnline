﻿namespace TuProductoOnline
{
    partial class AddUsers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddUsers));
            this.errorProviderUsers1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProviderUsers2 = new System.Windows.Forms.ErrorProvider(this.components);
            this.label2 = new System.Windows.Forms.Label();
            this.txtPasswordUsers = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtUsersNameCode = new System.Windows.Forms.TextBox();
            this.btnAddUsers = new System.Windows.Forms.Button();
            this.txtIDUsers = new System.Windows.Forms.TextBox();
            this.lblCédula = new System.Windows.Forms.Label();
            this.txtPhoneUsers = new System.Windows.Forms.TextBox();
            this.lblDirección = new System.Windows.Forms.Label();
            this.txtAdressUsers = new System.Windows.Forms.TextBox();
            this.lblPhone = new System.Windows.Forms.Label();
            this.txtSurnameUsers = new System.Windows.Forms.TextBox();
            this.lblApellido = new System.Windows.Forms.Label();
            this.txtNameUsers = new System.Windows.Forms.TextBox();
            this.lblNombre = new System.Windows.Forms.Label();
            this.pnlTopBorder = new System.Windows.Forms.Panel();
            this.btnCancel = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderUsers1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderUsers2)).BeginInit();
            this.SuspendLayout();
            // 
            // errorProviderUsers1
            // 
            this.errorProviderUsers1.ContainerControl = this;
            // 
            // errorProviderUsers2
            // 
            this.errorProviderUsers2.ContainerControl = this;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label2.Location = new System.Drawing.Point(53, 82);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 15);
            this.label2.TabIndex = 82;
            this.label2.Text = "Contraseña";
            // 
            // txtPasswordUsers
            // 
            this.txtPasswordUsers.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtPasswordUsers.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPasswordUsers.ForeColor = System.Drawing.Color.White;
            this.txtPasswordUsers.Location = new System.Drawing.Point(32, 106);
            this.txtPasswordUsers.Name = "txtPasswordUsers";
            this.txtPasswordUsers.Size = new System.Drawing.Size(123, 26);
            this.txtPasswordUsers.TabIndex = 2;
            this.txtPasswordUsers.TextChanged += new System.EventHandler(this.txtPasswordUsers_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label1.Location = new System.Drawing.Point(27, 29);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(132, 15);
            this.label1.TabIndex = 80;
            this.label1.Text = "Nombre de Usuario";
            // 
            // txtUsersNameCode
            // 
            this.txtUsersNameCode.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtUsersNameCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtUsersNameCode.ForeColor = System.Drawing.Color.White;
            this.txtUsersNameCode.Location = new System.Drawing.Point(32, 52);
            this.txtUsersNameCode.Name = "txtUsersNameCode";
            this.txtUsersNameCode.Size = new System.Drawing.Size(123, 26);
            this.txtUsersNameCode.TabIndex = 1;
            this.txtUsersNameCode.TextChanged += new System.EventHandler(this.txtUsersNameCode_TextChanged);
            // 
            // btnAddUsers
            // 
            this.btnAddUsers.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.btnAddUsers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddUsers.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.btnAddUsers.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.btnAddUsers.Location = new System.Drawing.Point(217, 210);
            this.btnAddUsers.Name = "btnAddUsers";
            this.btnAddUsers.Size = new System.Drawing.Size(84, 28);
            this.btnAddUsers.TabIndex = 8;
            this.btnAddUsers.Text = "Registrar";
            this.btnAddUsers.UseVisualStyleBackColor = false;
            this.btnAddUsers.Click += new System.EventHandler(this.btnAddUsers_Click);
            // 
            // txtIDUsers
            // 
            this.txtIDUsers.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtIDUsers.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtIDUsers.ForeColor = System.Drawing.Color.White;
            this.txtIDUsers.Location = new System.Drawing.Point(178, 158);
            this.txtIDUsers.MaxLength = 9;
            this.txtIDUsers.Name = "txtIDUsers";
            this.txtIDUsers.Size = new System.Drawing.Size(123, 26);
            this.txtIDUsers.TabIndex = 7;
            this.txtIDUsers.TextChanged += new System.EventHandler(this.txtIDUsers_TextChanged);
            // 
            // lblCédula
            // 
            this.lblCédula.AutoSize = true;
            this.lblCédula.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.lblCédula.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblCédula.Location = new System.Drawing.Point(214, 135);
            this.lblCédula.Name = "lblCédula";
            this.lblCédula.Size = new System.Drawing.Size(52, 15);
            this.lblCédula.TabIndex = 74;
            this.lblCédula.Text = "Cédula";
            // 
            // txtPhoneUsers
            // 
            this.txtPhoneUsers.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtPhoneUsers.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPhoneUsers.ForeColor = System.Drawing.Color.White;
            this.txtPhoneUsers.Location = new System.Drawing.Point(32, 158);
            this.txtPhoneUsers.MaxLength = 11;
            this.txtPhoneUsers.Name = "txtPhoneUsers";
            this.txtPhoneUsers.Size = new System.Drawing.Size(123, 26);
            this.txtPhoneUsers.TabIndex = 5;
            this.txtPhoneUsers.TextChanged += new System.EventHandler(this.txtPhoneUsers_TextChanged);
            // 
            // lblDirección
            // 
            this.lblDirección.AutoSize = true;
            this.lblDirección.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.lblDirección.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblDirección.Location = new System.Drawing.Point(59, 190);
            this.lblDirección.Name = "lblDirección";
            this.lblDirección.Size = new System.Drawing.Size(68, 15);
            this.lblDirección.TabIndex = 72;
            this.lblDirección.Text = "Dirección";
            // 
            // txtAdressUsers
            // 
            this.txtAdressUsers.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtAdressUsers.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAdressUsers.ForeColor = System.Drawing.Color.White;
            this.txtAdressUsers.Location = new System.Drawing.Point(32, 212);
            this.txtAdressUsers.Name = "txtAdressUsers";
            this.txtAdressUsers.Size = new System.Drawing.Size(123, 26);
            this.txtAdressUsers.TabIndex = 6;
            this.txtAdressUsers.TextChanged += new System.EventHandler(this.txtAdressUsers_TextChanged_1);
            // 
            // lblPhone
            // 
            this.lblPhone.AutoSize = true;
            this.lblPhone.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.lblPhone.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblPhone.Location = new System.Drawing.Point(61, 135);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Size = new System.Drawing.Size(63, 15);
            this.lblPhone.TabIndex = 70;
            this.lblPhone.Text = "Teléfono";
            // 
            // txtSurnameUsers
            // 
            this.txtSurnameUsers.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtSurnameUsers.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSurnameUsers.ForeColor = System.Drawing.Color.White;
            this.txtSurnameUsers.Location = new System.Drawing.Point(178, 106);
            this.txtSurnameUsers.Name = "txtSurnameUsers";
            this.txtSurnameUsers.Size = new System.Drawing.Size(123, 26);
            this.txtSurnameUsers.TabIndex = 4;
            this.txtSurnameUsers.TextChanged += new System.EventHandler(this.txtSurnameUsers_TextChanged);
            // 
            // lblApellido
            // 
            this.lblApellido.AutoSize = true;
            this.lblApellido.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.lblApellido.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblApellido.Location = new System.Drawing.Point(209, 82);
            this.lblApellido.Name = "lblApellido";
            this.lblApellido.Size = new System.Drawing.Size(59, 15);
            this.lblApellido.TabIndex = 68;
            this.lblApellido.Text = "Apellido";
            // 
            // txtNameUsers
            // 
            this.txtNameUsers.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtNameUsers.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtNameUsers.ForeColor = System.Drawing.Color.White;
            this.txtNameUsers.Location = new System.Drawing.Point(178, 52);
            this.txtNameUsers.Name = "txtNameUsers";
            this.txtNameUsers.Size = new System.Drawing.Size(123, 26);
            this.txtNameUsers.TabIndex = 3;
            this.txtNameUsers.TextChanged += new System.EventHandler(this.txtNameUsers_TextChanged);
            // 
            // lblNombre
            // 
            this.lblNombre.AutoSize = true;
            this.lblNombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.lblNombre.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblNombre.Location = new System.Drawing.Point(210, 29);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(58, 15);
            this.lblNombre.TabIndex = 66;
            this.lblNombre.Text = "Nombre";
            // 
            // pnlTopBorder
            // 
            this.pnlTopBorder.BackColor = System.Drawing.Color.Transparent;
            this.pnlTopBorder.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTopBorder.Location = new System.Drawing.Point(0, 0);
            this.pnlTopBorder.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pnlTopBorder.Name = "pnlTopBorder";
            this.pnlTopBorder.Size = new System.Drawing.Size(335, 23);
            this.pnlTopBorder.TabIndex = 85;
            this.pnlTopBorder.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlTopBorder_MouseDown);
            this.pnlTopBorder.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pnlTopBorder_MouseMove);
            this.pnlTopBorder.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pnlTopBorder_MouseUp);
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.btnCancel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.btnCancel.Location = new System.Drawing.Point(217, 258);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(84, 28);
            this.btnCancel.TabIndex = 86;
            this.btnCancel.Text = "Cancelar";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // AddUsers
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(234)))), ((int)(((byte)(199)))));
            this.ClientSize = new System.Drawing.Size(335, 305);
            this.ControlBox = false;
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.pnlTopBorder);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtPasswordUsers);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtUsersNameCode);
            this.Controls.Add(this.btnAddUsers);
            this.Controls.Add(this.txtIDUsers);
            this.Controls.Add(this.lblCédula);
            this.Controls.Add(this.txtPhoneUsers);
            this.Controls.Add(this.lblDirección);
            this.Controls.Add(this.txtAdressUsers);
            this.Controls.Add(this.lblPhone);
            this.Controls.Add(this.txtSurnameUsers);
            this.Controls.Add(this.lblApellido);
            this.Controls.Add(this.txtNameUsers);
            this.Controls.Add(this.lblNombre);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximumSize = new System.Drawing.Size(730, 500);
            this.Name = "AddUsers";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderUsers1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderUsers2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ErrorProvider errorProviderUsers1;
        private System.Windows.Forms.ErrorProvider errorProviderUsers2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtPasswordUsers;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtUsersNameCode;
        private System.Windows.Forms.Button btnAddUsers;
        private System.Windows.Forms.TextBox txtIDUsers;
        private System.Windows.Forms.Label lblCédula;
        private System.Windows.Forms.TextBox txtPhoneUsers;
        private System.Windows.Forms.Label lblDirección;
        private System.Windows.Forms.TextBox txtAdressUsers;
        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.TextBox txtSurnameUsers;
        private System.Windows.Forms.Label lblApellido;
        private System.Windows.Forms.TextBox txtNameUsers;
        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.Panel pnlTopBorder;
        private System.Windows.Forms.Button btnCancel;
    }
}