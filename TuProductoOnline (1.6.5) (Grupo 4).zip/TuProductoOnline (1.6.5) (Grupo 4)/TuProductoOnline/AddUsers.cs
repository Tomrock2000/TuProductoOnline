﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TuProductoOnline
{
    public partial class AddUsers : Form
    {
        bool modifyadmin = false;
        public AddUsers(bool isadmin)
        {
            modifyadmin = isadmin;
            InitializeComponent();
           
        }
        private void btnAddUsers_Click(object sender, EventArgs e)
        {
            DelteErrorProviderUsers();
            if (CheckerUsers())
            {
                if (modifyadmin == false)
                {
                    var usersFromFile = GetUsersFromFile();
                    var users = JsonConvert.DeserializeObject<List<Employee>>(usersFromFile);
                    DialogResult result = MessageBox.Show("¿Está seguro de que desea añadir este Usuario?", "Confirmación", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (result == DialogResult.Yes)
                    {
                        int count = 0;
                        foreach (Employee user in users.ToList())
                        {
                            if (txtIDUsers.Text == user.Id.ToString())
                            {
                                count++;
                            }

                        }
                        if (count >= 1)
                        {
                            MessageBox.Show("Este Usuario ya esta registrado");   //Si existe el usario
                        }
                        else
                        {


                            if (users == null)
                            {
                                List<Employee> employees = new List<Employee>
                        {
                           new Employee()
                           {
                               Name =  txtNameUsers.Text,
                               LastName = txtSurnameUsers.Text,
                               Id = long.Parse(txtIDUsers.Text),
                               Phone = long.Parse(txtPhoneUsers.Text),
                               Address = txtAdressUsers.Text,
                               User = txtUsersNameCode.Text,
                               Password = long.Parse(txtPasswordUsers.Text),
                           }
                        };
                                string userslist = JsonConvert.SerializeObject(employees.ToArray(), Formatting.Indented);
                                File.WriteAllText(_pathusers, userslist);

                            }
                            else
                            {

                                Employee employee = new Employee
                                {
                                    Name = txtNameUsers.Text,
                                    LastName = txtSurnameUsers.Text,
                                    Id = long.Parse(txtIDUsers.Text),
                                    Phone = long.Parse(txtPhoneUsers.Text),
                                    Address = txtAdressUsers.Text,
                                    User = txtUsersNameCode.Text,
                                    Password = long.Parse(txtPasswordUsers.Text),
                                };
                                users.Add(employee);
                                string userslist = JsonConvert.SerializeObject(users.ToArray(), Formatting.Indented);
                                File.WriteAllText(_pathusers, userslist);

                            }
                            UserManageMenu us = new UserManageMenu();
                            foreach (Form form in Application.OpenForms)
                            {
                                if (form is UserManageMenu)
                                {
                                    us = (UserManageMenu)form;
                                    break;
                                }
                            }
                            us.UsersLoad();
                        }
                    }
                }
                if (modifyadmin == true)
                {
                    var adminsfromfile = GetAdminsFromFile();//Aplica el metodo antes mencionado
                    var admins = JsonConvert.DeserializeObject<List<Admin>>(adminsfromfile);
                    DialogResult result = MessageBox.Show("¿Está seguro de que desea añadir este Admin?", "Confirmación", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (result == DialogResult.Yes)
                    {
                        int count = 0;
                        if (admins != null)
                        {
                            foreach (Admin admin in admins.ToList())
                            {
                                if (txtIDUsers.Text == admin.Id.ToString())
                                {
                                    count++;
                                }

                            }
                        }
                        if (count >= 1)
                        {
                            MessageBox.Show("Este Admin ya esta registrado");   //Si existe el usario
                        }
                        else
                        {


                            if (admins == null)
                            {
                                List<Admin> admin = new List<Admin>
                        {
                           new Admin()
                           {
                               Name =  txtNameUsers.Text,
                               LastName = txtSurnameUsers.Text,
                               Id = long.Parse(txtIDUsers.Text),
                               Phone = long.Parse(txtPhoneUsers.Text),
                               Address = txtAdressUsers.Text,
                               User = txtUsersNameCode.Text,
                               Password = long.Parse(txtPasswordUsers.Text),
                           }
                        };
                                string adminslist = JsonConvert.SerializeObject(admin.ToArray(), Formatting.Indented);
                                File.WriteAllText(_pathadmin, adminslist);

                            }
                            else
                            {

                                Admin admin=new Admin
                                {
                                    Name = txtNameUsers.Text,
                                    LastName = txtSurnameUsers.Text,
                                    Id = long.Parse(txtIDUsers.Text),
                                    Phone = long.Parse(txtPhoneUsers.Text),
                                    Address = txtAdressUsers.Text,
                                    User = txtUsersNameCode.Text,
                                    Password = long.Parse(txtPasswordUsers.Text),
                                };
                                admins.Add(admin);
                                string adminslist = JsonConvert.SerializeObject(admins.ToArray(), Formatting.Indented);
                                File.WriteAllText(_pathadmin, adminslist);

                            }
                            UserManageMenu us = new UserManageMenu();
                            foreach (Form form in Application.OpenForms)
                            {
                                if (form is UserManageMenu)
                                {
                                    us = (UserManageMenu)form;
                                    break;
                                }
                            }
                            us.AdminsLoad();
                            this.Close();
                        }
                    }
                }
            }
            
        }

        private static string _pathusers = Path.GetFullPath(Path.Combine(Application.StartupPath, "..\\..", "Users.json"));
        public static string _pathadmin = Path.GetFullPath(Path.Combine(Application.StartupPath, "..\\..", "Admins.json"));
        private static string GetUsersFromFile()
        {
            string UsersJsonFromFile;
            using (var reader = new StreamReader(_pathusers))
            {
                UsersJsonFromFile = reader.ReadToEnd();
            }
            return UsersJsonFromFile;
        }
        public static string GetAdminsFromFile()//Este metodo lee el json y lo guarda en una variable
        {
            string adminsJsonfromFile;//Declara la variable en la que se guardará el json
            using (var reader = new StreamReader(_pathadmin))//Mediante el lector, se leerá todo el json y lo guardará en la variable
            {
                adminsJsonfromFile = reader.ReadToEnd();
            }
            return adminsJsonfromFile;//Devuelve el valor de la variable, que sería la lectura del json
        }


        public void DelteErrorProviderUsers()
        {
            errorProviderUsers1.SetError(txtNameUsers, "");
            errorProviderUsers1.SetError(txtSurnameUsers, "");
            errorProviderUsers1.SetError(txtIDUsers, "");
            errorProviderUsers1.SetError(txtPhoneUsers, "");
            errorProviderUsers1.SetError(txtAdressUsers, "");
            errorProviderUsers1.SetError(txtUsersNameCode, "");
            errorProviderUsers1.SetError(txtPasswordUsers, "");
        }


        public bool CheckerUsers()
        {
            bool validar = true;
            if (txtNameUsers.Text == string.Empty)
            {
                validar = false;
                errorProviderUsers1.SetError(txtNameUsers, "Ingresar un Nombre");
            }
            if (txtPhoneUsers.Text == string.Empty)
            {
                validar = false;
                errorProviderUsers1.SetError(txtPhoneUsers, "Ingresar un Telefono");
            }
            if (txtIDUsers.Text == string.Empty)
            {
                validar = false;
                errorProviderUsers1.SetError(txtIDUsers, "Ingresar un ID");
            }
            if (txtSurnameUsers.Text == string.Empty)
            {
                validar = false;
                errorProviderUsers1.SetError(txtSurnameUsers, "Ingresar un Apellido");
            }
            if (txtAdressUsers.Text == string.Empty)
            {
                validar = false;
                errorProviderUsers1.SetError(txtAdressUsers, "Ingresar una Direccion");
            }
            if(txtUsersNameCode.Text == string.Empty)
            {
                validar = false;
                errorProviderUsers1.SetError(txtUsersNameCode, "Ingrese un Usuario");
            }
            if (txtPasswordUsers.Text == string.Empty)
            {
                validar = false;
                errorProviderUsers1.SetError(txtPasswordUsers, "Ingrese una contraseña");
            }
            return validar;
        }
        private void ChechCampos()
        {
            long validationIDclient;
            bool IDValido = long.TryParse(txtIDUsers.Text, out validationIDclient);
            bool nombreValido = ValidarNombre(txtNameUsers.Text);
            bool apellidoValido = ValidarApellido(txtSurnameUsers.Text);
            bool telefonoValido = ValidarTelefono(txtPhoneUsers.Text);
            bool direccionValida = ValidarDireccion(txtAdressUsers.Text);
            bool usuarioValido = ValidarUsuario(txtUsersNameCode.Text);
            bool contraseñaValido = ValidarContraseña(txtPasswordUsers.Text);

            if (IDValido && nombreValido && apellidoValido && telefonoValido && direccionValida && usuarioValido && contraseñaValido)
            {
                btnAddUsers.Enabled = true;
                errorProviderUsers1.Clear();
            }
            else
            {
                btnAddUsers.Enabled = false;
                errorProviderUsers1.SetError(btnAddUsers, "Por favor, complete todos los campos correctamente.");
                if (!nombreValido)
                {
                    errorProviderUsers1.SetError(txtNameUsers, "El nombre solo debe contener letras y espacios.");
                }
                if (!apellidoValido)
                {
                    errorProviderUsers1.SetError(txtSurnameUsers, "El apellido solo debe contener letras y espacios.");
                }
                if (!IDValido)
                {
                    errorProviderUsers1.SetError(txtIDUsers, "El ID solo debe contener números.");
                }
                if (!telefonoValido)
                {
                    errorProviderUsers1.SetError(txtPhoneUsers, "El número de teléfono solo debe contener números.");
                }
                if (!direccionValida)
                {
                    errorProviderUsers1.SetError(txtAdressUsers, "La dirección no es válida.");
                }
                if (!usuarioValido)
                {
                    errorProviderUsers1.SetError(txtUsersNameCode, "El usuario solo puede contener letras y numeros sin espacios");
                }
                if (!contraseñaValido)
                {
                    errorProviderUsers1.SetError(txtPasswordUsers, "Ingrese solo Numeros");
                }
            }
        }
        private bool ValidarNombre(string nombre)
        {
            foreach (char c in nombre)
            {
                if (!Char.IsLetter(c) && !Char.IsWhiteSpace(c))
                {
                    return false;
                }
            }
            return true;
        }

        private bool ValidarApellido(string apellido)
        {
            foreach (char c in apellido)
            {
                if (!Char.IsLetter(c) && !Char.IsWhiteSpace(c))
                {
                    return false;
                }
            }
            return true;
        }

        private bool ValidarTelefono(string telefono)
        {
            foreach (char c in telefono)
            {
                if (!Char.IsDigit(c))
                {
                    return false;
                }
            }
            return true;
        }

        private bool ValidarDireccion(string direccion)
        {
            foreach (char c in direccion)
            {
                if (!Char.IsLetterOrDigit(c) && !Char.IsWhiteSpace(c) && !Char.IsPunctuation(c))
                {
                    return false;
                }
            }
            return true;
        }
        private bool ValidarUsuario(string direccion)
        {
            foreach (char c in direccion)
            {
                if (!Char.IsLetterOrDigit(c))
                {
                    return false;
                }
            }
            return true;
        }
        private bool ValidarContraseña(string direccion)
        {
            foreach (char c in direccion)
            {
                if (!Char.IsDigit(c))
                {
                    return false;
                }
            }
            return true;
        }
        private void txtUsersNameCode_TextChanged(object sender, EventArgs e)
        {
            ChechCampos();
        }

        private void txtPasswordUsers_TextChanged(object sender, EventArgs e)
        {
            ChechCampos();
        }
        private void txtNameUsers_TextChanged(object sender, EventArgs e)
        {
            ChechCampos();
        }
        private void txtSurnameUsers_TextChanged(object sender, EventArgs e)
        {
            ChechCampos();
        }
        private void txtPhoneUsers_TextChanged(object sender, EventArgs e)
        {
            ChechCampos();
        }
        private void txtAdressUsers_TextChanged_1(object sender, EventArgs e)
        {
            ChechCampos();
        }
        private void txtIDUsers_TextChanged(object sender, EventArgs e)
        {
            ChechCampos();
        }
        
        int m, mx, my;
        private void pnlTopBorder_MouseDown(object sender, MouseEventArgs e)
        {
            m = 1;
            mx = e.X;
            my = e.Y;
        }

        private void btnComeAddUsers_Click_1(object sender, EventArgs e)
        {
            this.Close();
            UserManageMenu.ActiveForm.Show();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pnlTopBorder_MouseMove(object sender, MouseEventArgs e)
        {

        }

        private void pnlTopBorder_MouseUp(object sender, MouseEventArgs e)
        {
            m = 0;
        }
    }
}
