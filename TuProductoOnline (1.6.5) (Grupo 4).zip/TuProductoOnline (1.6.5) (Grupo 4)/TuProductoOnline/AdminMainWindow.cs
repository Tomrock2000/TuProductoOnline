﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TuProductoOnline
{
    public partial class AdminMainWindow : Form
    {
        public AdminMainWindow()
        {
            InitializeComponent();
        }
        int m, mx, my;
        private void pbClose_Click(object sender, EventArgs e)
        {
            foreach (Form form in Application.OpenForms.Cast<Form>().ToList())
            {
                form.Close();
            }
        }

        private void pbMaximize_Click(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Normal)
            {
                this.WindowState = FormWindowState.Maximized;
            }
            else
            {
                this.WindowState = FormWindowState.Normal;
            }

        }

        private void pbMinimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void pnlTopBorder_MouseDown(object sender, MouseEventArgs e)
        {
            m = 1;
            mx = e.X;
            my = e.Y;
        }

        private void btExitMainMenu_Click(object sender, EventArgs e)
        {
            foreach (Form form in Application.OpenForms.Cast<Form>().ToList())
            {
                form.Close();
            }
        }

        private void btnMaximize_Click(object sender, EventArgs e)
        {
            btnMaximize.Visible = false;
            btnRestore.Visible = true;
            this.WindowState = FormWindowState.Maximized;

        }

        private void btnMinimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnRestore_Click(object sender, EventArgs e)
        {
            btnRestore.Visible = false;
            btnMaximize.Visible = true;
            this.WindowState = FormWindowState.Normal;
        }
        //Timers para la animacion
        private void tmHideMenu_Tick(object sender, EventArgs e)
        {
            if (panelMenu.Width <= 60)
            {
                tmHideMenu.Enabled = false;
            }
            else
            {
                this.panelMenu.Width = this.panelMenu.Width - 15;
            }
        }

        private void tmShowMenu_Tick(object sender, EventArgs e)
        {
            if (panelMenu.Width >= 160)
            {
                tmShowMenu.Enabled = false;
            }
            else
            {
                this.panelMenu.Width = this.panelMenu.Width + 15;
            }
        }

        private void pbMenu_Click(object sender, EventArgs e)
        {
            tmHideMenu.Enabled = true;
            pbMenu.Visible = false;
            pbMenu2.Visible = false;
        }

        private void pbMenu2_Click(object sender, EventArgs e)
        {
            tmShowMenu.Enabled = true;
            pbMenu2.Visible = false;
            pbMenu.Visible = true;


        }



        //Fin del codigo de los timers

        private void pnlTopBorder_MouseMove(object sender, MouseEventArgs e)
        {
            if (m == 1)
            {
                this.SetDesktopLocation(MousePosition.X - mx, MousePosition.Y - my);
            }
        }

        private void pnlTopBorder_MouseUp(object sender, MouseEventArgs e)
        {
            m = 0;
        }

        private void btnProductManage_MouseEnter(object sender, EventArgs e)
        {
            pnlProductManage.BackColor = Color.FromArgb(142, 139, 250);
        }

        private void btnProductManage_MouseLeave(object sender, EventArgs e)
        {
            pnlProductManage.BackColor = Color.FromArgb(107, 103, 248);
        }

        private void btnManageClient_MouseEnter(object sender, EventArgs e)
        {
            pnlClientManage.BackColor = Color.FromArgb(142, 139, 250);
        }

        private void btnManageClient_MouseLeave(object sender, EventArgs e)
        {
            pnlClientManage.BackColor = Color.FromArgb(107, 103, 248);
        }

        private void btnNewSale_MouseEnter(object sender, EventArgs e)
        {
            pnlNewSale.BackColor = Color.FromArgb(142, 139, 250);
        }

        private void btnNewSale_MouseLeave(object sender, EventArgs e)
        {
            pnlNewSale.BackColor = Color.FromArgb(107, 103, 248);
        }
        private void btnUserManage_MouseEnter(object sender, EventArgs e)
        {
            pnlUserManage.BackColor = Color.FromArgb(142, 139, 250);
        }
        private void btnUserManage_MouseLeave(object sender, EventArgs e)
        {
            pnlUserManage.BackColor = Color.FromArgb(107, 103, 248);
        }
        private void btnRecordsMenu_MouseEnter(object sender, EventArgs e)
        {
            pnlRecordsMenu.BackColor = Color.FromArgb(142, 139, 250);
        }

        private void btnRecordsMenu_MouseLeave(object sender, EventArgs e)
        {
            pnlRecordsMenu.BackColor = Color.FromArgb(107, 103, 248);
        }

        private void pnlLogOut_MouseEnter(object sender, EventArgs e)
        {
            pnlLogOut.BackColor = Color.FromArgb(142, 139, 250);
        }

        private void pnlLogOut_MouseLeave(object sender, EventArgs e)
        {
            pnlLogOut.BackColor = Color.FromArgb(107, 103, 248);
        }

        private void btnMainMenu_MouseEnter(object sender, EventArgs e)
        {
            pnlMainWindow.BackColor = Color.FromArgb(142, 139, 250);
        }

        private void btnMainMenu_MouseLeave(object sender, EventArgs e)
        {
            pnlMainWindow.BackColor = Color.FromArgb(107, 103, 248);
        }

        private void pbMenu_MouseEnter(object sender, EventArgs e)
        {
            pbMenu.BackColor = Color.FromArgb(78, 73, 73);
        }

        private void pbMenu_MouseLeave(object sender, EventArgs e)
        {
            pbMenu.BackColor = Color.FromArgb(51, 48, 48);
        }

        private void pbLogo_MouseEnter(object sender, EventArgs e)
        {
            pbLogo.BackColor = Color.FromArgb(78, 73, 73);
        }

        private void btnProductManage_Click(object sender, EventArgs e)
        {

            foreach (Form form in Application.OpenForms)
            {

                if (form is ProductManageMenu)
                {
                    OpenNewForm(form);
                    return;
                }

            }
            OpenNewForm(new ProductManageMenu());
            /*pnlMainMenu.BackColor = Color.FromArgb(107, 103, 248);
              btnMainMenu.FlatAppearance.MouseDownBackColor = Color.FromArgb(107, 103, 248);
              btnMainMenu.FlatAppearance.MouseOverBackColor = Color.FromArgb(142, 139, 250);
              pnlProductManage.BackColor = Color.FromArgb(248, 234, 199);
              btnProductManage.FlatAppearance.MouseOverBackColor = Color.White;*/
        }

        private void btnMainMenu_Click(object sender, EventArgs e)
        {

            foreach (Form form in Application.OpenForms)
            {

                if (form is MainMenu)
                {
                    OpenNewForm(form);
                    return;
                }

            }
            OpenNewForm(new MainMenu());
        }

        private void MainWindow_Load(object sender, EventArgs e)
        {

            foreach (Form form in Application.OpenForms)
            {

                if (form is MainMenu)
                {
                    OpenNewForm(form);
                    return;
                }

            }
            OpenNewForm(new MainMenu());
        }

        private void btnManageClient_Click(object sender, EventArgs e)
        {
            foreach (Form form in Application.OpenForms)
            {

                if (form is ClientManageMenu)
                {
                    OpenNewForm(form);
                    return;
                }

            }
            OpenNewForm(new ClientManageMenu());
        }

        private void btnNewSale_Click(object sender, EventArgs e)
        {

            foreach (Form form in Application.OpenForms)
            {

                if (form is NewSaleMenu)
                {
                    OpenNewForm(form);
                    return;
                }

            }
            OpenNewForm(new NewSaleMenu());

        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {

            NewSaleMenu newsalemenu = new NewSaleMenu(); ;
            foreach (Form form in Application.OpenForms)
            {
                if (form is NewSaleMenu)
                {
                    newsalemenu = (NewSaleMenu)form;
                    break;
                }
            }
            if (newsalemenu.ValidateCloseSession() == false)
            {
                MessageBox.Show("Elimine todos los productos de el carrito antes de cerrar sesión");
            }
            else
            {
                if (MessageBox.Show("¿Está seguro que desea cerrar sesión?", "Cerrar Sesión", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    LoginMenu.SessionClose();
                    LoginMenu.SessionCloseAdmin();

                    foreach (Form form in Application.OpenForms.Cast<Form>().ToList())
                    {

                        if (form is LoginMenu)
                        {

                            form.Show();

                        }
                        if (!(form is LoginMenu) && !(form is MainWindow))
                        {
                            form.Close();
                        }
                    }

                    this.Close();
                }
            }
        }

        private void btnUserManage_Click(object sender, EventArgs e)
        {
            OpenNewForm(new UserManageMenu());
        }

        private void btnRecordsMenu_Click(object sender, EventArgs e)
        {
            OpenNewForm(new RecordsMenu());
        }

        private void AdminMainWindow_Load(object sender, EventArgs e)
        {
            OpenNewForm(new MainMenu());
        }

        private void pbLogo_MouseLeave(object sender, EventArgs e)
        {
            pbLogo.BackColor = Color.FromArgb(51, 48, 48);
        }

        private void OpenNewForm(object form)
        {
            if (this.pnlBackground.Controls.Count > 0)
                pnlBackground.Controls.Clear();
            Form newform = form as Form;
            newform.TopLevel = false;
            newform.Dock = DockStyle.Fill;
            this.pnlBackground.Controls.Add(newform);
            this.pnlBackground.Tag = newform;
            newform.Show();
        }
    }
}

