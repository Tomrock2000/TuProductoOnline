﻿namespace TuProductoOnline
{
    partial class Billing
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Billing));
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtIVA = new System.Windows.Forms.TextBox();
            this.lblIVA = new System.Windows.Forms.Label();
            this.pbLogo = new System.Windows.Forms.PictureBox();
            this.txtBillId = new System.Windows.Forms.TextBox();
            this.lblThanks = new System.Windows.Forms.Label();
            this.txtTotalCost = new System.Windows.Forms.TextBox();
            this.lblTotalCost = new System.Windows.Forms.Label();
            this.txtRetained = new System.Windows.Forms.TextBox();
            this.lblRetained = new System.Windows.Forms.Label();
            this.txtSubTotal = new System.Windows.Forms.TextBox();
            this.lblSubtotal = new System.Windows.Forms.Label();
            this.dtgvBill = new System.Windows.Forms.DataGridView();
            this.BillProductCantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BillProductName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BillProductDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BillUnitaryPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtClientAddress = new System.Windows.Forms.TextBox();
            this.txtClientPhone = new System.Windows.Forms.TextBox();
            this.txtClientId = new System.Windows.Forms.TextBox();
            this.txtClientName = new System.Windows.Forms.TextBox();
            this.txtEmployeeName = new System.Windows.Forms.TextBox();
            this.txtTime = new System.Windows.Forms.TextBox();
            this.txtDateTime = new System.Windows.Forms.TextBox();
            this.lblClientAddress = new System.Windows.Forms.Label();
            this.lblClientPhone = new System.Windows.Forms.Label();
            this.lblClientId = new System.Windows.Forms.Label();
            this.lblClientName = new System.Windows.Forms.Label();
            this.lblEmployeeName = new System.Windows.Forms.Label();
            this.lblTime = new System.Windows.Forms.Label();
            this.lblDateTime = new System.Windows.Forms.Label();
            this.lblBillId = new System.Windows.Forms.Label();
            this.lblCompanyName = new System.Windows.Forms.Label();
            this.pnlTopBorder = new System.Windows.Forms.Panel();
            this.btnExit = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbLogo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvBill)).BeginInit();
            this.pnlTopBorder.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.txtIVA);
            this.panel1.Controls.Add(this.lblIVA);
            this.panel1.Controls.Add(this.pbLogo);
            this.panel1.Controls.Add(this.txtBillId);
            this.panel1.Controls.Add(this.lblThanks);
            this.panel1.Controls.Add(this.txtTotalCost);
            this.panel1.Controls.Add(this.lblTotalCost);
            this.panel1.Controls.Add(this.txtRetained);
            this.panel1.Controls.Add(this.lblRetained);
            this.panel1.Controls.Add(this.txtSubTotal);
            this.panel1.Controls.Add(this.lblSubtotal);
            this.panel1.Controls.Add(this.dtgvBill);
            this.panel1.Controls.Add(this.txtClientAddress);
            this.panel1.Controls.Add(this.txtClientPhone);
            this.panel1.Controls.Add(this.txtClientId);
            this.panel1.Controls.Add(this.txtClientName);
            this.panel1.Controls.Add(this.txtEmployeeName);
            this.panel1.Controls.Add(this.txtTime);
            this.panel1.Controls.Add(this.txtDateTime);
            this.panel1.Controls.Add(this.lblClientAddress);
            this.panel1.Controls.Add(this.lblClientPhone);
            this.panel1.Controls.Add(this.lblClientId);
            this.panel1.Controls.Add(this.lblClientName);
            this.panel1.Controls.Add(this.lblEmployeeName);
            this.panel1.Controls.Add(this.lblTime);
            this.panel1.Controls.Add(this.lblDateTime);
            this.panel1.Controls.Add(this.lblBillId);
            this.panel1.Controls.Add(this.lblCompanyName);
            this.panel1.Location = new System.Drawing.Point(1, -2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(600, 669);
            this.panel1.TabIndex = 0;
            // 
            // txtIVA
            // 
            this.txtIVA.BackColor = System.Drawing.SystemColors.Control;
            this.txtIVA.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtIVA.Location = new System.Drawing.Point(87, 555);
            this.txtIVA.Name = "txtIVA";
            this.txtIVA.Size = new System.Drawing.Size(100, 13);
            this.txtIVA.TabIndex = 31;
            this.txtIVA.Text = "-";
            // 
            // lblIVA
            // 
            this.lblIVA.AutoSize = true;
            this.lblIVA.Location = new System.Drawing.Point(33, 555);
            this.lblIVA.Name = "lblIVA";
            this.lblIVA.Size = new System.Drawing.Size(53, 13);
            this.lblIVA.TabIndex = 30;
            this.lblIVA.Text = "IVA=16%:";
            // 
            // pbLogo
            // 
            this.pbLogo.Image = global::TuProductoOnline.Properties.Resources.Logo__TuProductoOnline_;
            this.pbLogo.Location = new System.Drawing.Point(508, 27);
            this.pbLogo.Name = "pbLogo";
            this.pbLogo.Size = new System.Drawing.Size(70, 83);
            this.pbLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbLogo.TabIndex = 29;
            this.pbLogo.TabStop = false;
            // 
            // txtBillId
            // 
            this.txtBillId.BackColor = System.Drawing.SystemColors.Control;
            this.txtBillId.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtBillId.Location = new System.Drawing.Point(283, 45);
            this.txtBillId.Name = "txtBillId";
            this.txtBillId.Size = new System.Drawing.Size(100, 13);
            this.txtBillId.TabIndex = 28;
            this.txtBillId.Text = "-";
            // 
            // lblThanks
            // 
            this.lblThanks.AutoSize = true;
            this.lblThanks.Location = new System.Drawing.Point(195, 635);
            this.lblThanks.Name = "lblThanks";
            this.lblThanks.Size = new System.Drawing.Size(219, 13);
            this.lblThanks.TabIndex = 27;
            this.lblThanks.Text = "¡Gracias por realizar su compra con nosotros!";
            // 
            // txtTotalCost
            // 
            this.txtTotalCost.BackColor = System.Drawing.SystemColors.Control;
            this.txtTotalCost.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTotalCost.Location = new System.Drawing.Point(72, 600);
            this.txtTotalCost.Name = "txtTotalCost";
            this.txtTotalCost.Size = new System.Drawing.Size(100, 13);
            this.txtTotalCost.TabIndex = 26;
            this.txtTotalCost.Text = "-";
            // 
            // lblTotalCost
            // 
            this.lblTotalCost.AutoSize = true;
            this.lblTotalCost.Location = new System.Drawing.Point(33, 600);
            this.lblTotalCost.Name = "lblTotalCost";
            this.lblTotalCost.Size = new System.Drawing.Size(34, 13);
            this.lblTotalCost.TabIndex = 25;
            this.lblTotalCost.Text = "Total:";
            // 
            // txtRetained
            // 
            this.txtRetained.BackColor = System.Drawing.SystemColors.Control;
            this.txtRetained.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtRetained.Location = new System.Drawing.Point(94, 578);
            this.txtRetained.Name = "txtRetained";
            this.txtRetained.Size = new System.Drawing.Size(100, 13);
            this.txtRetained.TabIndex = 24;
            this.txtRetained.Text = "-";
            // 
            // lblRetained
            // 
            this.lblRetained.AutoSize = true;
            this.lblRetained.Location = new System.Drawing.Point(33, 577);
            this.lblRetained.Name = "lblRetained";
            this.lblRetained.Size = new System.Drawing.Size(59, 13);
            this.lblRetained.TabIndex = 23;
            this.lblRetained.Text = "Retención:";
            // 
            // txtSubTotal
            // 
            this.txtSubTotal.BackColor = System.Drawing.SystemColors.Control;
            this.txtSubTotal.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtSubTotal.Location = new System.Drawing.Point(84, 534);
            this.txtSubTotal.Name = "txtSubTotal";
            this.txtSubTotal.Size = new System.Drawing.Size(100, 13);
            this.txtSubTotal.TabIndex = 22;
            this.txtSubTotal.Text = "-";
            // 
            // lblSubtotal
            // 
            this.lblSubtotal.AutoSize = true;
            this.lblSubtotal.Location = new System.Drawing.Point(33, 534);
            this.lblSubtotal.Name = "lblSubtotal";
            this.lblSubtotal.Size = new System.Drawing.Size(49, 13);
            this.lblSubtotal.TabIndex = 21;
            this.lblSubtotal.Text = "Subtotal:";
            // 
            // dtgvBill
            // 
            this.dtgvBill.AllowUserToAddRows = false;
            this.dtgvBill.AllowUserToDeleteRows = false;
            this.dtgvBill.AllowUserToResizeColumns = false;
            this.dtgvBill.AllowUserToResizeRows = false;
            this.dtgvBill.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dtgvBill.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dtgvBill.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dtgvBill.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvBill.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dtgvBill.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvBill.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.BillProductCantity,
            this.BillProductName,
            this.BillProductDescription,
            this.BillUnitaryPrice});
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dtgvBill.DefaultCellStyle = dataGridViewCellStyle6;
            this.dtgvBill.EnableHeadersVisualStyles = false;
            this.dtgvBill.GridColor = System.Drawing.SystemColors.Control;
            this.dtgvBill.Location = new System.Drawing.Point(22, 261);
            this.dtgvBill.Name = "dtgvBill";
            this.dtgvBill.ReadOnly = true;
            this.dtgvBill.RowHeadersVisible = false;
            this.dtgvBill.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dtgvBill.Size = new System.Drawing.Size(554, 248);
            this.dtgvBill.TabIndex = 20;
            // 
            // BillProductCantity
            // 
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            this.BillProductCantity.DefaultCellStyle = dataGridViewCellStyle2;
            this.BillProductCantity.Frozen = true;
            this.BillProductCantity.HeaderText = "Cantidad";
            this.BillProductCantity.Name = "BillProductCantity";
            this.BillProductCantity.ReadOnly = true;
            // 
            // BillProductName
            // 
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            this.BillProductName.DefaultCellStyle = dataGridViewCellStyle3;
            this.BillProductName.Frozen = true;
            this.BillProductName.HeaderText = "Producto";
            this.BillProductName.Name = "BillProductName";
            this.BillProductName.ReadOnly = true;
            this.BillProductName.Width = 150;
            // 
            // BillProductDescription
            // 
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            this.BillProductDescription.DefaultCellStyle = dataGridViewCellStyle4;
            this.BillProductDescription.Frozen = true;
            this.BillProductDescription.HeaderText = "Descripción del Producto";
            this.BillProductDescription.Name = "BillProductDescription";
            this.BillProductDescription.ReadOnly = true;
            this.BillProductDescription.Width = 200;
            // 
            // BillUnitaryPrice
            // 
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control;
            this.BillUnitaryPrice.DefaultCellStyle = dataGridViewCellStyle5;
            this.BillUnitaryPrice.Frozen = true;
            this.BillUnitaryPrice.HeaderText = "Precio Unitario Total";
            this.BillUnitaryPrice.Name = "BillUnitaryPrice";
            this.BillUnitaryPrice.ReadOnly = true;
            // 
            // txtClientAddress
            // 
            this.txtClientAddress.BackColor = System.Drawing.SystemColors.Control;
            this.txtClientAddress.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtClientAddress.Location = new System.Drawing.Point(94, 230);
            this.txtClientAddress.Name = "txtClientAddress";
            this.txtClientAddress.Size = new System.Drawing.Size(100, 13);
            this.txtClientAddress.TabIndex = 19;
            this.txtClientAddress.Text = "-";
            // 
            // txtClientPhone
            // 
            this.txtClientPhone.BackColor = System.Drawing.SystemColors.Control;
            this.txtClientPhone.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtClientPhone.Location = new System.Drawing.Point(91, 205);
            this.txtClientPhone.Name = "txtClientPhone";
            this.txtClientPhone.Size = new System.Drawing.Size(100, 13);
            this.txtClientPhone.TabIndex = 18;
            this.txtClientPhone.Text = "-";
            // 
            // txtClientId
            // 
            this.txtClientId.BackColor = System.Drawing.SystemColors.Control;
            this.txtClientId.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtClientId.Location = new System.Drawing.Point(62, 181);
            this.txtClientId.Name = "txtClientId";
            this.txtClientId.Size = new System.Drawing.Size(100, 13);
            this.txtClientId.TabIndex = 17;
            this.txtClientId.Text = "-";
            // 
            // txtClientName
            // 
            this.txtClientName.BackColor = System.Drawing.SystemColors.Control;
            this.txtClientName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtClientName.Location = new System.Drawing.Point(84, 157);
            this.txtClientName.Name = "txtClientName";
            this.txtClientName.Size = new System.Drawing.Size(100, 13);
            this.txtClientName.TabIndex = 16;
            this.txtClientName.Text = "-";
            // 
            // txtEmployeeName
            // 
            this.txtEmployeeName.BackColor = System.Drawing.SystemColors.Control;
            this.txtEmployeeName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtEmployeeName.Location = new System.Drawing.Point(114, 121);
            this.txtEmployeeName.Name = "txtEmployeeName";
            this.txtEmployeeName.Size = new System.Drawing.Size(100, 13);
            this.txtEmployeeName.TabIndex = 15;
            this.txtEmployeeName.Text = "-";
            // 
            // txtTime
            // 
            this.txtTime.BackColor = System.Drawing.SystemColors.Control;
            this.txtTime.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTime.Location = new System.Drawing.Point(72, 97);
            this.txtTime.Name = "txtTime";
            this.txtTime.Size = new System.Drawing.Size(100, 13);
            this.txtTime.TabIndex = 14;
            this.txtTime.Text = "-";
            // 
            // txtDateTime
            // 
            this.txtDateTime.BackColor = System.Drawing.SystemColors.Control;
            this.txtDateTime.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtDateTime.Location = new System.Drawing.Point(79, 71);
            this.txtDateTime.Name = "txtDateTime";
            this.txtDateTime.Size = new System.Drawing.Size(100, 13);
            this.txtDateTime.TabIndex = 13;
            this.txtDateTime.Text = "-";
            // 
            // lblClientAddress
            // 
            this.lblClientAddress.AutoSize = true;
            this.lblClientAddress.Location = new System.Drawing.Point(33, 230);
            this.lblClientAddress.Name = "lblClientAddress";
            this.lblClientAddress.Size = new System.Drawing.Size(55, 13);
            this.lblClientAddress.TabIndex = 8;
            this.lblClientAddress.Text = "Dirección:";
            // 
            // lblClientPhone
            // 
            this.lblClientPhone.AutoSize = true;
            this.lblClientPhone.Location = new System.Drawing.Point(33, 205);
            this.lblClientPhone.Name = "lblClientPhone";
            this.lblClientPhone.Size = new System.Drawing.Size(52, 13);
            this.lblClientPhone.TabIndex = 7;
            this.lblClientPhone.Text = "Teléfono:";
            // 
            // lblClientId
            // 
            this.lblClientId.AutoSize = true;
            this.lblClientId.Location = new System.Drawing.Point(33, 181);
            this.lblClientId.Name = "lblClientId";
            this.lblClientId.Size = new System.Drawing.Size(23, 13);
            this.lblClientId.TabIndex = 6;
            this.lblClientId.Text = "C.I:";
            // 
            // lblClientName
            // 
            this.lblClientName.AutoSize = true;
            this.lblClientName.Location = new System.Drawing.Point(33, 157);
            this.lblClientName.Name = "lblClientName";
            this.lblClientName.Size = new System.Drawing.Size(45, 13);
            this.lblClientName.TabIndex = 5;
            this.lblClientName.Text = "Cliente: ";
            // 
            // lblEmployeeName
            // 
            this.lblEmployeeName.AutoSize = true;
            this.lblEmployeeName.Location = new System.Drawing.Point(33, 121);
            this.lblEmployeeName.Name = "lblEmployeeName";
            this.lblEmployeeName.Size = new System.Drawing.Size(75, 13);
            this.lblEmployeeName.TabIndex = 4;
            this.lblEmployeeName.Text = "Realizada por:";
            // 
            // lblTime
            // 
            this.lblTime.AutoSize = true;
            this.lblTime.Location = new System.Drawing.Point(33, 97);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(33, 13);
            this.lblTime.TabIndex = 3;
            this.lblTime.Text = "Hora:";
            // 
            // lblDateTime
            // 
            this.lblDateTime.AutoSize = true;
            this.lblDateTime.Location = new System.Drawing.Point(33, 71);
            this.lblDateTime.Name = "lblDateTime";
            this.lblDateTime.Size = new System.Drawing.Size(40, 13);
            this.lblDateTime.TabIndex = 2;
            this.lblDateTime.Text = "Fecha:";
            // 
            // lblBillId
            // 
            this.lblBillId.AutoSize = true;
            this.lblBillId.Location = new System.Drawing.Point(216, 45);
            this.lblBillId.Name = "lblBillId";
            this.lblBillId.Size = new System.Drawing.Size(61, 13);
            this.lblBillId.TabIndex = 1;
            this.lblBillId.Text = "Factura N°:";
            // 
            // lblCompanyName
            // 
            this.lblCompanyName.AutoSize = true;
            this.lblCompanyName.Location = new System.Drawing.Point(251, 29);
            this.lblCompanyName.Name = "lblCompanyName";
            this.lblCompanyName.Size = new System.Drawing.Size(93, 13);
            this.lblCompanyName.TabIndex = 0;
            this.lblCompanyName.Text = "TuProductoOnline";
            // 
            // pnlTopBorder
            // 
            this.pnlTopBorder.BackColor = System.Drawing.Color.Transparent;
            this.pnlTopBorder.Controls.Add(this.btnExit);
            this.pnlTopBorder.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTopBorder.Location = new System.Drawing.Point(0, 0);
            this.pnlTopBorder.Name = "pnlTopBorder";
            this.pnlTopBorder.Size = new System.Drawing.Size(599, 28);
            this.pnlTopBorder.TabIndex = 89;
            this.pnlTopBorder.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlTopBorder_MouseDown);
            this.pnlTopBorder.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pnlTopBorder_MouseMove);
            this.pnlTopBorder.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pnlTopBorder_MouseUp);
            // 
            // btnExit
            // 
            this.btnExit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExit.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnExit.BackColor = System.Drawing.Color.Transparent;
            this.btnExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExit.FlatAppearance.BorderSize = 0;
            this.btnExit.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btnExit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExit.ForeColor = System.Drawing.Color.White;
            this.btnExit.Image = global::TuProductoOnline.Properties.Resources.Icono_Cerrar_Factura;
            this.btnExit.Location = new System.Drawing.Point(568, -2);
            this.btnExit.Margin = new System.Windows.Forms.Padding(2);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(30, 30);
            this.btnExit.TabIndex = 30;
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // Billing
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(599, 655);
            this.Controls.Add(this.pnlTopBorder);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Billing";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbLogo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvBill)).EndInit();
            this.pnlTopBorder.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblCompanyName;
        private System.Windows.Forms.Label lblThanks;
        private System.Windows.Forms.TextBox txtTotalCost;
        private System.Windows.Forms.Label lblTotalCost;
        private System.Windows.Forms.TextBox txtRetained;
        private System.Windows.Forms.Label lblRetained;
        private System.Windows.Forms.TextBox txtSubTotal;
        private System.Windows.Forms.Label lblSubtotal;
        private System.Windows.Forms.TextBox txtClientAddress;
        private System.Windows.Forms.TextBox txtClientPhone;
        private System.Windows.Forms.TextBox txtClientId;
        private System.Windows.Forms.TextBox txtClientName;
        private System.Windows.Forms.TextBox txtEmployeeName;
        private System.Windows.Forms.TextBox txtTime;
        private System.Windows.Forms.TextBox txtDateTime;
        private System.Windows.Forms.Label lblClientAddress;
        private System.Windows.Forms.Label lblClientPhone;
        private System.Windows.Forms.Label lblClientId;
        private System.Windows.Forms.Label lblClientName;
        private System.Windows.Forms.Label lblEmployeeName;
        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.Label lblDateTime;
        private System.Windows.Forms.Label lblBillId;
        private System.Windows.Forms.TextBox txtBillId;
        private System.Windows.Forms.DataGridView dtgvBill;
        private System.Windows.Forms.DataGridViewTextBoxColumn BillProductCantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn BillProductName;
        private System.Windows.Forms.DataGridViewTextBoxColumn BillProductDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn BillUnitaryPrice;
        private System.Windows.Forms.PictureBox pbLogo;
        private System.Windows.Forms.Panel pnlTopBorder;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.TextBox txtIVA;
        private System.Windows.Forms.Label lblIVA;
    }
}