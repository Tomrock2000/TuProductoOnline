﻿using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.tool.xml;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace TuProductoOnline
{
    public partial class Billing : Form
    {

        Bill bill = new Bill();//Instanciamos un objeto Bill que será nuestra factura
        public Billing(Employee employee, Client client, CarShop carshop, bool contributor)//Recibimos un Employee, un Client, un Carshop y un bool, los cuales representan los datos que asignaremos a la factura
        {
            bill.BillDate = DateTime.Today;//Le asignamos la fecha correspondiente de la factura a el atributo de fecha
           
            bill.ClientSale = client;//Asignamos el Client a el atributo de el cliente
            bill.EmployeSale = employee;//Asignamos el Employee a el atributo de empleado
            bill.ProductSale = carshop;//Asignamos el CarShop a el atributo de "ProductSale", que es un atributo CarShop
            bill.BillId = GetBillId();//Para la asignación del id de la factura, utilizamos la función GetBillId()
            bill.Contributor = contributor;//Asignamos el bool correspondiente para saber si es contribuidor o no
            InitializeComponent();
            MessageBox.Show("Por favor, eliga la ruta donde quiere guardar el archivo");
            LoadBillProducts();//Cargamos los datos a la factura
           GetBillPDF();//Imprimimos la factura en formato pdf
            WriteBill();//Escribimos la factura en el registro

        }
        private static string _pathusers = Path.GetFullPath(Path.Combine(Application.StartupPath, "..\\..", "Users.json"));
        public void AddSaleCount(float amount)
        {
            var usersfromfile = LoginMenu.GetUsersFromFile();
            var users = JsonConvert.DeserializeObject<List<Employee>>(usersfromfile);
            foreach (Employee employee in users)
            {
                if (employee.ActiveSession == true)
                {
                    employee.ConcludedSales++;
                    employee.BilledAmount += amount;
                }
            }
            string userslist = JsonConvert.SerializeObject(users.ToArray(), Formatting.Indented);
            File.WriteAllText(_pathusers, userslist);
        }
        private static string _pathbills = Path.GetFullPath(Path.Combine(Application.StartupPath, "..\\..", "BillsRegistry.json"));//Ruta de el json de registro de facturas
        
        public void WriteBill()//Añade la factura a el registro, el cual es una lista de facturas, esto si la lista ya existe y si no, crea una lista de facturas y la escribe
        {
            var billsFromFile = GetBillsRegistryFromFile();
            var bills = JsonConvert.DeserializeObject<List<Bill>>(billsFromFile);
            if (bills == null)
            {
                List<Bill> billlist = new List<Bill>();
                billlist.Add(bill);
                string billsJson = JsonConvert.SerializeObject(billlist.ToArray(), Formatting.Indented);//Serializa para guardar los cambios
                File.WriteAllText(_pathbills, billsJson);
            }
            else
            {
                bills.Add(bill);

                string billsJson = JsonConvert.SerializeObject(bills.ToArray(), Formatting.Indented);//Serializa para guardar los cambios
                File.WriteAllText(_pathbills, billsJson);
            }
        }
        public void LoadBillProducts()//Carga los productos a la factura, mostrando los datos en los txt correspondientes
        {
            txtBillId.Text = GetBillId();

            txtDateTime.Text = DateTime.Now.ToString(@"dd\/MM\/yy");
            txtTime.Text = DateTime.Now.TimeOfDay.ToString(@"hh\:mm\:ss");

            txtEmployeeName.Text = bill.EmployeSale.Name + " " + bill.EmployeSale.LastName;

            txtClientName.Text = bill.ClientSale.Name + " " + bill.ClientSale.LastName;
            txtClientId.Text = bill.ClientSale.Id.ToString();
            txtClientPhone.Text = bill.ClientSale.Phone.ToString();
            txtClientAddress.Text = bill.ClientSale.Address;


            dtgvBill.Rows.Clear();//Limpia el dtgv

            if (bill.ProductSale.ProductsInCar != null)//Añade los productos de el carrito a el dtgv
            {
                foreach (Product product in bill.ProductSale.ProductsInCar)
                {
                    float unitaryprice = 0;
                    int n = dtgvBill.Rows.Add();

                    dtgvBill.Rows[n].Cells[0].Value = product.Cantity;
                    dtgvBill.Rows[n].Cells[1].Value = product.Name;
                    dtgvBill.Rows[n].Cells[2].Value = product.Description;
                    unitaryprice = product.Price * (float)product.Cantity;
                    dtgvBill.Rows[n].Cells[3].Value = unitaryprice;
                }
            }

            txtSubTotal.Text = bill.ProductSale.TotalAmount.ToString() + "$";//Subtotal
            float iva = (float)(bill.ProductSale.TotalAmount * 0.16);//Calculo del IVA
            txtIVA.Text = iva + "$";
            float retained;
            if (bill.Contributor == true)//Si es contribuidor, le restara un 5% a el subtotal
            {
                txtRetained.Text = -5+"%";
                retained = (float)(bill.ProductSale.TotalAmount*0.05);
            }
            else//Si no, no resta nada
            {
                txtRetained.Text = 0 + "%";
                retained = 0;
            }

            float totalcost = bill.ProductSale.TotalAmount + iva - retained;//Calculo de el costo total
            txtTotalCost.Text = totalcost + "$";
            AddSaleCount(totalcost);

        }

        //Lee el json de el registro
        public static string GetBillsRegistryFromFile()
        {
            string billsJsonFromFile;
            using (var reader = new StreamReader(_pathbills))
            {
                billsJsonFromFile = reader.ReadToEnd();
            }
            return billsJsonFromFile;
        }
        public string GetBillId()//Esta función obtiene el número de ID correspondiente
        {
            var billsFromFile = GetBillsRegistryFromFile();
            var bills = JsonConvert.DeserializeObject<List<Bill>>(billsFromFile);
            int count = 1;
            if (bills == null)//SI no hay ninguna factura en el json
            {
                return "F0001";
            }
            else
            {
                foreach (Bill bill in bills)//Por cada factura, y si la id es igual, sumará +1 a el count, esto con el fin de obtener el número correcto para la factura
                {
                    if ("F" + count.ToString("D4") == bill.BillId)
                    {
                        count++;
                    }
                }
                return "F" + count.ToString("D4");//Devuelve el código correspondiente, donde count va a ser el total de las facturas+1
            }
        }
        int m, mx, my;
        private void pnlTopBorder_MouseDown(object sender, MouseEventArgs e)
        {
            m = 1;
            mx = e.X;
            my = e.Y;
        }

        private void pbExit_Click(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pnlTopBorder_MouseMove(object sender, MouseEventArgs e)
        {
            if (m == 1)
            {
                this.SetDesktopLocation(MousePosition.X - mx, MousePosition.Y - my);
            }
        }

        private void pnlTopBorder_MouseUp(object sender, MouseEventArgs e)
        {
            m = 0;
        }
        public static string _pathpdfs = Path.GetFullPath(Path.Combine(Application.StartupPath, "..\\..", "PDF"));
        
        public void GetBillPDF()//Esta función guarda la factura en formato pdf
        {

            SaveFileDialog savefile = new SaveFileDialog();//Instanciará un cuadro de dialogo para guardar el pdf en una ubicación
            savefile.FileName = GetBillId() + ".pdf";//Este será el nombre de el archivo, que será la id de la factura + .pdf
            

            string htmlpage_text = Properties.Resources.billtemplate.ToString();//Aquí utilizamos el html agregado como recurso, que será nuestra plantilla para las facturas

            //Si observamos el html, encontraremos en varias partes el "@" seguido de un texto, esto se agregó con el fin de reemplazarlos los datos correspondientes, como se observa abajo

            htmlpage_text = htmlpage_text.Replace("@IdFactura", GetBillId());//Buscará en el html "@IdFactura" y lo reemplazara por lo obtenido de GetBillId(), esto muy similar con los siguientes
            htmlpage_text = htmlpage_text.Replace("@Fecha", DateTime.Now.ToString(@"dd\/MM\/yyyy"));
            htmlpage_text = htmlpage_text.Replace("@Hora", DateTime.Now.TimeOfDay.ToString(@"hh\:mm\:ss"));
            htmlpage_text = htmlpage_text.Replace("@Empleado", $"{bill.EmployeSale.Name} {bill.EmployeSale.LastName}");
            htmlpage_text = htmlpage_text.Replace("@NombreCliente", $"{bill.ClientSale.Name} {bill.ClientSale.LastName}");
            htmlpage_text = htmlpage_text.Replace("@ClienteId", bill.ClientSale.Id.ToString());
            htmlpage_text = htmlpage_text.Replace("@ClienteTelefono", bill.ClientSale.Phone.ToString());
            htmlpage_text = htmlpage_text.Replace("@ClienteDireccion", bill.ClientSale.Address);

            string filas = string.Empty;//Aquí guardaremos los datos de los productos para luego insertarlos en el html

            foreach (Product product in bill.ProductSale.ProductsInCar)//Recorre todos los productos en el carrito de compras
            {
                //Por cada producto, irá añadiendo texto a el string filas, este texto está en el formato de html, con sus respectivos tags para las separaciones
                //"&nbsp;" Son separaciones para lograr que se vea más ordenado

                float unitaryprice = 0;
                filas += "<tr>";
                filas += "<td>&nbsp;&nbsp;&nbsp;&nbsp;" + product.Cantity.ToString() + "&nbsp;</td>";//Primero escribe la cantidad
                filas += "<td>&nbsp;&nbsp;&nbsp;&nbsp;" + product.Name + "&nbsp;&nbsp;</td>";//Luego el nombre
                filas += "<td>&nbsp;&nbsp;&nbsp;&nbsp;" + product.Description + " &nbsp;&nbsp;&nbsp;&nbsp;</td>";//Después la descripción
                unitaryprice = product.Price * (float)product.Cantity;//Realiza el calculo correcto para el precio unitario
                filas += "<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + unitaryprice.ToString() + " </td>";//Y por último el precio unitario
                filas += "</tr>";
            }
            
            htmlpage_text = htmlpage_text.Replace("@Filas", filas);//Reemplaza en el lugar correspondiente

            //Los siguientes calculos son iguales a los de el form de la facturam solo que esta vez reemplaza en el html
            htmlpage_text = htmlpage_text.Replace("@SubTotal", bill.ProductSale.TotalAmount.ToString() + "$");

            
            float iva = (float)(bill.ProductSale.TotalAmount * 0.16);
            htmlpage_text = htmlpage_text.Replace("@Iva", iva.ToString() + "$");
            float retained;
            string retainedtext;
            if (bill.Contributor == true)
            {
                retainedtext = -5 + "%";
                retained = (float)(bill.ProductSale.TotalAmount * 0.05);
            }
            else
            {
                retainedtext = 0 + "%";
                retained = 0;
            }
            htmlpage_text = htmlpage_text.Replace("@Retencion", retainedtext);

            float totalcost = (float)bill.ProductSale.TotalAmount +iva- retained;
            htmlpage_text = htmlpage_text.Replace("@Total", totalcost.ToString() + "$");

            if (savefile.ShowDialog() == DialogResult.OK)//Si el resultado de el dialogo es OK
            {
                //Comenzará a crear el pdf
                using (FileStream stream = new FileStream(savefile.FileName, FileMode.Create))//Permite la escritura y lectura para un archivo, como parámetros le damos la ruta y la "Operación", en este caso, crear
                {
                    Document pdfDoc = new Document(PageSize.A4, 25, 25, 25, 25);//Intanciamos un Document y le ajustamos el tamaño
                    PdfWriter writer = PdfWriter.GetInstance(pdfDoc, stream);//Obtenemos la instancia de el PdfWriter, sus parametros el Document y el FileStream 

                    pdfDoc.Open();//Abrimos el documento para agregar el contenido
                    iTextSharp.text.Image img = iTextSharp.text.Image.GetInstance(Properties.Resources.Logo__TuProductoOnline_, System.Drawing.Imaging.ImageFormat.Png);//Obtenemos la imagen de el logo que se encuentra en resources

                        img.ScaleToFit(70, 83);//Ajustamos la imagen
                    img.Alignment = iTextSharp.text.Image.UNDERLYING;//Ajustamos para que la imagen se sobreponga
                    img.SetAbsolutePosition(pdfDoc.Right-60, pdfDoc.Top - 60);//Ajustamos la posición de la imagen
                    pdfDoc.Add(img);//La añadimos

                    using (StringReader sr = new StringReader(htmlpage_text))//Lector del string que contiene a el html
                    {
                        XMLWorkerHelper.GetInstance().ParseXHtml(writer, pdfDoc, sr);//Mediante el writer, escribirá en el documento el contenido de el string, pero tomando en cuenta el formato html
                        //writer es el FileStream que permite la escritura, pdfDoc es el documento pdf y sr es el StringReader que lee el string htmlpage_text
                    }

                    pdfDoc.Close();//Cierra el documento
                    stream.Close();//Cierra el FileStream
                }
                
                MessageBox.Show("Se ha creado el pdf correctamente");
               

            }
            //El proceso es el mismo a el de arriba, solo que en este caso, cambia la ubicación de el guardado, teniendo una copia de el pdf de la factura en la carpeta de la solución
            string pdfregistry = Path.Combine(_pathpdfs, GetBillId() + ".pdf");//A este string le asignamos la ruta de la carpeta+el nombre de el archivo correspondiente
            using (FileStream stream = new FileStream(pdfregistry, FileMode.Create))//Se coloca pdfregistry en la ruta de el FileStream
            {
                Document pdfDoc = new Document(PageSize.A4, 25, 25, 25, 25);
                PdfWriter writer = PdfWriter.GetInstance(pdfDoc, stream);

                pdfDoc.Open();
                iTextSharp.text.Image img = iTextSharp.text.Image.GetInstance(Properties.Resources.Logo__TuProductoOnline_, System.Drawing.Imaging.ImageFormat.Png);

                img.ScaleToFit(70, 83);
                img.Alignment = iTextSharp.text.Image.UNDERLYING;
                img.SetAbsolutePosition(pdfDoc.Right - 60, pdfDoc.Top - 60);
                pdfDoc.Add(img);

                using (StringReader sr = new StringReader(htmlpage_text))
                {
                    XMLWorkerHelper.GetInstance().ParseXHtml(writer, pdfDoc, sr);
                }

                pdfDoc.Close();
                stream.Close();
            }
        }


    }
}

    
