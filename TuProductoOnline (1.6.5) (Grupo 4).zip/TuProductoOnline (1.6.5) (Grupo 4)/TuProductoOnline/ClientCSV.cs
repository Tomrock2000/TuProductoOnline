﻿using CsvHelper.Configuration.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TuProductoOnline
{
    internal class ClientCSV
    {

        [Name("ID")]
        public long Id { get; set; }

        [Name("Nombre")]
        public string Name { get; set; }

        [Name("Apellido")]
        public string LastName { get; set; }

        [Name("Telefono")]
        public long Phone { get; set; }

        [Name("Direccion")]
        public string Address { get; set; }

        [Name("Activo")]
        public bool Enabled { get; set; }

    }
}
    
