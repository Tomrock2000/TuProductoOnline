﻿namespace TuProductoOnline
{
    partial class ClientManageMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ClientManageMenu));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btnAddManageClient = new System.Windows.Forms.Button();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.dtgvClients = new System.Windows.Forms.DataGridView();
            this.ClientName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Lastname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Phone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Adress = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ModifyClient = new System.Windows.Forms.DataGridViewButtonColumn();
            this.DeleteClient = new System.Windows.Forms.DataGridViewButtonColumn();
            this.btnPrevPage = new System.Windows.Forms.Button();
            this.btnNextPage = new System.Windows.Forms.Button();
            this.pnlSudMenu = new System.Windows.Forms.Panel();
            this.btnExport = new System.Windows.Forms.Button();
            this.btnImport = new System.Windows.Forms.Button();
            this.btnExportImport = new System.Windows.Forms.Button();
            this.pbSearch = new System.Windows.Forms.PictureBox();
            this.pbTitleFrame = new System.Windows.Forms.PictureBox();
            this.pbIconFrame = new System.Windows.Forms.PictureBox();
            this.pbMenuIcon = new System.Windows.Forms.PictureBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvClients)).BeginInit();
            this.pnlSudMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbSearch)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbTitleFrame)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbIconFrame)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMenuIcon)).BeginInit();
            this.SuspendLayout();
            // 
            // btnAddManageClient
            // 
            this.btnAddManageClient.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnAddManageClient.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.btnAddManageClient.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddManageClient.FlatAppearance.BorderSize = 0;
            this.btnAddManageClient.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(73)))), ((int)(((byte)(73)))));
            this.btnAddManageClient.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddManageClient.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddManageClient.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.btnAddManageClient.Image = ((System.Drawing.Image)(resources.GetObject("btnAddManageClient.Image")));
            this.btnAddManageClient.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAddManageClient.Location = new System.Drawing.Point(692, 105);
            this.btnAddManageClient.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAddManageClient.Name = "btnAddManageClient";
            this.btnAddManageClient.Size = new System.Drawing.Size(183, 48);
            this.btnAddManageClient.TabIndex = 2;
            this.btnAddManageClient.Text = "Agregar Cliente";
            this.btnAddManageClient.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAddManageClient.UseVisualStyleBackColor = false;
            this.btnAddManageClient.Click += new System.EventHandler(this.btnAddManageClient_Click);
            // 
            // txtSearch
            // 
            this.txtSearch.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtSearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold);
            this.txtSearch.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.txtSearch.Location = new System.Drawing.Point(128, 117);
            this.txtSearch.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(557, 35);
            this.txtSearch.TabIndex = 1;
            this.txtSearch.Text = "Buscar...";
            this.txtSearch.MouseClick += new System.Windows.Forms.MouseEventHandler(this.txtSearch_MouseClick);
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
            // 
            // lblWelcome
            // 
            this.lblWelcome.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.BackColor = System.Drawing.Color.Transparent;
            this.lblWelcome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblWelcome.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold);
            this.lblWelcome.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblWelcome.Location = new System.Drawing.Point(391, 25);
            this.lblWelcome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(243, 29);
            this.lblWelcome.TabIndex = 27;
            this.lblWelcome.Text = "Gestión de Clientes";
            this.lblWelcome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dtgvClients
            // 
            this.dtgvClients.AllowUserToAddRows = false;
            this.dtgvClients.AllowUserToOrderColumns = true;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvClients.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle12;
            this.dtgvClients.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dtgvClients.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.dtgvClients.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dtgvClients.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dtgvClients.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvClients.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.dtgvClients.ColumnHeadersHeight = 38;
            this.dtgvClients.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ClientName,
            this.Lastname,
            this.Id,
            this.Phone,
            this.Adress,
            this.ModifyClient,
            this.DeleteClient});
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle21.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle21.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle21.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvClients.DefaultCellStyle = dataGridViewCellStyle21;
            this.dtgvClients.EnableHeadersVisualStyles = false;
            this.dtgvClients.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.dtgvClients.Location = new System.Drawing.Point(128, 158);
            this.dtgvClients.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dtgvClients.Name = "dtgvClients";
            this.dtgvClients.ReadOnly = true;
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle22.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle22.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle22.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle22.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle22.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvClients.RowHeadersDefaultCellStyle = dataGridViewCellStyle22;
            this.dtgvClients.RowHeadersVisible = false;
            this.dtgvClients.RowHeadersWidth = 51;
            this.dtgvClients.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dtgvClients.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.dtgvClients.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Bold);
            this.dtgvClients.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.dtgvClients.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            this.dtgvClients.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.dtgvClients.RowTemplate.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvClients.RowTemplate.Height = 35;
            this.dtgvClients.Size = new System.Drawing.Size(747, 312);
            this.dtgvClients.TabIndex = 3;
            this.dtgvClients.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgvUsers_CellContentClick);
            this.dtgvClients.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.dtgvClients_CellPainting);
            // 
            // ClientName
            // 
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClientName.DefaultCellStyle = dataGridViewCellStyle14;
            this.ClientName.HeaderText = "Nombre Cliente";
            this.ClientName.MinimumWidth = 6;
            this.ClientName.Name = "ClientName";
            this.ClientName.ReadOnly = true;
            this.ClientName.Width = 125;
            // 
            // Lastname
            // 
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.Lastname.DefaultCellStyle = dataGridViewCellStyle15;
            this.Lastname.HeaderText = "Apellido Cliente";
            this.Lastname.MinimumWidth = 6;
            this.Lastname.Name = "Lastname";
            this.Lastname.ReadOnly = true;
            this.Lastname.Width = 125;
            // 
            // Id
            // 
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.Id.DefaultCellStyle = dataGridViewCellStyle16;
            this.Id.HeaderText = "Cédula Cliente";
            this.Id.MinimumWidth = 6;
            this.Id.Name = "Id";
            this.Id.ReadOnly = true;
            this.Id.Width = 125;
            // 
            // Phone
            // 
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.Phone.DefaultCellStyle = dataGridViewCellStyle17;
            this.Phone.HeaderText = "Teléfono Cliente";
            this.Phone.MinimumWidth = 6;
            this.Phone.Name = "Phone";
            this.Phone.ReadOnly = true;
            this.Phone.Width = 125;
            // 
            // Adress
            // 
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.Adress.DefaultCellStyle = dataGridViewCellStyle18;
            this.Adress.HeaderText = "Dirección Cliente";
            this.Adress.MinimumWidth = 6;
            this.Adress.Name = "Adress";
            this.Adress.ReadOnly = true;
            this.Adress.Width = 125;
            // 
            // ModifyClient
            // 
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.ModifyClient.DefaultCellStyle = dataGridViewCellStyle19;
            this.ModifyClient.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ModifyClient.HeaderText = "Modificar Cliente";
            this.ModifyClient.MinimumWidth = 6;
            this.ModifyClient.Name = "ModifyClient";
            this.ModifyClient.ReadOnly = true;
            this.ModifyClient.Width = 125;
            // 
            // DeleteClient
            // 
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.DeleteClient.DefaultCellStyle = dataGridViewCellStyle20;
            this.DeleteClient.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DeleteClient.HeaderText = "Eliminar Cliente";
            this.DeleteClient.MinimumWidth = 6;
            this.DeleteClient.Name = "DeleteClient";
            this.DeleteClient.ReadOnly = true;
            this.DeleteClient.Width = 125;
            // 
            // btnPrevPage
            // 
            this.btnPrevPage.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnPrevPage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.btnPrevPage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPrevPage.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold);
            this.btnPrevPage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.btnPrevPage.Location = new System.Drawing.Point(426, 476);
            this.btnPrevPage.Name = "btnPrevPage";
            this.btnPrevPage.Size = new System.Drawing.Size(71, 38);
            this.btnPrevPage.TabIndex = 4;
            this.btnPrevPage.Text = "Pág Anterior";
            this.btnPrevPage.UseVisualStyleBackColor = false;
            this.btnPrevPage.Click += new System.EventHandler(this.btnPrevPage_Click);
            // 
            // btnNextPage
            // 
            this.btnNextPage.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnNextPage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.btnNextPage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNextPage.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold);
            this.btnNextPage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.btnNextPage.Location = new System.Drawing.Point(503, 476);
            this.btnNextPage.Name = "btnNextPage";
            this.btnNextPage.Size = new System.Drawing.Size(71, 38);
            this.btnNextPage.TabIndex = 5;
            this.btnNextPage.Text = "Pág Siguiente";
            this.btnNextPage.UseVisualStyleBackColor = false;
            this.btnNextPage.Click += new System.EventHandler(this.btnNextPage_Click);
            // 
            // pnlSudMenu
            // 
            this.pnlSudMenu.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pnlSudMenu.AutoScroll = true;
            this.pnlSudMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.pnlSudMenu.Controls.Add(this.btnExport);
            this.pnlSudMenu.Controls.Add(this.btnImport);
            this.pnlSudMenu.Location = new System.Drawing.Point(12, 40);
            this.pnlSudMenu.Name = "pnlSudMenu";
            this.pnlSudMenu.Size = new System.Drawing.Size(66, 144);
            this.pnlSudMenu.TabIndex = 80;
            // 
            // btnExport
            // 
            this.btnExport.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.btnExport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExport.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnExport.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.btnExport.Image = global::TuProductoOnline.Properties.Resources.Icono_Exportar1;
            this.btnExport.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnExport.Location = new System.Drawing.Point(0, 73);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(66, 68);
            this.btnExport.TabIndex = 1;
            this.btnExport.Text = "Exportar";
            this.btnExport.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnExport.UseVisualStyleBackColor = false;
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            // 
            // btnImport
            // 
            this.btnImport.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.btnImport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnImport.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnImport.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.btnImport.Image = global::TuProductoOnline.Properties.Resources.Icono_Importar;
            this.btnImport.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnImport.Location = new System.Drawing.Point(0, 3);
            this.btnImport.Name = "btnImport";
            this.btnImport.Size = new System.Drawing.Size(66, 68);
            this.btnImport.TabIndex = 0;
            this.btnImport.Text = "Importar";
            this.btnImport.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnImport.UseVisualStyleBackColor = false;
            this.btnImport.Click += new System.EventHandler(this.btnImport_Click);
            // 
            // btnExportImport
            // 
            this.btnExportImport.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnExportImport.FlatAppearance.BorderSize = 0;
            this.btnExportImport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExportImport.Location = new System.Drawing.Point(12, 12);
            this.btnExportImport.Name = "btnExportImport";
            this.btnExportImport.Size = new System.Drawing.Size(66, 30);
            this.btnExportImport.TabIndex = 79;
            this.btnExportImport.Text = "°°°";
            this.btnExportImport.UseVisualStyleBackColor = true;
            this.btnExportImport.Click += new System.EventHandler(this.btnExportImport_Click);
            // 
            // pbSearch
            // 
            this.pbSearch.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pbSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.pbSearch.Image = ((System.Drawing.Image)(resources.GetObject("pbSearch.Image")));
            this.pbSearch.Location = new System.Drawing.Point(651, 118);
            this.pbSearch.Name = "pbSearch";
            this.pbSearch.Size = new System.Drawing.Size(32, 32);
            this.pbSearch.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSearch.TabIndex = 81;
            this.pbSearch.TabStop = false;
            // 
            // pbTitleFrame
            // 
            this.pbTitleFrame.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pbTitleFrame.BackColor = System.Drawing.Color.Transparent;
            this.pbTitleFrame.Image = global::TuProductoOnline.Properties.Resources.Marco_de_Widgets;
            this.pbTitleFrame.Location = new System.Drawing.Point(381, 13);
            this.pbTitleFrame.Name = "pbTitleFrame";
            this.pbTitleFrame.Size = new System.Drawing.Size(262, 55);
            this.pbTitleFrame.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbTitleFrame.TabIndex = 82;
            this.pbTitleFrame.TabStop = false;
            // 
            // pbIconFrame
            // 
            this.pbIconFrame.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pbIconFrame.BackColor = System.Drawing.Color.Transparent;
            this.pbIconFrame.Image = global::TuProductoOnline.Properties.Resources.Marco_de_Widgets;
            this.pbIconFrame.Location = new System.Drawing.Point(913, -1);
            this.pbIconFrame.Name = "pbIconFrame";
            this.pbIconFrame.Size = new System.Drawing.Size(117, 112);
            this.pbIconFrame.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbIconFrame.TabIndex = 83;
            this.pbIconFrame.TabStop = false;
            // 
            // pbMenuIcon
            // 
            this.pbMenuIcon.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pbMenuIcon.BackColor = System.Drawing.Color.Transparent;
            this.pbMenuIcon.Image = global::TuProductoOnline.Properties.Resources.Icono_Gestión_de_Clientes1;
            this.pbMenuIcon.Location = new System.Drawing.Point(916, 4);
            this.pbMenuIcon.Name = "pbMenuIcon";
            this.pbMenuIcon.Size = new System.Drawing.Size(110, 102);
            this.pbMenuIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbMenuIcon.TabIndex = 84;
            this.pbMenuIcon.TabStop = false;
            // 
            // comboBox1
            // 
            this.comboBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.comboBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Cedula",
            "Nombre"});
            this.comboBox1.Location = new System.Drawing.Point(128, 81);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 28);
            this.comboBox1.TabIndex = 85;
            this.comboBox1.Text = "Ordenar por:";
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // ClientManageMenu
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(234)))), ((int)(((byte)(199)))));
            this.ClientSize = new System.Drawing.Size(1030, 560);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.pbMenuIcon);
            this.Controls.Add(this.pbIconFrame);
            this.Controls.Add(this.pbSearch);
            this.Controls.Add(this.pnlSudMenu);
            this.Controls.Add(this.btnExportImport);
            this.Controls.Add(this.btnPrevPage);
            this.Controls.Add(this.btnNextPage);
            this.Controls.Add(this.dtgvClients);
            this.Controls.Add(this.btnAddManageClient);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.lblWelcome);
            this.Controls.Add(this.pbTitleFrame);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "ClientManageMenu";
            this.Text = "ClientManageMenu";
            this.Activated += new System.EventHandler(this.ClientManageMenu_Activated);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvClients)).EndInit();
            this.pnlSudMenu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbSearch)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbTitleFrame)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbIconFrame)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMenuIcon)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnAddManageClient;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.DataGridView dtgvClients;
        private System.Windows.Forms.Button btnPrevPage;
        private System.Windows.Forms.Button btnNextPage;
        private System.Windows.Forms.Panel pnlSudMenu;
        private System.Windows.Forms.Button btnExport;
        private System.Windows.Forms.Button btnImport;
        private System.Windows.Forms.Button btnExportImport;
        private System.Windows.Forms.PictureBox pbSearch;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClientName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Lastname;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id;
        private System.Windows.Forms.DataGridViewTextBoxColumn Phone;
        private System.Windows.Forms.DataGridViewTextBoxColumn Adress;
        private System.Windows.Forms.DataGridViewButtonColumn ModifyClient;
        private System.Windows.Forms.DataGridViewButtonColumn DeleteClient;
        private System.Windows.Forms.PictureBox pbTitleFrame;
        private System.Windows.Forms.PictureBox pbIconFrame;
        private System.Windows.Forms.PictureBox pbMenuIcon;
        private System.Windows.Forms.ComboBox comboBox1;
    }
}