﻿namespace TuProductoOnline
{
    partial class DeleteProductSelect
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DeleteProductSelect));
            this.txtTypeProduct = new System.Windows.Forms.TextBox();
            this.lblCantityToSell = new System.Windows.Forms.Label();
            this.txtCantityToSell = new System.Windows.Forms.TextBox();
            this.txtDescriptionProduct = new System.Windows.Forms.RichTextBox();
            this.lblModelProduct = new System.Windows.Forms.Label();
            this.txtModelProduct = new System.Windows.Forms.TextBox();
            this.lblVersionProduct = new System.Windows.Forms.Label();
            this.txtVersionProduct = new System.Windows.Forms.TextBox();
            this.lblLicenceProduct = new System.Windows.Forms.Label();
            this.txtLicenceProduct = new System.Windows.Forms.TextBox();
            this.lblMeassuresProduct = new System.Windows.Forms.Label();
            this.txtMeassuresProduct = new System.Windows.Forms.TextBox();
            this.lblPriceProduct = new System.Windows.Forms.Label();
            this.txtPriceProduct = new System.Windows.Forms.TextBox();
            this.lblNameProduct = new System.Windows.Forms.Label();
            this.txtNameProduct = new System.Windows.Forms.TextBox();
            this.lblDescriptionProduct = new System.Windows.Forms.Label();
            this.lblIdProduct = new System.Windows.Forms.Label();
            this.txtIdProduct = new System.Windows.Forms.TextBox();
            this.btnDeleteSelectProduct = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.lblType = new System.Windows.Forms.Label();
            this.pnlTopBorder = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.dtgvProducts = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvProducts)).BeginInit();
            this.SuspendLayout();
            // 
            // txtTypeProduct
            // 
            this.txtTypeProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtTypeProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTypeProduct.ForeColor = System.Drawing.Color.White;
            this.txtTypeProduct.Location = new System.Drawing.Point(466, 39);
            this.txtTypeProduct.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtTypeProduct.MaxLength = 20;
            this.txtTypeProduct.Name = "txtTypeProduct";
            this.txtTypeProduct.ReadOnly = true;
            this.txtTypeProduct.Size = new System.Drawing.Size(122, 26);
            this.txtTypeProduct.TabIndex = 102;
            // 
            // lblCantityToSell
            // 
            this.lblCantityToSell.AutoSize = true;
            this.lblCantityToSell.Location = new System.Drawing.Point(462, 221);
            this.lblCantityToSell.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCantityToSell.Name = "lblCantityToSell";
            this.lblCantityToSell.Size = new System.Drawing.Size(165, 20);
            this.lblCantityToSell.TabIndex = 100;
            this.lblCantityToSell.Text = "Cantidad a Eliminar";
            // 
            // txtCantityToSell
            // 
            this.txtCantityToSell.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtCantityToSell.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCantityToSell.ForeColor = System.Drawing.Color.White;
            this.txtCantityToSell.Location = new System.Drawing.Point(486, 255);
            this.txtCantityToSell.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtCantityToSell.MaxLength = 3;
            this.txtCantityToSell.Name = "txtCantityToSell";
            this.txtCantityToSell.Size = new System.Drawing.Size(114, 26);
            this.txtCantityToSell.TabIndex = 2;
            this.txtCantityToSell.TextChanged += new System.EventHandler(this.txtNameProduct_TextChanged);
            // 
            // txtDescriptionProduct
            // 
            this.txtDescriptionProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtDescriptionProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDescriptionProduct.ForeColor = System.Drawing.Color.White;
            this.txtDescriptionProduct.Location = new System.Drawing.Point(317, 100);
            this.txtDescriptionProduct.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtDescriptionProduct.MaxLength = 200;
            this.txtDescriptionProduct.Name = "txtDescriptionProduct";
            this.txtDescriptionProduct.ReadOnly = true;
            this.txtDescriptionProduct.Size = new System.Drawing.Size(271, 86);
            this.txtDescriptionProduct.TabIndex = 98;
            this.txtDescriptionProduct.Text = "";
            this.txtDescriptionProduct.TextChanged += new System.EventHandler(this.txtNameProduct_TextChanged);
            // 
            // lblModelProduct
            // 
            this.lblModelProduct.AutoSize = true;
            this.lblModelProduct.Location = new System.Drawing.Point(59, 75);
            this.lblModelProduct.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblModelProduct.Name = "lblModelProduct";
            this.lblModelProduct.Size = new System.Drawing.Size(57, 20);
            this.lblModelProduct.TabIndex = 97;
            this.lblModelProduct.Text = "Model";
            this.lblModelProduct.Visible = false;
            // 
            // txtModelProduct
            // 
            this.txtModelProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtModelProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtModelProduct.ForeColor = System.Drawing.Color.White;
            this.txtModelProduct.Location = new System.Drawing.Point(25, 100);
            this.txtModelProduct.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtModelProduct.MaxLength = 20;
            this.txtModelProduct.Name = "txtModelProduct";
            this.txtModelProduct.ReadOnly = true;
            this.txtModelProduct.Size = new System.Drawing.Size(132, 26);
            this.txtModelProduct.TabIndex = 96;
            this.txtModelProduct.Visible = false;
            this.txtModelProduct.TextChanged += new System.EventHandler(this.txtNameProduct_TextChanged);
            // 
            // lblVersionProduct
            // 
            this.lblVersionProduct.AutoSize = true;
            this.lblVersionProduct.Location = new System.Drawing.Point(209, 75);
            this.lblVersionProduct.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblVersionProduct.Name = "lblVersionProduct";
            this.lblVersionProduct.Size = new System.Drawing.Size(70, 20);
            this.lblVersionProduct.TabIndex = 95;
            this.lblVersionProduct.Text = "Version";
            this.lblVersionProduct.Visible = false;
            // 
            // txtVersionProduct
            // 
            this.txtVersionProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtVersionProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtVersionProduct.ForeColor = System.Drawing.Color.White;
            this.txtVersionProduct.Location = new System.Drawing.Point(170, 100);
            this.txtVersionProduct.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtVersionProduct.MaxLength = 20;
            this.txtVersionProduct.Name = "txtVersionProduct";
            this.txtVersionProduct.ReadOnly = true;
            this.txtVersionProduct.Size = new System.Drawing.Size(132, 26);
            this.txtVersionProduct.TabIndex = 94;
            this.txtVersionProduct.Visible = false;
            this.txtVersionProduct.TextChanged += new System.EventHandler(this.txtNameProduct_TextChanged);
            // 
            // lblLicenceProduct
            // 
            this.lblLicenceProduct.AutoSize = true;
            this.lblLicenceProduct.Location = new System.Drawing.Point(55, 75);
            this.lblLicenceProduct.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblLicenceProduct.Name = "lblLicenceProduct";
            this.lblLicenceProduct.Size = new System.Drawing.Size(75, 20);
            this.lblLicenceProduct.TabIndex = 93;
            this.lblLicenceProduct.Text = "Licencia";
            this.lblLicenceProduct.Visible = false;
            // 
            // txtLicenceProduct
            // 
            this.txtLicenceProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtLicenceProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtLicenceProduct.ForeColor = System.Drawing.Color.White;
            this.txtLicenceProduct.Location = new System.Drawing.Point(25, 100);
            this.txtLicenceProduct.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtLicenceProduct.MaxLength = 20;
            this.txtLicenceProduct.Name = "txtLicenceProduct";
            this.txtLicenceProduct.ReadOnly = true;
            this.txtLicenceProduct.Size = new System.Drawing.Size(132, 26);
            this.txtLicenceProduct.TabIndex = 92;
            this.txtLicenceProduct.Visible = false;
            this.txtLicenceProduct.TextChanged += new System.EventHandler(this.txtNameProduct_TextChanged);
            // 
            // lblMeassuresProduct
            // 
            this.lblMeassuresProduct.AutoSize = true;
            this.lblMeassuresProduct.Location = new System.Drawing.Point(59, 75);
            this.lblMeassuresProduct.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMeassuresProduct.Name = "lblMeassuresProduct";
            this.lblMeassuresProduct.Size = new System.Drawing.Size(76, 20);
            this.lblMeassuresProduct.TabIndex = 91;
            this.lblMeassuresProduct.Text = "Medidas";
            this.lblMeassuresProduct.Visible = false;
            // 
            // txtMeassuresProduct
            // 
            this.txtMeassuresProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtMeassuresProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtMeassuresProduct.ForeColor = System.Drawing.Color.White;
            this.txtMeassuresProduct.Location = new System.Drawing.Point(25, 100);
            this.txtMeassuresProduct.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtMeassuresProduct.MaxLength = 20;
            this.txtMeassuresProduct.Name = "txtMeassuresProduct";
            this.txtMeassuresProduct.ReadOnly = true;
            this.txtMeassuresProduct.Size = new System.Drawing.Size(132, 26);
            this.txtMeassuresProduct.TabIndex = 90;
            this.txtMeassuresProduct.Visible = false;
            this.txtMeassuresProduct.TextChanged += new System.EventHandler(this.txtNameProduct_TextChanged);
            // 
            // lblPriceProduct
            // 
            this.lblPriceProduct.AutoSize = true;
            this.lblPriceProduct.Location = new System.Drawing.Point(211, 18);
            this.lblPriceProduct.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPriceProduct.Name = "lblPriceProduct";
            this.lblPriceProduct.Size = new System.Drawing.Size(59, 20);
            this.lblPriceProduct.TabIndex = 89;
            this.lblPriceProduct.Text = "Precio";
            // 
            // txtPriceProduct
            // 
            this.txtPriceProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtPriceProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPriceProduct.ForeColor = System.Drawing.Color.White;
            this.txtPriceProduct.Location = new System.Drawing.Point(170, 39);
            this.txtPriceProduct.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtPriceProduct.MaxLength = 6;
            this.txtPriceProduct.Name = "txtPriceProduct";
            this.txtPriceProduct.ReadOnly = true;
            this.txtPriceProduct.Size = new System.Drawing.Size(132, 26);
            this.txtPriceProduct.TabIndex = 88;
            this.txtPriceProduct.TextChanged += new System.EventHandler(this.txtNameProduct_TextChanged);
            // 
            // lblNameProduct
            // 
            this.lblNameProduct.AutoSize = true;
            this.lblNameProduct.Location = new System.Drawing.Point(59, 18);
            this.lblNameProduct.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNameProduct.Name = "lblNameProduct";
            this.lblNameProduct.Size = new System.Drawing.Size(71, 20);
            this.lblNameProduct.TabIndex = 87;
            this.lblNameProduct.Text = "Nombre";
            // 
            // txtNameProduct
            // 
            this.txtNameProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtNameProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtNameProduct.ForeColor = System.Drawing.Color.White;
            this.txtNameProduct.Location = new System.Drawing.Point(25, 39);
            this.txtNameProduct.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtNameProduct.MaxLength = 20;
            this.txtNameProduct.Name = "txtNameProduct";
            this.txtNameProduct.ReadOnly = true;
            this.txtNameProduct.Size = new System.Drawing.Size(132, 26);
            this.txtNameProduct.TabIndex = 86;
            this.txtNameProduct.TextChanged += new System.EventHandler(this.txtNameProduct_TextChanged);
            // 
            // lblDescriptionProduct
            // 
            this.lblDescriptionProduct.AutoSize = true;
            this.lblDescriptionProduct.Location = new System.Drawing.Point(342, 75);
            this.lblDescriptionProduct.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDescriptionProduct.Name = "lblDescriptionProduct";
            this.lblDescriptionProduct.Size = new System.Drawing.Size(103, 20);
            this.lblDescriptionProduct.TabIndex = 85;
            this.lblDescriptionProduct.Text = "Descripción";
            // 
            // lblIdProduct
            // 
            this.lblIdProduct.AutoSize = true;
            this.lblIdProduct.Location = new System.Drawing.Point(356, 18);
            this.lblIdProduct.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblIdProduct.Name = "lblIdProduct";
            this.lblIdProduct.Size = new System.Drawing.Size(65, 20);
            this.lblIdProduct.TabIndex = 84;
            this.lblIdProduct.Text = "Código";
            // 
            // txtIdProduct
            // 
            this.txtIdProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtIdProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtIdProduct.ForeColor = System.Drawing.Color.White;
            this.txtIdProduct.Location = new System.Drawing.Point(317, 39);
            this.txtIdProduct.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtIdProduct.MaxLength = 10;
            this.txtIdProduct.Name = "txtIdProduct";
            this.txtIdProduct.ReadOnly = true;
            this.txtIdProduct.Size = new System.Drawing.Size(132, 26);
            this.txtIdProduct.TabIndex = 83;
            // 
            // btnDeleteSelectProduct
            // 
            this.btnDeleteSelectProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.btnDeleteSelectProduct.Enabled = false;
            this.btnDeleteSelectProduct.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDeleteSelectProduct.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.btnDeleteSelectProduct.Location = new System.Drawing.Point(488, 296);
            this.btnDeleteSelectProduct.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnDeleteSelectProduct.Name = "btnDeleteSelectProduct";
            this.btnDeleteSelectProduct.Size = new System.Drawing.Size(112, 27);
            this.btnDeleteSelectProduct.TabIndex = 3;
            this.btnDeleteSelectProduct.Text = "Modificar";
            this.btnDeleteSelectProduct.UseVisualStyleBackColor = false;
            this.btnDeleteSelectProduct.Click += new System.EventHandler(this.btnDeleteSelectProduct_Click);
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBack.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.btnBack.Location = new System.Drawing.Point(488, 339);
            this.btnBack.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(112, 27);
            this.btnBack.TabIndex = 4;
            this.btnBack.Text = "Regresar";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // lblType
            // 
            this.lblType.AutoSize = true;
            this.lblType.Location = new System.Drawing.Point(494, 18);
            this.lblType.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblType.Name = "lblType";
            this.lblType.Size = new System.Drawing.Size(87, 20);
            this.lblType.TabIndex = 105;
            this.lblType.Text = "Categoria";
            // 
            // pnlTopBorder
            // 
            this.pnlTopBorder.BackColor = System.Drawing.Color.Transparent;
            this.pnlTopBorder.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTopBorder.Location = new System.Drawing.Point(0, 0);
            this.pnlTopBorder.Name = "pnlTopBorder";
            this.pnlTopBorder.Size = new System.Drawing.Size(639, 20);
            this.pnlTopBorder.TabIndex = 106;
            this.pnlTopBorder.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlTopBorder_MouseDown);
            this.pnlTopBorder.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pnlTopBorder_MouseMove);
            this.pnlTopBorder.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pnlTopBorder_MouseUp);
            // 
            // textBox1
            // 
            this.textBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.ForeColor = System.Drawing.Color.White;
            this.textBox1.Location = new System.Drawing.Point(25, 204);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(400, 26);
            this.textBox1.TabIndex = 108;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // dtgvProducts
            // 
            this.dtgvProducts.AllowUserToOrderColumns = true;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvProducts.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dtgvProducts.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.dtgvProducts.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dtgvProducts.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dtgvProducts.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvProducts.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dtgvProducts.ColumnHeadersHeight = 45;
            this.dtgvProducts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dtgvProducts.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.ProductName,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6});
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvProducts.DefaultCellStyle = dataGridViewCellStyle8;
            this.dtgvProducts.EnableHeadersVisualStyles = false;
            this.dtgvProducts.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.dtgvProducts.Location = new System.Drawing.Point(25, 242);
            this.dtgvProducts.Name = "dtgvProducts";
            this.dtgvProducts.ReadOnly = true;
            this.dtgvProducts.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dtgvProducts.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvProducts.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.dtgvProducts.RowHeadersVisible = false;
            this.dtgvProducts.RowHeadersWidth = 51;
            this.dtgvProducts.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dtgvProducts.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.dtgvProducts.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Bold);
            this.dtgvProducts.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.dtgvProducts.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            this.dtgvProducts.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.dtgvProducts.RowTemplate.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvProducts.RowTemplate.Height = 40;
            this.dtgvProducts.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvProducts.Size = new System.Drawing.Size(400, 168);
            this.dtgvProducts.TabIndex = 109;
            this.dtgvProducts.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgvProducts_CellClick);
            // 
            // dataGridViewTextBoxColumn1
            // 
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewTextBoxColumn1.HeaderText = "Código Producto";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 125;
            // 
            // ProductName
            // 
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.ProductName.DefaultCellStyle = dataGridViewCellStyle4;
            this.ProductName.HeaderText = "Nombre Producto";
            this.ProductName.MinimumWidth = 6;
            this.ProductName.Name = "ProductName";
            this.ProductName.ReadOnly = true;
            this.ProductName.Width = 125;
            // 
            // dataGridViewTextBoxColumn3
            // 
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.dataGridViewTextBoxColumn3.DefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridViewTextBoxColumn3.HeaderText = "Precio ($) Producto";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 125;
            // 
            // dataGridViewTextBoxColumn4
            // 
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.dataGridViewTextBoxColumn4.DefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridViewTextBoxColumn4.HeaderText = "Categoria Producto";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 125;
            // 
            // dataGridViewTextBoxColumn5
            // 
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.dataGridViewTextBoxColumn5.DefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridViewTextBoxColumn5.HeaderText = "Descripcion Producto";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Width = 125;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.HeaderText = "Cantidad Producto";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            // 
            // DeleteProductSelect
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(234)))), ((int)(((byte)(199)))));
            this.ClientSize = new System.Drawing.Size(639, 437);
            this.Controls.Add(this.dtgvProducts);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.pnlTopBorder);
            this.Controls.Add(this.lblType);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnDeleteSelectProduct);
            this.Controls.Add(this.txtTypeProduct);
            this.Controls.Add(this.lblCantityToSell);
            this.Controls.Add(this.txtCantityToSell);
            this.Controls.Add(this.txtDescriptionProduct);
            this.Controls.Add(this.lblModelProduct);
            this.Controls.Add(this.txtModelProduct);
            this.Controls.Add(this.lblVersionProduct);
            this.Controls.Add(this.txtVersionProduct);
            this.Controls.Add(this.lblLicenceProduct);
            this.Controls.Add(this.txtLicenceProduct);
            this.Controls.Add(this.lblMeassuresProduct);
            this.Controls.Add(this.txtMeassuresProduct);
            this.Controls.Add(this.lblPriceProduct);
            this.Controls.Add(this.txtPriceProduct);
            this.Controls.Add(this.lblNameProduct);
            this.Controls.Add(this.txtNameProduct);
            this.Controls.Add(this.lblDescriptionProduct);
            this.Controls.Add(this.lblIdProduct);
            this.Controls.Add(this.txtIdProduct);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "DeleteProductSelect";
            this.Text = "DeleteProductSelect";
            ((System.ComponentModel.ISupportInitialize)(this.dtgvProducts)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtTypeProduct;
        private System.Windows.Forms.Label lblCantityToSell;
        private System.Windows.Forms.TextBox txtCantityToSell;
        private System.Windows.Forms.RichTextBox txtDescriptionProduct;
        private System.Windows.Forms.Label lblModelProduct;
        private System.Windows.Forms.TextBox txtModelProduct;
        private System.Windows.Forms.Label lblVersionProduct;
        private System.Windows.Forms.TextBox txtVersionProduct;
        private System.Windows.Forms.Label lblLicenceProduct;
        private System.Windows.Forms.TextBox txtLicenceProduct;
        private System.Windows.Forms.Label lblMeassuresProduct;
        private System.Windows.Forms.TextBox txtMeassuresProduct;
        private System.Windows.Forms.Label lblPriceProduct;
        private System.Windows.Forms.TextBox txtPriceProduct;
        private System.Windows.Forms.Label lblNameProduct;
        private System.Windows.Forms.TextBox txtNameProduct;
        private System.Windows.Forms.Label lblDescriptionProduct;
        private System.Windows.Forms.Label lblIdProduct;
        private System.Windows.Forms.TextBox txtIdProduct;
        private System.Windows.Forms.Button btnDeleteSelectProduct;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Label lblType;
        private System.Windows.Forms.Panel pnlTopBorder;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.DataGridView dtgvProducts;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductName;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
    }
}