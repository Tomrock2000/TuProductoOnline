﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TuProductoOnline
{
    public partial class DeleteProductSelect : Form
    {
         CarShop carShop=new CarShop();//Instanciamos un objeto carrito, que será de donde obtendremos los datos
        public DeleteProductSelect(CarShop car)//El constructor de este form recibe un objeto CarShop
        {
            carShop=car;//Asignamos a carShop el objeto recibido en el contructor
            InitializeComponent();
            ProductLoad();
        }
        public void ProductLoad()//Función para cargar los datos de los productos en la lista del carrito de compras
        {
            dtgvProducts.Rows.Clear();
                foreach (Product product in carShop.ProductsInCar)
                {
                    int n = dtgvProducts.Rows.Add();

                    dtgvProducts.Rows[n].Cells[0].Value = product.Id;
                    dtgvProducts.Rows[n].Cells[1].Value = product.Name;
                    dtgvProducts.Rows[n].Cells[2].Value = product.Price;
                    dtgvProducts.Rows[n].Cells[3].Value = product.Type;
                    dtgvProducts.Rows[n].Cells[4].Value = product.Description;
                    dtgvProducts.Rows[n].Cells[5].Value = product.Cantity;

                }
            
        }
        private void dtgvProducts_CellClick(object sender, DataGridViewCellEventArgs e)//Al seleccionar una celda, muestra los txt correspondientes a el producto seleccionado
        {
            int n = dtgvProducts.CurrentRow.Index;
            if (n != -1 && n != dtgvProducts.Rows.Count - 1)
            {
                if (dtgvProducts.Rows[n].Cells[3].Value.ToString() == "Hardware")
                {
                    txtMeassuresProduct.Show();
                    lblMeassuresProduct.Show();
                    txtModelProduct.Hide();
                    lblModelProduct.Hide();
                    txtLicenceProduct.Hide();
                    lblLicenceProduct.Hide();
                    txtVersionProduct.Hide();
                    lblVersionProduct.Hide();

                    foreach (Product product in carShop.ProductsInCar)
                    {
                        if (product.Id == dtgvProducts.Rows[n].Cells[0].Value.ToString())
                        {
                            txtIdProduct.Text = (string)dtgvProducts.Rows[n].Cells[0].Value;
                            txtNameProduct.Text = (string)dtgvProducts.Rows[n].Cells[1].Value;
                            txtPriceProduct.Text = dtgvProducts.Rows[n].Cells[2].Value.ToString();
                            txtTypeProduct.Text = (string)dtgvProducts.Rows[n].Cells[3].Value;
                            txtDescriptionProduct.Text = (string)dtgvProducts.Rows[n].Cells[4].Value;
                            txtCantityToSell.Text = dtgvProducts.Rows[n].Cells[5].Value.ToString();
                            txtMeassuresProduct.Text = product.Hard.Meassures.ToString();
                           
                        }
                    }
                }

                if (dtgvProducts.Rows[n].Cells[3].Value.ToString() == "Software")
                {
                    txtMeassuresProduct.Hide();
                    lblMeassuresProduct.Hide();
                    txtModelProduct.Hide();
                    lblModelProduct.Hide();
                    txtLicenceProduct.Show();
                    lblLicenceProduct.Show();
                    txtVersionProduct.Show();
                    lblVersionProduct.Show();
                    foreach (Product product in carShop.ProductsInCar)
                    {
                        if (product.Id == dtgvProducts.Rows[n].Cells[0].Value.ToString())
                        {
                            txtIdProduct.Text = (string)dtgvProducts.Rows[n].Cells[0].Value;
                            txtNameProduct.Text = (string)dtgvProducts.Rows[n].Cells[1].Value;
                            txtPriceProduct.Text = dtgvProducts.Rows[n].Cells[2].Value.ToString();
                            txtTypeProduct.Text = (string)dtgvProducts.Rows[n].Cells[3].Value;
                            txtDescriptionProduct.Text = (string)dtgvProducts.Rows[n].Cells[4].Value;
                            txtCantityToSell.Text = dtgvProducts.Rows[n].Cells[5].Value.ToString();
                            txtLicenceProduct.Text = product.Soft.Licence.ToString();
                            txtVersionProduct.Text = product.Soft.Version.ToString();
                           
                        }
                    }

                }
                if (dtgvProducts.Rows[n].Cells[3].Value.ToString() == "Device")
                {
                    txtMeassuresProduct.Hide();
                    lblMeassuresProduct.Hide();
                    txtModelProduct.Show();
                    lblModelProduct.Show();
                    txtLicenceProduct.Hide();
                    lblLicenceProduct.Hide();
                    txtVersionProduct.Hide();
                    lblVersionProduct.Hide();
                    foreach (Product product in carShop.ProductsInCar)
                    {
                        if (product.Id == dtgvProducts.Rows[n].Cells[0].Value.ToString())
                        {
                            txtIdProduct.Text = (string)dtgvProducts.Rows[n].Cells[0].Value;
                            txtNameProduct.Text = (string)dtgvProducts.Rows[n].Cells[1].Value;
                            txtPriceProduct.Text = dtgvProducts.Rows[n].Cells[2].Value.ToString();
                            txtTypeProduct.Text = (string)dtgvProducts.Rows[n].Cells[3].Value;
                            txtDescriptionProduct.Text = (string)dtgvProducts.Rows[n].Cells[4].Value;
                            txtCantityToSell.Text = dtgvProducts.Rows[n].Cells[5].Value.ToString();
                            txtModelProduct.Text = product.Devi.Model.ToString();

                        }
                    }
            }
        }
    }
        private static string _pathproduct = Path.GetFullPath(Path.Combine(Application.StartupPath, "..\\..", "Products.json"));
        
        private void btnDeleteSelectProduct_Click(object sender, EventArgs e)
        {
            var productsFromFile = ProductManageMenu.GetProductsFromFile();
            var products = JsonConvert.DeserializeObject<List<Product>>(productsFromFile);//Leemos el Json ya que haremos cambios dentro de el, para agregar de vuelta los productos eliminados

            int n = dtgvProducts.CurrentRow.Index;
            int cantitytodelete = int.Parse(txtCantityToSell.Text);//Será la cantidad que queramos eliminar de la lista
                string tomodify;
            if (n != -1 && n != dtgvProducts.Rows.Count - 1)
            {
                tomodify = (string)dtgvProducts.Rows[n].Cells[0].Value;//A el string le asignamos el valor de la celda[0] es decir, el id del producto seleccionado
                if (cantitytodelete > (int)dtgvProducts.Rows[n].Cells[5].Value)//Si la cantidad ingresada para eliminar es mayor a la disponible
                {
                    MessageBox.Show("La cantidad introducida es mayor a la inicial");
                }
                else//Caso contrario
                {
                    foreach (Product product in carShop.ProductsInCar.ToList())//Por cada producto en la lista
                                                                               //Aplicamos .ToList() igual que antes, que nos sirve de copia de carShop.ProductsInCar para poder cambiar los datos
                    {
                        if (tomodify == product.Id.ToString())//Si tomdify es igual a la id de un producto
                        {
                            product.Cantity -= cantitytodelete;//Restará la cantidad a borrar de el producto
                            foreach (Product productJson in products)//Por cada producto en products(El archivo Json)
                            {
                                if (tomodify == productJson.Id)//Si la id es igual a la de productJson
                                {
                                    productJson.Cantity += cantitytodelete;//Le sumará a el product en el Json la cantidad restada de el product en el carrito de compras
                                }
                            }
                            if (product.Cantity == 0)//Si la cantidad en la lista de el carrito, pasa a ser 0
                            {
                                carShop.ProductsInCar.Remove(product);//Removera a el producto de el carrito
                            }
                        }
                        
                    }
                    Clear();
                    ProductLoad();//Actializa el dtgv
                }
                
            }
            string productsJson = JsonConvert.SerializeObject(products.ToArray(), Formatting.Indented);
            File.WriteAllText(_pathproduct, productsJson);//Escribimos el Json para guardar cambios

            NewSaleMenu newsalemenu = new NewSaleMenu(); //Instanciamos un objeto NewSaleMenu 
            foreach (Form form in Application.OpenForms)//Buscaremos en cada form abierto en la aplicación
            {
                if (form is NewSaleMenu)//Si el form es de tipo NewSaleMenu
                {
                    newsalemenu = (NewSaleMenu)form;//Asignaremos a el objeto instanciado inicialmente el form encontrado en los forms abiertos
                    break;//Rompemos el ciclo
                }
            }//De esta manera podemos referirnos a el form NewSaleMenu activo y podemos trabajar con él mediante newsalemenu
             //En la cual le enviaremos los datos que recibirá y aplicará en ese form
            newsalemenu.BillCheck();
            newsalemenu.SaleLoad(carShop);//Utilizamos la funcion SaleLoad() de NewSaleMenu y le pasamos como parámetro 
            //El carrito actualizado con los productos seleccionados eliminados
            
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        public void SelectProductChecker()
        {
            if (txtTypeProduct.Text == "Device")
            {
                if (txtNameProduct.Text != string.Empty && txtDescriptionProduct.Text != string.Empty && txtCantityToSell.Text != string.Empty && txtPriceProduct.Text != string.Empty && txtModelProduct.Text != string.Empty)
                {
                    btnDeleteSelectProduct.Enabled = true;
                }
                else { btnDeleteSelectProduct.Enabled = false; }
            }
            if (txtTypeProduct.Text == "Hardware")
            {
                if (txtNameProduct.Text != string.Empty && txtDescriptionProduct.Text != string.Empty && txtCantityToSell.Text != string.Empty && txtPriceProduct.Text != string.Empty && txtMeassuresProduct.Text != string.Empty)
                {
                    btnDeleteSelectProduct.Enabled = true;
                }
                else { btnDeleteSelectProduct.Enabled = false; }
            }
            if (txtTypeProduct.Text == "Software")
            {
                if (txtNameProduct.Text != string.Empty && txtDescriptionProduct.Text != string.Empty && txtCantityToSell.Text != string.Empty && txtPriceProduct.Text != string.Empty && txtVersionProduct.Text != string.Empty && txtLicenceProduct.Text != string.Empty)
                {
                    btnDeleteSelectProduct.Enabled = true;
                }
                else { btnDeleteSelectProduct.Enabled = false; }
            }
        }

        private void txtNameProduct_TextChanged(object sender, EventArgs e)
        {
            SelectProductChecker();
        }
        int m, mx, my;
        private void pnlTopBorder_MouseDown(object sender, MouseEventArgs e)
        {
            m = 1;
            mx = e.X;
            my = e.Y;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string searchText = textBox1.Text.ToLower();

            int columnIndex = dtgvProducts.Columns["ProductName"].Index;

            try
            {
                foreach (DataGridViewRow row in dtgvProducts.Rows)
                {

                    bool found = false;

                    DataGridViewCell cell = row.Cells[columnIndex];



                    if (cell.Value != null && cell.Value.ToString().ToLower().Contains(searchText))
                    {
                        found = true;
                    }
                    row.Visible = found;
                }
            }
            catch (Exception a)
            {

            }
        }

        private void pnlTopBorder_MouseMove(object sender, MouseEventArgs e)
        {
            if (m == 1)
            {
                this.SetDesktopLocation(MousePosition.X - mx, MousePosition.Y - my);
            }
        }

        private void pnlTopBorder_MouseUp(object sender, MouseEventArgs e)
        {
            m = 0;
        }
        public void Clear()
        {
            txtCantityToSell.Text = string.Empty;
            txtDescriptionProduct.Text = string.Empty;
            txtIdProduct.Text = string.Empty;
            txtLicenceProduct.Text = string.Empty;
            txtMeassuresProduct.Text = string.Empty;
            txtModelProduct.Text = string.Empty;
            txtNameProduct.Text = string.Empty;
            txtPriceProduct.Text = string.Empty;
            txtTypeProduct.Text = string.Empty;
            txtVersionProduct.Text = string.Empty;
            
        }
    }
}
    
    

