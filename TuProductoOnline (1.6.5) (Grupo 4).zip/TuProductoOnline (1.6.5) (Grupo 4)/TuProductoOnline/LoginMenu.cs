﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace TuProductoOnline
{
    public partial class LoginMenu : Form
    {
        static bool logged = false;
        public LoginMenu()
        {
            InitializeComponent();

        }
        int m, mx, my;

        private void pnlTopBorder_MouseDown(object sender, MouseEventArgs e)
        {
            m = 1;
            mx = e.X;
            my = e.Y;
        }

        private void pnlTopBorder_MouseMove(object sender, MouseEventArgs e)
        {
            if (m == 1)
            {
                this.SetDesktopLocation(MousePosition.X - mx, MousePosition.Y - my);
            }
        }

        private void pnlTopBorder_MouseUp(object sender, MouseEventArgs e)
        {
            m = 0;
        }
        public static string _pathuser = Path.GetFullPath(Path.Combine(Application.StartupPath, "..\\..", "Users.json"));//Ruta en la que se encuentra el Users.json
        public static string _pathadmin = Path.GetFullPath(Path.Combine(Application.StartupPath, "..\\..", "Admins.json"));
        private void btExit_Click(object sender, EventArgs e) //Boton de cerrar el programa de login
        {
            if (MessageBox.Show("¿Está seguro que desea cerrar la aplicación?", "Cerrar programa", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                SessionClose();
                SessionCloseAdmin();
                foreach (Form form in Application.OpenForms.Cast<Form>().ToList())
                {
                    form.Close();
                }
            }
        }

        public static string GetUsersFromFile()//Este metodo lee el json y lo guarda en una variable
        {
            string usersJsonfromFile;//Declara la variable en la que se guardará el json
            using (var reader = new StreamReader(_pathuser))//Mediante el lector, se leerá todo el json y lo guardará en la variable
            {
                usersJsonfromFile = reader.ReadToEnd();
            }
            return usersJsonfromFile;//Devuelve el valor de la variable, que sería la lectura del json
        }
        public static string GetAdminsFromFile()//Este metodo lee el json y lo guarda en una variable
        {
            string adminsJsonfromFile;//Declara la variable en la que se guardará el json
            using (var reader = new StreamReader(_pathadmin))//Mediante el lector, se leerá todo el json y lo guardará en la variable
            {
                adminsJsonfromFile = reader.ReadToEnd();
            }
            return adminsJsonfromFile;//Devuelve el valor de la variable, que sería la lectura del json
        }
        private void bntValid_Click(object sender, EventArgs e)
        {
           SuperUser sup = new SuperUser();
            
            string user = txtUsername.Text;
            string password = txtPassword.Text;//Estas dos variables, son de los textbox del login
            if (sup.User == user && sup.Password.ToString() == password)
            {
                this.Hide();//Esconde el LoginMenu
                AdminMainWindow frmmain = new AdminMainWindow();//Instancia un form MainMenu
                frmmain.Show();//Muestra el MainMenu del Admin
                txtPassword.Text = string.Empty;
                txtUsername.Text = string.Empty;
            }

            else
            {
                var adminsfromfile = GetAdminsFromFile();//Aplica el metodo antes mencionado
                var admins = JsonConvert.DeserializeObject<List<Admin>>(adminsfromfile);
                
                var usersfromfile = GetUsersFromFile();//Aplica el metodo antes mencionado
                var users = JsonConvert.DeserializeObject<List<Employee>>(usersfromfile);//Deserializa la lectura del json en la variable anterior en forma de <List<Employee>> 

                if (users == null && admins==null)
                {
                    MessageBox.Show("Los datos ingresados son incorrectos");
                }
                if (admins != null)
                {
                    foreach (Admin admin in admins)
                    {
                        if (admin.User == user && admin.Password.ToString() == password)
                        {
                            if (admin.Enabled == true)
                            {
                                logged = true;
                                admin.ActiveSession = true;
                                string adminsJson = JsonConvert.SerializeObject(admins.ToArray(), Formatting.Indented);//Serializa el objeto en forma de users(Una lista) y lo guarda en la variable
                                File.WriteAllText(_pathadmin, adminsJson);
                                this.Hide();//Esconde el LoginMenu
                                AdminMainWindow frmmain = new AdminMainWindow();//Instancia un form MainMenu
                                frmmain.Show();//Muestra el MainMenu del Admin
                                txtPassword.Text = string.Empty;
                                txtUsername.Text = string.Empty;
                                break;
                            }
                            if (admin.Enabled != true)
                            {
                                MessageBox.Show("El usuario se encuentra deshabilitado");
                            }
                        }
                    }
                }
                if (user != null && logged==false)
                {
                    int count = 0;

                    foreach (Employee employee in users)//Para cada Employee en users(que es <List<Employee>>)
                    {
                        if (user == employee.User && password == employee.Password.ToString())//Si los valores introducidos en los textboxs son iguales a los valores de alguno de los clientes establecidos
                        {
                            if (employee.Enabled == true)
                            {
                                employee.ActiveSession = true;
                                string usersJson = JsonConvert.SerializeObject(users.ToArray(), Formatting.Indented);//Serializa el objeto en forma de users(Una lista) y lo guarda en la variable
                                File.WriteAllText(_pathuser, usersJson);
                                this.Hide();//Esconde el LoginMenu
                                MainWindow frmmain = new MainWindow();//Instancia un form MainMenu
                                frmmain.Show();//Muestra el MainMenu
                                txtPassword.Text = string.Empty;
                                txtUsername.Text = string.Empty;
                                break;
                            }
                            if (employee.Enabled != true)
                            {
                                MessageBox.Show("El usuario se encuentra deshabilitado");
                            }
                        }
                        else
                        {
                            count++;
                        }
                    }

                    if (count == users.Count)
                    {
                        MessageBox.Show("Los datos ingresados son incorrectos");
                        //En el caso de que los datos sean incorrectos, muestra este mensaje
                    }
                }
            }
        }
        public void LoginChecker()
        {
            if (txtUsername.Text != string.Empty && txtPassword.Text != string.Empty)
            {
                btnValid.Enabled = true;
            }
            else { btnValid.Enabled = false; }

        }

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {
            LoginChecker();
        }

        private void btnShowPassword_Click(object sender, EventArgs e)
        {
            if (txtPassword.PasswordChar == '*')
            {
                txtPassword.PasswordChar = '\0';
            }
            else
            {
                txtPassword.PasswordChar = '*';
            }
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {
            LoginChecker();
        }
        public static void SessionClose()
        {
            var usersfromfile = GetUsersFromFile();
            var users = JsonConvert.DeserializeObject<List<Employee>>(usersfromfile);
            foreach (Employee employee in users)
            {
                employee.ActiveSession = false;
            }
            string usersJson = JsonConvert.SerializeObject(users.ToArray(), Formatting.Indented);
            File.WriteAllText(_pathuser, usersJson);
            logged = false;
        }
        public static void SessionCloseAdmin()
        {
            var adminsfromfile = GetAdminsFromFile();//Aplica el metodo antes mencionado
            var admins = JsonConvert.DeserializeObject<List<Admin>>(adminsfromfile);

            foreach (Admin admin in admins)
            {
                admin.ActiveSession = false;
            }
            string adminsJson = JsonConvert.SerializeObject(admins.ToArray(), Formatting.Indented);//Serializa el objeto en forma de users(Una lista) y lo guarda en la variable
            File.WriteAllText(_pathadmin, adminsJson);
            logged = false;
        }
    }
}
