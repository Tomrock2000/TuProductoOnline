﻿namespace TuProductoOnline
{
    partial class MainMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainMenu));
            this.pnlGraphic = new System.Windows.Forms.Panel();
            this.cBarGraphic = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.pnlGraphicDecorativeLine = new System.Windows.Forms.Panel();
            this.pbGraphicFrame = new System.Windows.Forms.PictureBox();
            this.pnlLastClientAdded = new System.Windows.Forms.Panel();
            this.pbClientImage = new System.Windows.Forms.PictureBox();
            this.lblLastClientAdded = new System.Windows.Forms.Label();
            this.lblClientAdress = new System.Windows.Forms.Label();
            this.lblClientNationalID = new System.Windows.Forms.Label();
            this.lblClientName = new System.Windows.Forms.Label();
            this.pnlLastClientAddedDecorativeLine = new System.Windows.Forms.Panel();
            this.pbLastClientAddedFrame = new System.Windows.Forms.PictureBox();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.pnlSummary = new System.Windows.Forms.Panel();
            this.lblTotalAmountBilled = new System.Windows.Forms.Label();
            this.lblTotalSalesAmount = new System.Windows.Forms.Label();
            this.lblTotalClientsAddedAmount = new System.Windows.Forms.Label();
            this.pnlSummaryDecorativeLine = new System.Windows.Forms.Panel();
            this.pbSummaryFrame = new System.Windows.Forms.PictureBox();
            this.pbUserImage = new System.Windows.Forms.PictureBox();
            this.timerHours = new System.Windows.Forms.Timer(this.components);
            this.lblDays = new System.Windows.Forms.Label();
            this.lblHours = new System.Windows.Forms.Label();
            this.pnlGraphic.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cBarGraphic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbGraphicFrame)).BeginInit();
            this.pnlLastClientAdded.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbClientImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLastClientAddedFrame)).BeginInit();
            this.pnlSummary.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbSummaryFrame)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbUserImage)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlGraphic
            // 
            this.pnlGraphic.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pnlGraphic.BackColor = System.Drawing.Color.Transparent;
            this.pnlGraphic.Controls.Add(this.cBarGraphic);
            this.pnlGraphic.Controls.Add(this.pnlGraphicDecorativeLine);
            this.pnlGraphic.Controls.Add(this.pbGraphicFrame);
            this.pnlGraphic.Location = new System.Drawing.Point(84, 304);
            this.pnlGraphic.Name = "pnlGraphic";
            this.pnlGraphic.Size = new System.Drawing.Size(465, 197);
            this.pnlGraphic.TabIndex = 26;
            // 
            // cBarGraphic
            // 
            this.cBarGraphic.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cBarGraphic.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(234)))), ((int)(((byte)(199)))));
            this.cBarGraphic.BorderlineColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(234)))), ((int)(((byte)(199)))));
            chartArea1.AxisX.IsLabelAutoFit = false;
            chartArea1.AxisX.LabelStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea1.AxisY.IsLabelAutoFit = false;
            chartArea1.AxisY.LabelStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea1.AxisY.LabelStyle.Format = "N0";
            chartArea1.Name = "ChartArea1";
            this.cBarGraphic.ChartAreas.Add(chartArea1);
            this.cBarGraphic.Location = new System.Drawing.Point(10, 22);
            this.cBarGraphic.Name = "cBarGraphic";
            this.cBarGraphic.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.None;
            this.cBarGraphic.PaletteCustomColors = new System.Drawing.Color[] {
        System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248))))),
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(103))))),
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(248)))))};
            series1.ChartArea = "ChartArea1";
            series1.Name = "Series1";
            this.cBarGraphic.Series.Add(series1);
            this.cBarGraphic.Size = new System.Drawing.Size(446, 166);
            this.cBarGraphic.TabIndex = 14;
            this.cBarGraphic.Text = "chart1";
            // 
            // pnlGraphicDecorativeLine
            // 
            this.pnlGraphicDecorativeLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(59)))), ((int)(((byte)(84)))));
            this.pnlGraphicDecorativeLine.Location = new System.Drawing.Point(24, 12);
            this.pnlGraphicDecorativeLine.Name = "pnlGraphicDecorativeLine";
            this.pnlGraphicDecorativeLine.Size = new System.Drawing.Size(415, 5);
            this.pnlGraphicDecorativeLine.TabIndex = 13;
            // 
            // pbGraphicFrame
            // 
            this.pbGraphicFrame.BackColor = System.Drawing.Color.Transparent;
            this.pbGraphicFrame.Image = ((System.Drawing.Image)(resources.GetObject("pbGraphicFrame.Image")));
            this.pbGraphicFrame.Location = new System.Drawing.Point(0, 0);
            this.pbGraphicFrame.Name = "pbGraphicFrame";
            this.pbGraphicFrame.Size = new System.Drawing.Size(465, 197);
            this.pbGraphicFrame.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbGraphicFrame.TabIndex = 12;
            this.pbGraphicFrame.TabStop = false;
            // 
            // pnlLastClientAdded
            // 
            this.pnlLastClientAdded.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pnlLastClientAdded.BackColor = System.Drawing.Color.Transparent;
            this.pnlLastClientAdded.Controls.Add(this.pbClientImage);
            this.pnlLastClientAdded.Controls.Add(this.lblLastClientAdded);
            this.pnlLastClientAdded.Controls.Add(this.lblClientAdress);
            this.pnlLastClientAdded.Controls.Add(this.lblClientNationalID);
            this.pnlLastClientAdded.Controls.Add(this.lblClientName);
            this.pnlLastClientAdded.Controls.Add(this.pnlLastClientAddedDecorativeLine);
            this.pnlLastClientAdded.Controls.Add(this.pbLastClientAddedFrame);
            this.pnlLastClientAdded.Location = new System.Drawing.Point(662, 304);
            this.pnlLastClientAdded.Name = "pnlLastClientAdded";
            this.pnlLastClientAdded.Size = new System.Drawing.Size(251, 197);
            this.pnlLastClientAdded.TabIndex = 27;
            // 
            // pbClientImage
            // 
            this.pbClientImage.BackColor = System.Drawing.Color.Transparent;
            this.pbClientImage.Image = ((System.Drawing.Image)(resources.GetObject("pbClientImage.Image")));
            this.pbClientImage.Location = new System.Drawing.Point(155, 48);
            this.pbClientImage.Name = "pbClientImage";
            this.pbClientImage.Size = new System.Drawing.Size(75, 75);
            this.pbClientImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbClientImage.TabIndex = 18;
            this.pbClientImage.TabStop = false;
            // 
            // lblLastClientAdded
            // 
            this.lblLastClientAdded.AutoSize = true;
            this.lblLastClientAdded.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.lblLastClientAdded.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblLastClientAdded.Location = new System.Drawing.Point(56, 22);
            this.lblLastClientAdded.Name = "lblLastClientAdded";
            this.lblLastClientAdded.Size = new System.Drawing.Size(137, 17);
            this.lblLastClientAdded.TabIndex = 23;
            this.lblLastClientAdded.Text = "Ultimo Cliente Ag.";
            // 
            // lblClientAdress
            // 
            this.lblClientAdress.AutoSize = true;
            this.lblClientAdress.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblClientAdress.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblClientAdress.Location = new System.Drawing.Point(17, 156);
            this.lblClientAdress.Name = "lblClientAdress";
            this.lblClientAdress.Size = new System.Drawing.Size(70, 16);
            this.lblClientAdress.TabIndex = 22;
            this.lblClientAdress.Text = "Dirección: ";
            // 
            // lblClientNationalID
            // 
            this.lblClientNationalID.AutoSize = true;
            this.lblClientNationalID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblClientNationalID.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblClientNationalID.Location = new System.Drawing.Point(17, 131);
            this.lblClientNationalID.Name = "lblClientNationalID";
            this.lblClientNationalID.Size = new System.Drawing.Size(131, 16);
            this.lblClientNationalID.TabIndex = 21;
            this.lblClientNationalID.Text = "Cédula: V-00.000.000";
            // 
            // lblClientName
            // 
            this.lblClientName.AutoSize = true;
            this.lblClientName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.lblClientName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblClientName.Location = new System.Drawing.Point(16, 48);
            this.lblClientName.Name = "lblClientName";
            this.lblClientName.Size = new System.Drawing.Size(97, 40);
            this.lblClientName.TabIndex = 19;
            this.lblClientName.Text = "No has Ag.\r\nun Cliente\r\n";
            // 
            // pnlLastClientAddedDecorativeLine
            // 
            this.pnlLastClientAddedDecorativeLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(59)))), ((int)(((byte)(84)))));
            this.pnlLastClientAddedDecorativeLine.Location = new System.Drawing.Point(20, 12);
            this.pnlLastClientAddedDecorativeLine.Name = "pnlLastClientAddedDecorativeLine";
            this.pnlLastClientAddedDecorativeLine.Size = new System.Drawing.Size(210, 5);
            this.pnlLastClientAddedDecorativeLine.TabIndex = 13;
            // 
            // pbLastClientAddedFrame
            // 
            this.pbLastClientAddedFrame.BackColor = System.Drawing.Color.Transparent;
            this.pbLastClientAddedFrame.Image = ((System.Drawing.Image)(resources.GetObject("pbLastClientAddedFrame.Image")));
            this.pbLastClientAddedFrame.Location = new System.Drawing.Point(0, 0);
            this.pbLastClientAddedFrame.Name = "pbLastClientAddedFrame";
            this.pbLastClientAddedFrame.Size = new System.Drawing.Size(251, 197);
            this.pbLastClientAddedFrame.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbLastClientAddedFrame.TabIndex = 12;
            this.pbLastClientAddedFrame.TabStop = false;
            // 
            // lblWelcome
            // 
            this.lblWelcome.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.BackColor = System.Drawing.Color.Transparent;
            this.lblWelcome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblWelcome.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold);
            this.lblWelcome.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblWelcome.Location = new System.Drawing.Point(342, 28);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(320, 29);
            this.lblWelcome.TabIndex = 28;
            this.lblWelcome.Text = "Bienvenido, Administrador";
            this.lblWelcome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlSummary
            // 
            this.pnlSummary.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pnlSummary.BackColor = System.Drawing.Color.Transparent;
            this.pnlSummary.Controls.Add(this.lblTotalAmountBilled);
            this.pnlSummary.Controls.Add(this.lblTotalSalesAmount);
            this.pnlSummary.Controls.Add(this.lblTotalClientsAddedAmount);
            this.pnlSummary.Controls.Add(this.pnlSummaryDecorativeLine);
            this.pnlSummary.Controls.Add(this.pbSummaryFrame);
            this.pnlSummary.Location = new System.Drawing.Point(498, 98);
            this.pnlSummary.Name = "pnlSummary";
            this.pnlSummary.Size = new System.Drawing.Size(415, 163);
            this.pnlSummary.TabIndex = 25;
            // 
            // lblTotalAmountBilled
            // 
            this.lblTotalAmountBilled.AutoSize = true;
            this.lblTotalAmountBilled.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalAmountBilled.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblTotalAmountBilled.Location = new System.Drawing.Point(21, 120);
            this.lblTotalAmountBilled.Name = "lblTotalAmountBilled";
            this.lblTotalAmountBilled.Size = new System.Drawing.Size(221, 20);
            this.lblTotalAmountBilled.TabIndex = 16;
            this.lblTotalAmountBilled.Text = "Monto Total Facturado: 0$";
            // 
            // lblTotalSalesAmount
            // 
            this.lblTotalSalesAmount.AutoSize = true;
            this.lblTotalSalesAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalSalesAmount.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblTotalSalesAmount.Location = new System.Drawing.Point(21, 74);
            this.lblTotalSalesAmount.Name = "lblTotalSalesAmount";
            this.lblTotalSalesAmount.Size = new System.Drawing.Size(330, 20);
            this.lblTotalSalesAmount.TabIndex = 15;
            this.lblTotalSalesAmount.Text = "Número Total de Ventas Concretadas: 0";
            // 
            // lblTotalClientsAddedAmount
            // 
            this.lblTotalClientsAddedAmount.AutoSize = true;
            this.lblTotalClientsAddedAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalClientsAddedAmount.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblTotalClientsAddedAmount.Location = new System.Drawing.Point(20, 29);
            this.lblTotalClientsAddedAmount.Name = "lblTotalClientsAddedAmount";
            this.lblTotalClientsAddedAmount.Size = new System.Drawing.Size(311, 20);
            this.lblTotalClientsAddedAmount.TabIndex = 14;
            this.lblTotalClientsAddedAmount.Text = "Número Total de Clientes Añadidos: 0";
            // 
            // pnlSummaryDecorativeLine
            // 
            this.pnlSummaryDecorativeLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(59)))), ((int)(((byte)(84)))));
            this.pnlSummaryDecorativeLine.Location = new System.Drawing.Point(24, 9);
            this.pnlSummaryDecorativeLine.Name = "pnlSummaryDecorativeLine";
            this.pnlSummaryDecorativeLine.Size = new System.Drawing.Size(365, 5);
            this.pnlSummaryDecorativeLine.TabIndex = 13;
            // 
            // pbSummaryFrame
            // 
            this.pbSummaryFrame.BackColor = System.Drawing.Color.Transparent;
            this.pbSummaryFrame.Image = ((System.Drawing.Image)(resources.GetObject("pbSummaryFrame.Image")));
            this.pbSummaryFrame.Location = new System.Drawing.Point(0, 0);
            this.pbSummaryFrame.Name = "pbSummaryFrame";
            this.pbSummaryFrame.Size = new System.Drawing.Size(415, 163);
            this.pbSummaryFrame.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSummaryFrame.TabIndex = 12;
            this.pbSummaryFrame.TabStop = false;
            // 
            // pbUserImage
            // 
            this.pbUserImage.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pbUserImage.BackColor = System.Drawing.Color.Transparent;
            this.pbUserImage.Image = ((System.Drawing.Image)(resources.GetObject("pbUserImage.Image")));
            this.pbUserImage.Location = new System.Drawing.Point(177, 98);
            this.pbUserImage.Name = "pbUserImage";
            this.pbUserImage.Size = new System.Drawing.Size(163, 163);
            this.pbUserImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbUserImage.TabIndex = 24;
            this.pbUserImage.TabStop = false;
            // 
            // timerHours
            // 
            this.timerHours.Enabled = true;
            this.timerHours.Tick += new System.EventHandler(this.timerHours_Tick);
            // 
            // lblDays
            // 
            this.lblDays.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblDays.AutoSize = true;
            this.lblDays.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDays.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblDays.Location = new System.Drawing.Point(344, 273);
            this.lblDays.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDays.Name = "lblDays";
            this.lblDays.Size = new System.Drawing.Size(46, 15);
            this.lblDays.TabIndex = 32;
            this.lblDays.Text = "Fecha";
            // 
            // lblHours
            // 
            this.lblHours.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblHours.AutoSize = true;
            this.lblHours.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHours.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblHours.Location = new System.Drawing.Point(591, 273);
            this.lblHours.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblHours.Name = "lblHours";
            this.lblHours.Size = new System.Drawing.Size(38, 15);
            this.lblHours.TabIndex = 31;
            this.lblHours.Text = "Hora";
            // 
            // MainMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(234)))), ((int)(((byte)(199)))));
            this.ClientSize = new System.Drawing.Size(1030, 560);
            this.Controls.Add(this.lblDays);
            this.Controls.Add(this.lblHours);
            this.Controls.Add(this.pnlGraphic);
            this.Controls.Add(this.pnlLastClientAdded);
            this.Controls.Add(this.lblWelcome);
            this.Controls.Add(this.pnlSummary);
            this.Controls.Add(this.pbUserImage);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "MainMenu";
            this.Text = "MainMenu";
            this.Load += new System.EventHandler(this.MainMenu_Load);
            this.Click += new System.EventHandler(this.MainMenu_Click);
            this.Enter += new System.EventHandler(this.MainMenu_Enter);
            this.MouseEnter += new System.EventHandler(this.MainMenu_Enter);
            this.pnlGraphic.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.cBarGraphic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbGraphicFrame)).EndInit();
            this.pnlLastClientAdded.ResumeLayout(false);
            this.pnlLastClientAdded.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbClientImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLastClientAddedFrame)).EndInit();
            this.pnlSummary.ResumeLayout(false);
            this.pnlSummary.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbSummaryFrame)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbUserImage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlGraphic;
        private System.Windows.Forms.Panel pnlGraphicDecorativeLine;
        private System.Windows.Forms.PictureBox pbGraphicFrame;
        private System.Windows.Forms.Panel pnlLastClientAdded;
        private System.Windows.Forms.PictureBox pbClientImage;
        private System.Windows.Forms.Label lblLastClientAdded;
        private System.Windows.Forms.Label lblClientAdress;
        private System.Windows.Forms.Label lblClientNationalID;
        private System.Windows.Forms.Label lblClientName;
        private System.Windows.Forms.Panel pnlLastClientAddedDecorativeLine;
        private System.Windows.Forms.PictureBox pbLastClientAddedFrame;
        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.Panel pnlSummary;
        private System.Windows.Forms.Label lblTotalAmountBilled;
        private System.Windows.Forms.Label lblTotalSalesAmount;
        private System.Windows.Forms.Label lblTotalClientsAddedAmount;
        private System.Windows.Forms.Panel pnlSummaryDecorativeLine;
        private System.Windows.Forms.PictureBox pbSummaryFrame;
        private System.Windows.Forms.PictureBox pbUserImage;
        private System.Windows.Forms.Timer timerHours;
        private System.Windows.Forms.Label lblDays;
        private System.Windows.Forms.Label lblHours;
        private System.Windows.Forms.DataVisualization.Charting.Chart cBarGraphic;
    }
}