﻿using iTextSharp.tool.xml.html.head;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace TuProductoOnline
{
    public partial class MainMenu : Form
    {
        public MainMenu()
        {
            InitializeComponent();
            MenuCheck();

        }
        public void MenuCheck()
        {
            var usersfromfile = LoginMenu.GetUsersFromFile();
            var users = JsonConvert.DeserializeObject<List<Employee>>(usersfromfile);
            var adminsfromfile = GetAdminsFromFile();//Aplica el metodo antes mencionado
            var admins = JsonConvert.DeserializeObject<List<Admin>>(adminsfromfile);
            if (users != null)
            {
                foreach (Employee employee in users)
                {
                    if (employee.ActiveSession == true)
                    {
                        lblWelcome.Text = $"Bienvenido, {employee.Name} {employee.LastName}";
                        lblTotalClientsAddedAmount.Text = $"Número Total de Clientes Añadidos: {employee.AddedClients}";
                        lblTotalSalesAmount.Text = $"Número Total de Ventas Concretadas: {employee.ConcludedSales}";
                        lblTotalAmountBilled.Text = $"Monto Total Facturado: {employee.BilledAmount}$";
                        if (employee.LastAddedClient != null)
                        {
                            lblClientName.Visible = true;
                            lblClientNationalID.Visible = true;
                            lblClientAdress.Visible = true;
                            lblClientName.Text = $"{employee.LastAddedClient.Name},\n{employee.LastAddedClient.LastName}";
                            lblClientNationalID.Text = $"Cédula:{employee.LastAddedClient.Id}";
                            lblClientAdress.Text = $"{employee.LastAddedClient.Address}";

                        }
                        else
                        {
                            lblLastClientAdded.Text = "Todavía no has \nañadido ningun \ncliente";
                            lblClientName.Visible = false;
                            lblClientNationalID.Visible = false;
                            lblClientAdress.Visible = false;
                        }
                    }
                }
            }
            if (admins != null)
            {
                foreach (Admin admin in admins)
                {
                    if (admin.ActiveSession == true)
                    {
                        lblWelcome.Text = $"Bienvenido, {admin.Name} {admin.LastName}";
                    }
                }
            }
        }
        public static string _pathadmin = Path.GetFullPath(Path.Combine(Application.StartupPath, "..\\..", "Admins.json"));
        private void timerHours_Tick(object sender, EventArgs e)
        {
            lblDays.Text = DateTime.Today.ToString("dddd, dd 'd'e MMMM 'd'e yyyy");
            lblHours.Text = DateTime.Now.ToString("HH:mm:ss");
        }

        private void MainMenu_Enter(object sender, EventArgs e)
        {
            MenuCheck();
            Graphic();
        }

        private void MainMenu_Click(object sender, EventArgs e)
        {
            MenuCheck();
        }

        private void MainMenu_Load(object sender, EventArgs e)
        {
            Graphic();
        }
        private static string _pathbills = Path.GetFullPath(Path.Combine(Application.StartupPath, "..\\..", "BillsRegistry.json"));
        public static string GetBillsRegistryFromFile()//Lee el json de el registro
        {
            string billsJsonFromFile;
            using (var reader = new StreamReader(_pathbills))
            {
                billsJsonFromFile = reader.ReadToEnd();
            }
            return billsJsonFromFile;
        }
        public static string GetAdminsFromFile()//Este metodo lee el json y lo guarda en una variable
        {
            string adminsJsonfromFile;//Declara la variable en la que se guardará el json
            using (var reader = new StreamReader(_pathadmin))//Mediante el lector, se leerá todo el json y lo guardará en la variable
            {
                adminsJsonfromFile = reader.ReadToEnd();
            }
            return adminsJsonfromFile;//Devuelve el valor de la variable, que sería la lectura del json
        }
        private void Graphic()
        {
            cBarGraphic.Titles.Clear();
            cBarGraphic.Series.Clear();
            cBarGraphic.Titles.Add("Gráfico de Ventas (Ult. 7 Días)");
            
            var billsFromFile = GetBillsRegistryFromFile();
            var bills = JsonConvert.DeserializeObject<List<Bill>>(billsFromFile);
            var usersfromfile = LoginMenu.GetUsersFromFile();
            var users = JsonConvert.DeserializeObject<List<Employee>>(usersfromfile);

            Employee activeUser = new Employee();

            foreach (Employee user in users)
            {
                if (user.ActiveSession == true)
                {
                    activeUser = user;
                }
            }
            
            Series series = new Series();
            cBarGraphic.Series.Add(series);
            cBarGraphic.Font = new Font("Microsoft Sans Serif", 9, FontStyle.Bold);
            /*for (int i = 0; i < 7; i++)
            {
                string day = (DateTime.Today.AddDays(-i)).ToString("dd/MM");
                series = cBarGraphic.Series.Add(day);
            }*/
            for (int i = 6; i >= 0; i--)
            {
                int count = 0;
                foreach (Bill bill in bills)
                {
                    if (bill.BillDate == (DateTime.Today.AddDays(-i)) && bill.EmployeSale.Name == activeUser.Name)
                    {
                        count++;
                    }
                }
                series.Points.AddXY((DateTime.Today.AddDays(-i)).ToString("dd/MM"), count);
            }
        }
    }
}
