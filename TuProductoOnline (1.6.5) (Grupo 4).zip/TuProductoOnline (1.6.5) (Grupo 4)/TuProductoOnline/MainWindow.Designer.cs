﻿namespace TuProductoOnline
{
    partial class MainWindow
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainWindow));
            this.tmHideMenu = new System.Windows.Forms.Timer(this.components);
            this.tmShowMenu = new System.Windows.Forms.Timer(this.components);
            this.pnlBottomBorder = new System.Windows.Forms.Panel();
            this.pnlRightBorder = new System.Windows.Forms.Panel();
            this.pnlTopBorder = new System.Windows.Forms.Panel();
            this.btnMinimize = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnMaximize = new System.Windows.Forms.Button();
            this.btnRestore = new System.Windows.Forms.Button();
            this.pnlProductManage = new System.Windows.Forms.Panel();
            this.pbProductManage = new System.Windows.Forms.PictureBox();
            this.btnProductManage = new System.Windows.Forms.Button();
            this.pnlProductManageDecorativeLine = new System.Windows.Forms.Panel();
            this.pnlClientManage = new System.Windows.Forms.Panel();
            this.pbClientManage = new System.Windows.Forms.PictureBox();
            this.btnClientManage = new System.Windows.Forms.Button();
            this.pnlClientManageDecorativeLine = new System.Windows.Forms.Panel();
            this.pnlNewSale = new System.Windows.Forms.Panel();
            this.pbNewSale = new System.Windows.Forms.PictureBox();
            this.btnNewSale = new System.Windows.Forms.Button();
            this.pnlNewSaleDecorativeLine = new System.Windows.Forms.Panel();
            this.pnlMainWindow = new System.Windows.Forms.Panel();
            this.pbMainMenu = new System.Windows.Forms.PictureBox();
            this.btnMainMenu = new System.Windows.Forms.Button();
            this.pnlMainMenuDecorativeLine = new System.Windows.Forms.Panel();
            this.pnlLogOut = new System.Windows.Forms.Panel();
            this.pbLogOut = new System.Windows.Forms.PictureBox();
            this.btnLogOut = new System.Windows.Forms.Button();
            this.pnlLogOutDecorativeLine = new System.Windows.Forms.Panel();
            this.panelMenu = new System.Windows.Forms.Panel();
            this.pbMenu = new System.Windows.Forms.PictureBox();
            this.pbMenu2 = new System.Windows.Forms.PictureBox();
            this.pbLogo = new System.Windows.Forms.PictureBox();
            this.pnlBackground = new System.Windows.Forms.Panel();
            this.pnlTopBorder.SuspendLayout();
            this.pnlProductManage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbProductManage)).BeginInit();
            this.pnlClientManage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbClientManage)).BeginInit();
            this.pnlNewSale.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbNewSale)).BeginInit();
            this.pnlMainWindow.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbMainMenu)).BeginInit();
            this.pnlLogOut.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbLogOut)).BeginInit();
            this.panelMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbMenu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMenu2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // tmHideMenu
            // 
            this.tmHideMenu.Interval = 1;
            this.tmHideMenu.Tick += new System.EventHandler(this.tmHideMenu_Tick);
            // 
            // tmShowMenu
            // 
            this.tmShowMenu.Interval = 1;
            this.tmShowMenu.Tick += new System.EventHandler(this.tmShowMenu_Tick);
            // 
            // pnlBottomBorder
            // 
            this.pnlBottomBorder.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.pnlBottomBorder.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottomBorder.Location = new System.Drawing.Point(0, 590);
            this.pnlBottomBorder.Name = "pnlBottomBorder";
            this.pnlBottomBorder.Size = new System.Drawing.Size(1200, 10);
            this.pnlBottomBorder.TabIndex = 4;
            // 
            // pnlRightBorder
            // 
            this.pnlRightBorder.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.pnlRightBorder.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnlRightBorder.Location = new System.Drawing.Point(1190, 0);
            this.pnlRightBorder.Name = "pnlRightBorder";
            this.pnlRightBorder.Size = new System.Drawing.Size(10, 590);
            this.pnlRightBorder.TabIndex = 3;
            // 
            // pnlTopBorder
            // 
            this.pnlTopBorder.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.pnlTopBorder.Controls.Add(this.btnMinimize);
            this.pnlTopBorder.Controls.Add(this.btnExit);
            this.pnlTopBorder.Controls.Add(this.btnMaximize);
            this.pnlTopBorder.Controls.Add(this.btnRestore);
            this.pnlTopBorder.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTopBorder.Location = new System.Drawing.Point(0, 0);
            this.pnlTopBorder.Name = "pnlTopBorder";
            this.pnlTopBorder.Size = new System.Drawing.Size(1190, 30);
            this.pnlTopBorder.TabIndex = 5;
            this.pnlTopBorder.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlTopBorder_MouseDown);
            this.pnlTopBorder.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pnlTopBorder_MouseMove);
            this.pnlTopBorder.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pnlTopBorder_MouseUp);
            // 
            // btnMinimize
            // 
            this.btnMinimize.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMinimize.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.btnMinimize.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMinimize.FlatAppearance.BorderSize = 0;
            this.btnMinimize.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btnMinimize.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(73)))), ((int)(((byte)(73)))));
            this.btnMinimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMinimize.ForeColor = System.Drawing.Color.White;
            this.btnMinimize.Image = ((System.Drawing.Image)(resources.GetObject("btnMinimize.Image")));
            this.btnMinimize.Location = new System.Drawing.Point(1083, -1);
            this.btnMinimize.Margin = new System.Windows.Forms.Padding(2);
            this.btnMinimize.Name = "btnMinimize";
            this.btnMinimize.Size = new System.Drawing.Size(33, 31);
            this.btnMinimize.TabIndex = 6;
            this.btnMinimize.UseVisualStyleBackColor = false;
            this.btnMinimize.Click += new System.EventHandler(this.btnMinimize_Click);
            // 
            // btnExit
            // 
            this.btnExit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExit.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.btnExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExit.FlatAppearance.BorderSize = 0;
            this.btnExit.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btnExit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExit.ForeColor = System.Drawing.Color.White;
            this.btnExit.Image = ((System.Drawing.Image)(resources.GetObject("btnExit.Image")));
            this.btnExit.Location = new System.Drawing.Point(1158, 0);
            this.btnExit.Margin = new System.Windows.Forms.Padding(2);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(33, 31);
            this.btnExit.TabIndex = 8;
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btExitMainMenu_Click);
            // 
            // btnMaximize
            // 
            this.btnMaximize.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMaximize.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.btnMaximize.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMaximize.FlatAppearance.BorderSize = 0;
            this.btnMaximize.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btnMaximize.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(73)))), ((int)(((byte)(73)))));
            this.btnMaximize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMaximize.ForeColor = System.Drawing.Color.White;
            this.btnMaximize.Image = ((System.Drawing.Image)(resources.GetObject("btnMaximize.Image")));
            this.btnMaximize.Location = new System.Drawing.Point(1121, 0);
            this.btnMaximize.Margin = new System.Windows.Forms.Padding(2);
            this.btnMaximize.Name = "btnMaximize";
            this.btnMaximize.Size = new System.Drawing.Size(33, 31);
            this.btnMaximize.TabIndex = 7;
            this.btnMaximize.UseVisualStyleBackColor = false;
            this.btnMaximize.Click += new System.EventHandler(this.btnMaximize_Click);
            // 
            // btnRestore
            // 
            this.btnRestore.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRestore.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.btnRestore.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRestore.FlatAppearance.BorderSize = 0;
            this.btnRestore.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btnRestore.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(73)))), ((int)(((byte)(73)))));
            this.btnRestore.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRestore.ForeColor = System.Drawing.Color.White;
            this.btnRestore.Image = ((System.Drawing.Image)(resources.GetObject("btnRestore.Image")));
            this.btnRestore.Location = new System.Drawing.Point(1121, 0);
            this.btnRestore.Margin = new System.Windows.Forms.Padding(2);
            this.btnRestore.Name = "btnRestore";
            this.btnRestore.Size = new System.Drawing.Size(33, 31);
            this.btnRestore.TabIndex = 21;
            this.btnRestore.UseVisualStyleBackColor = false;
            this.btnRestore.Click += new System.EventHandler(this.btnRestore_Click);
            // 
            // pnlProductManage
            // 
            this.pnlProductManage.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.pnlProductManage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.pnlProductManage.Controls.Add(this.pbProductManage);
            this.pnlProductManage.Controls.Add(this.btnProductManage);
            this.pnlProductManage.Location = new System.Drawing.Point(0, 175);
            this.pnlProductManage.Name = "pnlProductManage";
            this.pnlProductManage.Size = new System.Drawing.Size(160, 50);
            this.pnlProductManage.TabIndex = 31;
            // 
            // pbProductManage
            // 
            this.pbProductManage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbProductManage.Image = ((System.Drawing.Image)(resources.GetObject("pbProductManage.Image")));
            this.pbProductManage.Location = new System.Drawing.Point(12, 6);
            this.pbProductManage.Name = "pbProductManage";
            this.pbProductManage.Size = new System.Drawing.Size(35, 35);
            this.pbProductManage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbProductManage.TabIndex = 0;
            this.pbProductManage.TabStop = false;
            this.pbProductManage.Click += new System.EventHandler(this.btnProductManage_Click);
            this.pbProductManage.MouseEnter += new System.EventHandler(this.btnProductManage_MouseEnter);
            this.pbProductManage.MouseLeave += new System.EventHandler(this.btnProductManage_MouseLeave);
            // 
            // btnProductManage
            // 
            this.btnProductManage.BackColor = System.Drawing.Color.Transparent;
            this.btnProductManage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnProductManage.FlatAppearance.BorderSize = 0;
            this.btnProductManage.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.btnProductManage.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(139)))), ((int)(((byte)(250)))));
            this.btnProductManage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProductManage.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProductManage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.btnProductManage.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnProductManage.Location = new System.Drawing.Point(-2, 0);
            this.btnProductManage.Margin = new System.Windows.Forms.Padding(2);
            this.btnProductManage.Name = "btnProductManage";
            this.btnProductManage.Size = new System.Drawing.Size(162, 50);
            this.btnProductManage.TabIndex = 2;
            this.btnProductManage.Text = "Gestión de\r\nProductos\r\n";
            this.btnProductManage.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnProductManage.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnProductManage.UseVisualStyleBackColor = false;
            this.btnProductManage.Click += new System.EventHandler(this.btnProductManage_Click);
            this.btnProductManage.MouseEnter += new System.EventHandler(this.btnProductManage_MouseEnter);
            this.btnProductManage.MouseLeave += new System.EventHandler(this.btnProductManage_MouseLeave);
            // 
            // pnlProductManageDecorativeLine
            // 
            this.pnlProductManageDecorativeLine.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.pnlProductManageDecorativeLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(234)))), ((int)(((byte)(199)))));
            this.pnlProductManageDecorativeLine.Location = new System.Drawing.Point(0, 175);
            this.pnlProductManageDecorativeLine.Margin = new System.Windows.Forms.Padding(2);
            this.pnlProductManageDecorativeLine.Name = "pnlProductManageDecorativeLine";
            this.pnlProductManageDecorativeLine.Size = new System.Drawing.Size(4, 50);
            this.pnlProductManageDecorativeLine.TabIndex = 24;
            // 
            // pnlClientManage
            // 
            this.pnlClientManage.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.pnlClientManage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.pnlClientManage.Controls.Add(this.pbClientManage);
            this.pnlClientManage.Controls.Add(this.btnClientManage);
            this.pnlClientManage.Location = new System.Drawing.Point(0, 231);
            this.pnlClientManage.Name = "pnlClientManage";
            this.pnlClientManage.Size = new System.Drawing.Size(160, 50);
            this.pnlClientManage.TabIndex = 33;
            // 
            // pbClientManage
            // 
            this.pbClientManage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbClientManage.Image = ((System.Drawing.Image)(resources.GetObject("pbClientManage.Image")));
            this.pbClientManage.Location = new System.Drawing.Point(12, 7);
            this.pbClientManage.Name = "pbClientManage";
            this.pbClientManage.Size = new System.Drawing.Size(35, 35);
            this.pbClientManage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbClientManage.TabIndex = 0;
            this.pbClientManage.TabStop = false;
            this.pbClientManage.Click += new System.EventHandler(this.btnManageClient_Click);
            this.pbClientManage.MouseEnter += new System.EventHandler(this.btnManageClient_MouseEnter);
            this.pbClientManage.MouseLeave += new System.EventHandler(this.btnManageClient_MouseLeave);
            // 
            // btnClientManage
            // 
            this.btnClientManage.BackColor = System.Drawing.Color.Transparent;
            this.btnClientManage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClientManage.FlatAppearance.BorderSize = 0;
            this.btnClientManage.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.btnClientManage.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(139)))), ((int)(((byte)(250)))));
            this.btnClientManage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClientManage.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClientManage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.btnClientManage.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClientManage.Location = new System.Drawing.Point(-2, 0);
            this.btnClientManage.Margin = new System.Windows.Forms.Padding(2);
            this.btnClientManage.Name = "btnClientManage";
            this.btnClientManage.Size = new System.Drawing.Size(160, 50);
            this.btnClientManage.TabIndex = 3;
            this.btnClientManage.Text = "Gestión de\r\nClientes\r\n\r\n";
            this.btnClientManage.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnClientManage.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnClientManage.UseVisualStyleBackColor = false;
            this.btnClientManage.Click += new System.EventHandler(this.btnManageClient_Click);
            this.btnClientManage.MouseEnter += new System.EventHandler(this.btnManageClient_MouseEnter);
            this.btnClientManage.MouseLeave += new System.EventHandler(this.btnManageClient_MouseLeave);
            // 
            // pnlClientManageDecorativeLine
            // 
            this.pnlClientManageDecorativeLine.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.pnlClientManageDecorativeLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(234)))), ((int)(((byte)(199)))));
            this.pnlClientManageDecorativeLine.Location = new System.Drawing.Point(0, 231);
            this.pnlClientManageDecorativeLine.Margin = new System.Windows.Forms.Padding(2);
            this.pnlClientManageDecorativeLine.Name = "pnlClientManageDecorativeLine";
            this.pnlClientManageDecorativeLine.Size = new System.Drawing.Size(4, 50);
            this.pnlClientManageDecorativeLine.TabIndex = 32;
            // 
            // pnlNewSale
            // 
            this.pnlNewSale.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.pnlNewSale.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.pnlNewSale.Controls.Add(this.pbNewSale);
            this.pnlNewSale.Controls.Add(this.btnNewSale);
            this.pnlNewSale.Location = new System.Drawing.Point(0, 287);
            this.pnlNewSale.Name = "pnlNewSale";
            this.pnlNewSale.Size = new System.Drawing.Size(160, 50);
            this.pnlNewSale.TabIndex = 35;
            // 
            // pbNewSale
            // 
            this.pbNewSale.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbNewSale.Image = ((System.Drawing.Image)(resources.GetObject("pbNewSale.Image")));
            this.pbNewSale.Location = new System.Drawing.Point(12, 7);
            this.pbNewSale.Name = "pbNewSale";
            this.pbNewSale.Size = new System.Drawing.Size(35, 35);
            this.pbNewSale.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbNewSale.TabIndex = 0;
            this.pbNewSale.TabStop = false;
            this.pbNewSale.Click += new System.EventHandler(this.btnNewSale_Click);
            this.pbNewSale.MouseEnter += new System.EventHandler(this.btnNewSale_MouseEnter);
            this.pbNewSale.MouseLeave += new System.EventHandler(this.btnNewSale_MouseLeave);
            // 
            // btnNewSale
            // 
            this.btnNewSale.BackColor = System.Drawing.Color.Transparent;
            this.btnNewSale.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNewSale.FlatAppearance.BorderSize = 0;
            this.btnNewSale.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.btnNewSale.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(139)))), ((int)(((byte)(250)))));
            this.btnNewSale.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNewSale.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.btnNewSale.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.btnNewSale.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNewSale.Location = new System.Drawing.Point(-2, 0);
            this.btnNewSale.Margin = new System.Windows.Forms.Padding(2);
            this.btnNewSale.Name = "btnNewSale";
            this.btnNewSale.Size = new System.Drawing.Size(160, 50);
            this.btnNewSale.TabIndex = 4;
            this.btnNewSale.Text = "Nueva Venta";
            this.btnNewSale.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNewSale.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnNewSale.UseVisualStyleBackColor = false;
            this.btnNewSale.Click += new System.EventHandler(this.btnNewSale_Click);
            this.btnNewSale.MouseEnter += new System.EventHandler(this.btnNewSale_MouseEnter);
            this.btnNewSale.MouseLeave += new System.EventHandler(this.btnNewSale_MouseLeave);
            // 
            // pnlNewSaleDecorativeLine
            // 
            this.pnlNewSaleDecorativeLine.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.pnlNewSaleDecorativeLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(234)))), ((int)(((byte)(199)))));
            this.pnlNewSaleDecorativeLine.Location = new System.Drawing.Point(0, 287);
            this.pnlNewSaleDecorativeLine.Margin = new System.Windows.Forms.Padding(2);
            this.pnlNewSaleDecorativeLine.Name = "pnlNewSaleDecorativeLine";
            this.pnlNewSaleDecorativeLine.Size = new System.Drawing.Size(4, 50);
            this.pnlNewSaleDecorativeLine.TabIndex = 34;
            // 
            // pnlMainWindow
            // 
            this.pnlMainWindow.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.pnlMainWindow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.pnlMainWindow.Controls.Add(this.pbMainMenu);
            this.pnlMainWindow.Controls.Add(this.btnMainMenu);
            this.pnlMainWindow.Location = new System.Drawing.Point(0, 119);
            this.pnlMainWindow.Name = "pnlMainWindow";
            this.pnlMainWindow.Size = new System.Drawing.Size(160, 50);
            this.pnlMainWindow.TabIndex = 37;
            // 
            // pbMainMenu
            // 
            this.pbMainMenu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbMainMenu.Image = ((System.Drawing.Image)(resources.GetObject("pbMainMenu.Image")));
            this.pbMainMenu.Location = new System.Drawing.Point(12, 6);
            this.pbMainMenu.Name = "pbMainMenu";
            this.pbMainMenu.Size = new System.Drawing.Size(35, 35);
            this.pbMainMenu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbMainMenu.TabIndex = 0;
            this.pbMainMenu.TabStop = false;
            this.pbMainMenu.Click += new System.EventHandler(this.btnMainMenu_Click);
            this.pbMainMenu.MouseEnter += new System.EventHandler(this.btnMainMenu_MouseEnter);
            this.pbMainMenu.MouseLeave += new System.EventHandler(this.btnMainMenu_MouseLeave);
            // 
            // btnMainMenu
            // 
            this.btnMainMenu.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnMainMenu.BackColor = System.Drawing.Color.Transparent;
            this.btnMainMenu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMainMenu.FlatAppearance.BorderSize = 0;
            this.btnMainMenu.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.btnMainMenu.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(139)))), ((int)(((byte)(250)))));
            this.btnMainMenu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMainMenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.btnMainMenu.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.btnMainMenu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMainMenu.Location = new System.Drawing.Point(2, 0);
            this.btnMainMenu.Margin = new System.Windows.Forms.Padding(2);
            this.btnMainMenu.Name = "btnMainMenu";
            this.btnMainMenu.Size = new System.Drawing.Size(158, 50);
            this.btnMainMenu.TabIndex = 1;
            this.btnMainMenu.Text = "Menú \r\nPrincipal";
            this.btnMainMenu.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnMainMenu.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnMainMenu.UseVisualStyleBackColor = false;
            this.btnMainMenu.Click += new System.EventHandler(this.btnMainMenu_Click);
            this.btnMainMenu.MouseEnter += new System.EventHandler(this.btnMainMenu_MouseEnter);
            this.btnMainMenu.MouseLeave += new System.EventHandler(this.btnMainMenu_MouseLeave);
            // 
            // pnlMainMenuDecorativeLine
            // 
            this.pnlMainMenuDecorativeLine.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.pnlMainMenuDecorativeLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(234)))), ((int)(((byte)(199)))));
            this.pnlMainMenuDecorativeLine.Location = new System.Drawing.Point(0, 119);
            this.pnlMainMenuDecorativeLine.Margin = new System.Windows.Forms.Padding(2);
            this.pnlMainMenuDecorativeLine.Name = "pnlMainMenuDecorativeLine";
            this.pnlMainMenuDecorativeLine.Size = new System.Drawing.Size(4, 50);
            this.pnlMainMenuDecorativeLine.TabIndex = 36;
            // 
            // pnlLogOut
            // 
            this.pnlLogOut.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pnlLogOut.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.pnlLogOut.Controls.Add(this.pbLogOut);
            this.pnlLogOut.Controls.Add(this.btnLogOut);
            this.pnlLogOut.Location = new System.Drawing.Point(0, 510);
            this.pnlLogOut.Name = "pnlLogOut";
            this.pnlLogOut.Size = new System.Drawing.Size(160, 30);
            this.pnlLogOut.TabIndex = 39;
            this.pnlLogOut.MouseEnter += new System.EventHandler(this.pnlLogOut_MouseEnter);
            this.pnlLogOut.MouseLeave += new System.EventHandler(this.pnlLogOut_MouseLeave);
            // 
            // pbLogOut
            // 
            this.pbLogOut.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbLogOut.Image = ((System.Drawing.Image)(resources.GetObject("pbLogOut.Image")));
            this.pbLogOut.Location = new System.Drawing.Point(12, 0);
            this.pbLogOut.Name = "pbLogOut";
            this.pbLogOut.Size = new System.Drawing.Size(30, 30);
            this.pbLogOut.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbLogOut.TabIndex = 0;
            this.pbLogOut.TabStop = false;
            this.pbLogOut.MouseEnter += new System.EventHandler(this.pnlLogOut_MouseEnter);
            this.pbLogOut.MouseLeave += new System.EventHandler(this.pnlLogOut_MouseLeave);
            // 
            // btnLogOut
            // 
            this.btnLogOut.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.btnLogOut.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLogOut.FlatAppearance.BorderSize = 0;
            this.btnLogOut.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.btnLogOut.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(139)))), ((int)(((byte)(250)))));
            this.btnLogOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnLogOut.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.btnLogOut.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLogOut.Location = new System.Drawing.Point(-2, 0);
            this.btnLogOut.Margin = new System.Windows.Forms.Padding(2);
            this.btnLogOut.Name = "btnLogOut";
            this.btnLogOut.Size = new System.Drawing.Size(160, 30);
            this.btnLogOut.TabIndex = 5;
            this.btnLogOut.Text = "Cerrar Sesión";
            this.btnLogOut.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLogOut.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnLogOut.UseVisualStyleBackColor = false;
            this.btnLogOut.Click += new System.EventHandler(this.btnLogOut_Click);
            this.btnLogOut.MouseEnter += new System.EventHandler(this.pnlLogOut_MouseEnter);
            this.btnLogOut.MouseLeave += new System.EventHandler(this.pnlLogOut_MouseLeave);
            // 
            // pnlLogOutDecorativeLine
            // 
            this.pnlLogOutDecorativeLine.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pnlLogOutDecorativeLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(234)))), ((int)(((byte)(199)))));
            this.pnlLogOutDecorativeLine.Location = new System.Drawing.Point(0, 510);
            this.pnlLogOutDecorativeLine.Margin = new System.Windows.Forms.Padding(2);
            this.pnlLogOutDecorativeLine.Name = "pnlLogOutDecorativeLine";
            this.pnlLogOutDecorativeLine.Size = new System.Drawing.Size(4, 30);
            this.pnlLogOutDecorativeLine.TabIndex = 38;
            // 
            // panelMenu
            // 
            this.panelMenu.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panelMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.panelMenu.Controls.Add(this.pbMenu);
            this.panelMenu.Controls.Add(this.pbMenu2);
            this.panelMenu.Controls.Add(this.pbLogo);
            this.panelMenu.Controls.Add(this.pnlLogOutDecorativeLine);
            this.panelMenu.Controls.Add(this.pnlLogOut);
            this.panelMenu.Controls.Add(this.pnlMainMenuDecorativeLine);
            this.panelMenu.Controls.Add(this.pnlMainWindow);
            this.panelMenu.Controls.Add(this.pnlNewSaleDecorativeLine);
            this.panelMenu.Controls.Add(this.pnlNewSale);
            this.panelMenu.Controls.Add(this.pnlClientManageDecorativeLine);
            this.panelMenu.Controls.Add(this.pnlClientManage);
            this.panelMenu.Controls.Add(this.pnlProductManageDecorativeLine);
            this.panelMenu.Controls.Add(this.pnlProductManage);
            this.panelMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelMenu.Location = new System.Drawing.Point(0, 30);
            this.panelMenu.Margin = new System.Windows.Forms.Padding(2);
            this.panelMenu.Name = "panelMenu";
            this.panelMenu.Size = new System.Drawing.Size(160, 560);
            this.panelMenu.TabIndex = 21;
            // 
            // pbMenu
            // 
            this.pbMenu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbMenu.Image = ((System.Drawing.Image)(resources.GetObject("pbMenu.Image")));
            this.pbMenu.Location = new System.Drawing.Point(120, 2);
            this.pbMenu.Margin = new System.Windows.Forms.Padding(2);
            this.pbMenu.Name = "pbMenu";
            this.pbMenu.Size = new System.Drawing.Size(40, 35);
            this.pbMenu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbMenu.TabIndex = 19;
            this.pbMenu.TabStop = false;
            this.pbMenu.Click += new System.EventHandler(this.pbMenu_Click);
            this.pbMenu.MouseEnter += new System.EventHandler(this.pbMenu_MouseEnter);
            this.pbMenu.MouseLeave += new System.EventHandler(this.pbMenu_MouseLeave);
            // 
            // pbMenu2
            // 
            this.pbMenu2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pbMenu2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbMenu2.Image = ((System.Drawing.Image)(resources.GetObject("pbMenu2.Image")));
            this.pbMenu2.Location = new System.Drawing.Point(120, 0);
            this.pbMenu2.Margin = new System.Windows.Forms.Padding(2);
            this.pbMenu2.Name = "pbMenu2";
            this.pbMenu2.Size = new System.Drawing.Size(40, 35);
            this.pbMenu2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbMenu2.TabIndex = 20;
            this.pbMenu2.TabStop = false;
            this.pbMenu2.Click += new System.EventHandler(this.pbMenu2_Click);
            // 
            // pbLogo
            // 
            this.pbLogo.Image = ((System.Drawing.Image)(resources.GetObject("pbLogo.Image")));
            this.pbLogo.Location = new System.Drawing.Point(12, 0);
            this.pbLogo.Name = "pbLogo";
            this.pbLogo.Size = new System.Drawing.Size(109, 37);
            this.pbLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbLogo.TabIndex = 22;
            this.pbLogo.TabStop = false;
            this.pbLogo.Click += new System.EventHandler(this.pbMenu2_Click);
            this.pbLogo.MouseEnter += new System.EventHandler(this.pbLogo_MouseEnter);
            this.pbLogo.MouseLeave += new System.EventHandler(this.pbLogo_MouseLeave);
            // 
            // pnlBackground
            // 
            this.pnlBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(234)))), ((int)(((byte)(199)))));
            this.pnlBackground.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlBackground.Location = new System.Drawing.Point(160, 30);
            this.pnlBackground.Name = "pnlBackground";
            this.pnlBackground.Size = new System.Drawing.Size(1030, 560);
            this.pnlBackground.TabIndex = 22;
            // 
            // MainWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1200, 600);
            this.ControlBox = false;
            this.Controls.Add(this.pnlBackground);
            this.Controls.Add(this.panelMenu);
            this.Controls.Add(this.pnlTopBorder);
            this.Controls.Add(this.pnlRightBorder);
            this.Controls.Add(this.pnlBottomBorder);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(840, 480);
            this.Name = "MainWindow";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.MainWindow_Load);
            this.pnlTopBorder.ResumeLayout(false);
            this.pnlProductManage.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbProductManage)).EndInit();
            this.pnlClientManage.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbClientManage)).EndInit();
            this.pnlNewSale.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbNewSale)).EndInit();
            this.pnlMainWindow.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbMainMenu)).EndInit();
            this.pnlLogOut.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbLogOut)).EndInit();
            this.panelMenu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbMenu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMenu2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLogo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Timer tmHideMenu;
        private System.Windows.Forms.Timer tmShowMenu;
        private System.Windows.Forms.Panel pnlBottomBorder;
        private System.Windows.Forms.Panel pnlRightBorder;
        private System.Windows.Forms.Button btnRestore;
        private System.Windows.Forms.Button btnMaximize;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnMinimize;
        private System.Windows.Forms.Panel pnlTopBorder;
        private System.Windows.Forms.Panel pnlProductManage;
        private System.Windows.Forms.PictureBox pbProductManage;
        private System.Windows.Forms.Button btnProductManage;
        private System.Windows.Forms.Panel pnlProductManageDecorativeLine;
        private System.Windows.Forms.Panel pnlClientManage;
        private System.Windows.Forms.PictureBox pbClientManage;
        private System.Windows.Forms.Button btnClientManage;
        private System.Windows.Forms.Panel pnlClientManageDecorativeLine;
        private System.Windows.Forms.Panel pnlNewSale;
        private System.Windows.Forms.PictureBox pbNewSale;
        private System.Windows.Forms.Button btnNewSale;
        private System.Windows.Forms.Panel pnlNewSaleDecorativeLine;
        private System.Windows.Forms.Panel pnlMainWindow;
        private System.Windows.Forms.PictureBox pbMainMenu;
        private System.Windows.Forms.Button btnMainMenu;
        private System.Windows.Forms.Panel pnlMainMenuDecorativeLine;
        private System.Windows.Forms.Panel pnlLogOut;
        private System.Windows.Forms.PictureBox pbLogOut;
        private System.Windows.Forms.Button btnLogOut;
        private System.Windows.Forms.Panel pnlLogOutDecorativeLine;
        private System.Windows.Forms.PictureBox pbLogo;
        private System.Windows.Forms.PictureBox pbMenu2;
        private System.Windows.Forms.PictureBox pbMenu;
        private System.Windows.Forms.Panel panelMenu;
        private System.Windows.Forms.Panel pnlBackground;
    }
}

