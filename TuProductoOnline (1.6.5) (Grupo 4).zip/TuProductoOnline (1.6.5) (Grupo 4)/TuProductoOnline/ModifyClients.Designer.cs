﻿namespace TuProductoOnline
{
    partial class ModifyClients
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ModifyClients));
            this.txtModifyIDClient = new System.Windows.Forms.TextBox();
            this.lblCédula = new System.Windows.Forms.Label();
            this.txtModifyPhoneClient = new System.Windows.Forms.TextBox();
            this.lblDirección = new System.Windows.Forms.Label();
            this.txtModifyAdressClient = new System.Windows.Forms.TextBox();
            this.lblPhone = new System.Windows.Forms.Label();
            this.txtModifySurnameClient = new System.Windows.Forms.TextBox();
            this.lblApellido = new System.Windows.Forms.Label();
            this.txtModifyNameClient = new System.Windows.Forms.TextBox();
            this.lblNombre = new System.Windows.Forms.Label();
            this.btnModifyClients = new System.Windows.Forms.Button();
            this.pnlTopBorder = new System.Windows.Forms.Panel();
            this.errorProviderModifyClients1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProviderModifyClients3 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProviderModifyClients2 = new System.Windows.Forms.ErrorProvider(this.components);
            this.btnCancel = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderModifyClients1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderModifyClients3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderModifyClients2)).BeginInit();
            this.SuspendLayout();
            // 
            // txtModifyIDClient
            // 
            this.txtModifyIDClient.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtModifyIDClient.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtModifyIDClient.ForeColor = System.Drawing.Color.White;
            this.txtModifyIDClient.Location = new System.Drawing.Point(44, 168);
            this.txtModifyIDClient.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtModifyIDClient.Name = "txtModifyIDClient";
            this.txtModifyIDClient.Size = new System.Drawing.Size(153, 20);
            this.txtModifyIDClient.TabIndex = 5;
            this.txtModifyIDClient.TextChanged += new System.EventHandler(this.txtModifyIDClient_TextChanged);
            // 
            // lblCédula
            // 
            this.lblCédula.AutoSize = true;
            this.lblCédula.Location = new System.Drawing.Point(96, 145);
            this.lblCédula.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCédula.Name = "lblCédula";
            this.lblCédula.Size = new System.Drawing.Size(46, 13);
            this.lblCédula.TabIndex = 50;
            this.lblCédula.Text = "Cédula";
            // 
            // txtModifyPhoneClient
            // 
            this.txtModifyPhoneClient.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtModifyPhoneClient.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtModifyPhoneClient.ForeColor = System.Drawing.Color.White;
            this.txtModifyPhoneClient.Location = new System.Drawing.Point(238, 46);
            this.txtModifyPhoneClient.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtModifyPhoneClient.MaxLength = 11;
            this.txtModifyPhoneClient.Name = "txtModifyPhoneClient";
            this.txtModifyPhoneClient.Size = new System.Drawing.Size(153, 20);
            this.txtModifyPhoneClient.TabIndex = 2;
            this.txtModifyPhoneClient.Validating += new System.ComponentModel.CancelEventHandler(this.txtModifyPhoneClient_Validating);
            // 
            // lblDirección
            // 
            this.lblDirección.AutoSize = true;
            this.lblDirección.Location = new System.Drawing.Point(282, 84);
            this.lblDirección.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDirección.Name = "lblDirección";
            this.lblDirección.Size = new System.Drawing.Size(61, 13);
            this.lblDirección.TabIndex = 48;
            this.lblDirección.Text = "Dirección";
            // 
            // txtModifyAdressClient
            // 
            this.txtModifyAdressClient.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtModifyAdressClient.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtModifyAdressClient.ForeColor = System.Drawing.Color.White;
            this.txtModifyAdressClient.Location = new System.Drawing.Point(238, 107);
            this.txtModifyAdressClient.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtModifyAdressClient.Name = "txtModifyAdressClient";
            this.txtModifyAdressClient.Size = new System.Drawing.Size(153, 20);
            this.txtModifyAdressClient.TabIndex = 4;
            this.txtModifyAdressClient.Validating += new System.ComponentModel.CancelEventHandler(this.txtModifyAdressClient_Validating);
            // 
            // lblPhone
            // 
            this.lblPhone.AutoSize = true;
            this.lblPhone.Location = new System.Drawing.Point(281, 28);
            this.lblPhone.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Size = new System.Drawing.Size(57, 13);
            this.lblPhone.TabIndex = 46;
            this.lblPhone.Text = "Teléfono";
            // 
            // txtModifySurnameClient
            // 
            this.txtModifySurnameClient.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtModifySurnameClient.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtModifySurnameClient.ForeColor = System.Drawing.Color.White;
            this.txtModifySurnameClient.Location = new System.Drawing.Point(44, 107);
            this.txtModifySurnameClient.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtModifySurnameClient.Name = "txtModifySurnameClient";
            this.txtModifySurnameClient.Size = new System.Drawing.Size(153, 20);
            this.txtModifySurnameClient.TabIndex = 3;
            this.txtModifySurnameClient.Validating += new System.ComponentModel.CancelEventHandler(this.txtModifySurnameClient_Validating);
            // 
            // lblApellido
            // 
            this.lblApellido.AutoSize = true;
            this.lblApellido.Location = new System.Drawing.Point(96, 84);
            this.lblApellido.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblApellido.Name = "lblApellido";
            this.lblApellido.Size = new System.Drawing.Size(52, 13);
            this.lblApellido.TabIndex = 44;
            this.lblApellido.Text = "Apellido";
            // 
            // txtModifyNameClient
            // 
            this.txtModifyNameClient.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtModifyNameClient.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtModifyNameClient.ForeColor = System.Drawing.Color.White;
            this.txtModifyNameClient.Location = new System.Drawing.Point(44, 46);
            this.txtModifyNameClient.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtModifyNameClient.Name = "txtModifyNameClient";
            this.txtModifyNameClient.Size = new System.Drawing.Size(153, 20);
            this.txtModifyNameClient.TabIndex = 1;
            this.txtModifyNameClient.Validating += new System.ComponentModel.CancelEventHandler(this.txtModifyNameClient_Validating);
            // 
            // lblNombre
            // 
            this.lblNombre.AutoSize = true;
            this.lblNombre.Location = new System.Drawing.Point(98, 26);
            this.lblNombre.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(50, 13);
            this.lblNombre.TabIndex = 42;
            this.lblNombre.Text = "Nombre";
            // 
            // btnModifyClients
            // 
            this.btnModifyClients.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.btnModifyClients.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnModifyClients.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.btnModifyClients.Location = new System.Drawing.Point(296, 204);
            this.btnModifyClients.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnModifyClients.Name = "btnModifyClients";
            this.btnModifyClients.Size = new System.Drawing.Size(95, 29);
            this.btnModifyClients.TabIndex = 6;
            this.btnModifyClients.Text = "Modificar";
            this.btnModifyClients.UseVisualStyleBackColor = false;
            this.btnModifyClients.Click += new System.EventHandler(this.btnModifyClients_Click);
            // 
            // pnlTopBorder
            // 
            this.pnlTopBorder.BackColor = System.Drawing.Color.Transparent;
            this.pnlTopBorder.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTopBorder.Location = new System.Drawing.Point(0, 0);
            this.pnlTopBorder.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pnlTopBorder.Name = "pnlTopBorder";
            this.pnlTopBorder.Size = new System.Drawing.Size(435, 23);
            this.pnlTopBorder.TabIndex = 55;
            this.pnlTopBorder.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlTopBorder_MouseDown);
            this.pnlTopBorder.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pnlTopBorder_MouseMove);
            this.pnlTopBorder.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pnlTopBorder_MouseUp);
            // 
            // errorProviderModifyClients1
            // 
            this.errorProviderModifyClients1.ContainerControl = this;
            // 
            // errorProviderModifyClients3
            // 
            this.errorProviderModifyClients3.ContainerControl = this;
            // 
            // errorProviderModifyClients2
            // 
            this.errorProviderModifyClients2.ContainerControl = this;
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.btnCancel.Location = new System.Drawing.Point(44, 204);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(95, 29);
            this.btnCancel.TabIndex = 7;
            this.btnCancel.Text = "Cancelar";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // ModifyClients
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(234)))), ((int)(((byte)(199)))));
            this.ClientSize = new System.Drawing.Size(435, 261);
            this.ControlBox = false;
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.pnlTopBorder);
            this.Controls.Add(this.btnModifyClients);
            this.Controls.Add(this.txtModifyIDClient);
            this.Controls.Add(this.lblCédula);
            this.Controls.Add(this.txtModifyPhoneClient);
            this.Controls.Add(this.lblDirección);
            this.Controls.Add(this.txtModifyAdressClient);
            this.Controls.Add(this.lblPhone);
            this.Controls.Add(this.txtModifySurnameClient);
            this.Controls.Add(this.lblApellido);
            this.Controls.Add(this.txtModifyNameClient);
            this.Controls.Add(this.lblNombre);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "ModifyClients";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderModifyClients1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderModifyClients3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderModifyClients2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtModifyIDClient;
        private System.Windows.Forms.Label lblCédula;
        private System.Windows.Forms.TextBox txtModifyPhoneClient;
        private System.Windows.Forms.Label lblDirección;
        private System.Windows.Forms.TextBox txtModifyAdressClient;
        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.TextBox txtModifySurnameClient;
        private System.Windows.Forms.Label lblApellido;
        private System.Windows.Forms.TextBox txtModifyNameClient;
        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.Button btnModifyClients;
        private System.Windows.Forms.Panel pnlTopBorder;
        private System.Windows.Forms.ErrorProvider errorProviderModifyClients1;
        private System.Windows.Forms.ErrorProvider errorProviderModifyClients3;
        private System.Windows.Forms.ErrorProvider errorProviderModifyClients2;
        private System.Windows.Forms.Button btnCancel;
    }
}