﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TuProductoOnline
{
    public partial class ModifyClients : Form
    {
        Client client = new Client();
        public ModifyClients(Client clienttomodify)
        {
            client = clienttomodify;
            InitializeComponent();
            ClientLoad();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            ClientManageMenu.ActiveForm.Show();

        }
        private static string _pathclient = Path.GetFullPath(Path.Combine(Application.StartupPath, "..\\..", "Clients.json"));
        private static string GetClientsFromFile()
        {
            string clientsJsonFromFile;
            using (var reader = new StreamReader(_pathclient))
            {
                clientsJsonFromFile = reader.ReadToEnd();
            }
            return clientsJsonFromFile;
        }

        public void ClientLoad(string searchText = "")
        {
            txtModifyNameClient.Text = client.Name;
            txtModifySurnameClient.Text = client.LastName;
            txtModifyPhoneClient.Text = client.Phone.ToString();
            txtModifyIDClient.Text = client.Id.ToString();
            txtModifyAdressClient.Text =client.Address;
        }

        private void btnModifyClients_Click(object sender, EventArgs e)
        {
            {
                DelteErrorProviderClient2();
                if (CheckerAdd2())
                {

                    var clientsFromFile = GetClientsFromFile();
                    var clients = JsonConvert.DeserializeObject<List<Client>>(clientsFromFile);
                    DialogResult result1 = MessageBox.Show("¿Esta seguro que desea modificar este cliente?", "Confirmación", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (result1 == DialogResult.Yes)
                    {

                        long tomodify1 = client.Id;
                        foreach (Client client in clients)
                        {
                            if (tomodify1 == client.Id)
                            {
                                client.Name = txtModifyNameClient.Text;
                                client.LastName = txtModifySurnameClient.Text;
                                client.Id = long.Parse(txtModifyIDClient.Text);
                                client.Phone = long.Parse(txtModifyPhoneClient.Text);
                                client.Address = txtModifyAdressClient.Text;
                            }
                        }

                        string clientsJson = JsonConvert.SerializeObject(clients.ToArray(), Formatting.Indented);//Serializa el objeto en forma de users(Una lista) y lo guarda en la variable
                        File.WriteAllText(_pathclient, clientsJson);//Escribe en el json los datos de la variable anterio
                        ClientManageMenu cli = new ClientManageMenu();
                        foreach (Form form in Application.OpenForms)
                        {
                            if (form is ClientManageMenu)
                            {
                                cli = (ClientManageMenu)form;
                                break;
                            }
                        }
                        cli.ClientLoad();
                        this.Close();
                    }
                }
            }
        }

        public bool CheckerAdd2()
        {
            bool validar = true;
            if (txtModifyNameClient.Text == string.Empty)
            {
                validar = false;
               errorProviderModifyClients1.SetError(txtModifyNameClient, "Ingresar un nombre");
            }
            if (txtModifyPhoneClient.Text == string.Empty)
            {
                validar = false;
                errorProviderModifyClients1.SetError(txtModifyPhoneClient, "Ingresar un telefono");
            }
            if (txtModifyIDClient.Text == string.Empty)
            {
                validar = false;
                errorProviderModifyClients1.SetError(txtModifyIDClient, "Ingresar un ID");
            }
            if (txtModifySurnameClient.Text == string.Empty)
            {
                validar = false;
               errorProviderModifyClients1.SetError(txtModifySurnameClient, "Ingresar un apellido");
            }
            if (txtModifyAdressClient.Text == string.Empty)
            {
                validar = false;
                errorProviderModifyClients1.SetError(txtModifyAdressClient, "Ingresar una direccion");
            }
            return validar;
        }

        public void DelteErrorProviderClient2()
        {
            errorProviderModifyClients1.SetError(txtModifyNameClient, "");
            errorProviderModifyClients1.SetError(txtModifySurnameClient, "");
            errorProviderModifyClients1.SetError(txtModifyPhoneClient, "");
            errorProviderModifyClients1.SetError(txtModifyIDClient, "");
            errorProviderModifyClients1.SetError(txtModifyAdressClient, "");
        }

        private void txtModifyNameClient_Validating(object sender, CancelEventArgs e)
        {
            bool istrue2 = true;
            foreach (char c in txtModifyNameClient.Text)
            {
                if (!Char.IsLetter(c) && !Char.IsWhiteSpace(c))
                {
                    istrue2 = false;
                    break;
                }
            }

            if (!istrue2)
            {
               errorProviderModifyClients2.SetError(txtModifyNameClient, "Ingrese Solo Letras");
                btnModifyClients.Enabled = false;
                return;
            }
            errorProviderModifyClients2.SetError(txtModifyNameClient, "");
            btnModifyClients.Enabled = true;
        }

        private void txtModifySurnameClient_Validating(object sender, CancelEventArgs e)
        {
            bool istrue1 = true;
            foreach (char c in txtModifySurnameClient.Text)
            {
                if (!Char.IsLetter(c) && !Char.IsWhiteSpace(c))
                {
                    istrue1 = false;
                    break;
                }
            }

            if (!istrue1)
            {
                errorProviderModifyClients2.SetError(txtModifySurnameClient, "Ingrese Solo Letras");
                btnModifyClients.Enabled = false;
                return;
            }
            errorProviderModifyClients2.SetError(txtModifySurnameClient, "");
            btnModifyClients.Enabled = true;
        }

        private void txtModifyPhoneClient_Validating(object sender, CancelEventArgs e)
        {
            long validationphoneclient1;
            if (!long.TryParse(txtModifyPhoneClient.Text, out validationphoneclient1))
            {
                errorProviderModifyClients1.SetError(txtModifyPhoneClient, "Ingrese Solo Numeros");
                btnModifyClients.Enabled = false;
            }
            else
            {
                errorProviderModifyClients1.SetError(txtModifyPhoneClient, "");
                btnModifyClients.Enabled = true;
            }
        }

        private void txtModifyIDClient_TextChanged(object sender, EventArgs e)
        {

            long validationphoneclient2;
            if (!long.TryParse(txtModifyIDClient.Text, out validationphoneclient2))
            {
                errorProviderModifyClients1.SetError(txtModifyIDClient, "Ingrese Solo Numeros");
                btnModifyClients.Enabled = false;
            }
            else
            {
                errorProviderModifyClients1.SetError(txtModifyIDClient, "");
                btnModifyClients.Enabled = true;
            }
        }

        private void txtModifyAdressClient_Validating(object sender, CancelEventArgs e)
        {
            bool istrue = true;
            foreach (char c in txtModifyAdressClient.Text)
            {
                if (!Char.IsLetter(c) && !Char.IsDigit(c) && !Char.IsWhiteSpace(c) && !Char.IsPunctuation(c))
                {
                    istrue = false;
                    break;
                }
            }

            if (!istrue)
            {
                errorProviderModifyClients3.SetError(txtModifyAdressClient, "Ingrese Solo Letras, Números y Signos");
                btnModifyClients.Enabled = false;
                return;
            }

            // Si la validación es correcta, limpiar el error provider y habilitar el botón
            errorProviderModifyClients3.SetError(txtModifyAdressClient, "");
            btnModifyClients.Enabled = true;

        }
        int m, mx, my;
        private void pnlTopBorder_MouseDown(object sender, MouseEventArgs e)
        {
            m = 1;
            mx = e.X;
            my = e.Y;
        }

       
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pnlTopBorder_MouseMove(object sender, MouseEventArgs e)
        {
            if (m == 1)
            {
                this.SetDesktopLocation(MousePosition.X - mx, MousePosition.Y - my);
            }
        }

        private void pnlTopBorder_MouseUp(object sender, MouseEventArgs e)
        {
            m = 0;
        }

    }
}
    


































    
