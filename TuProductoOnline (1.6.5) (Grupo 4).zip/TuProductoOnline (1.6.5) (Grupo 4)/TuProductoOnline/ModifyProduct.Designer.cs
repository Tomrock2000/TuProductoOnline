﻿namespace TuProductoOnline
{
    partial class ModifyProduct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ModifyProduct));
            this.lblCantity = new System.Windows.Forms.Label();
            this.txtCantityProduct = new System.Windows.Forms.TextBox();
            this.txtDescriptionProduct = new System.Windows.Forms.RichTextBox();
            this.lblModelProduct = new System.Windows.Forms.Label();
            this.txtModelProduct = new System.Windows.Forms.TextBox();
            this.lblVersionProduct = new System.Windows.Forms.Label();
            this.txtVersionProduct = new System.Windows.Forms.TextBox();
            this.lblLicenceProduct = new System.Windows.Forms.Label();
            this.txtLicenceProduct = new System.Windows.Forms.TextBox();
            this.lblMeassuresProduct = new System.Windows.Forms.Label();
            this.txtMeassuresProduct = new System.Windows.Forms.TextBox();
            this.lblPriceProduct = new System.Windows.Forms.Label();
            this.txtPriceProduct = new System.Windows.Forms.TextBox();
            this.lblNameProduct = new System.Windows.Forms.Label();
            this.txtNameProduct = new System.Windows.Forms.TextBox();
            this.lblDescriptionProduct = new System.Windows.Forms.Label();
            this.lblIdProduct = new System.Windows.Forms.Label();
            this.txtIdProduct = new System.Windows.Forms.TextBox();
            this.btnModifyProduct = new System.Windows.Forms.Button();
            this.txtTypeProduct = new System.Windows.Forms.TextBox();
            this.btnCancel = new System.Windows.Forms.Button();
            this.cbEnabled = new System.Windows.Forms.ComboBox();
            this.lblType = new System.Windows.Forms.Label();
            this.pnlTopBorder = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // lblCantity
            // 
            this.lblCantity.AutoSize = true;
            this.lblCantity.Location = new System.Drawing.Point(54, 165);
            this.lblCantity.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCantity.Name = "lblCantity";
            this.lblCantity.Size = new System.Drawing.Size(57, 13);
            this.lblCantity.TabIndex = 39;
            this.lblCantity.Text = "Cantidad";
            // 
            // txtCantityProduct
            // 
            this.txtCantityProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtCantityProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCantityProduct.ForeColor = System.Drawing.Color.White;
            this.txtCantityProduct.Location = new System.Drawing.Point(28, 193);
            this.txtCantityProduct.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtCantityProduct.MaxLength = 3;
            this.txtCantityProduct.Name = "txtCantityProduct";
            this.txtCantityProduct.Size = new System.Drawing.Size(109, 20);
            this.txtCantityProduct.TabIndex = 6;
            this.txtCantityProduct.TextChanged += new System.EventHandler(this.txtNameProduct_TextChanged);
            this.txtCantityProduct.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCantity_KeyPress);
            // 
            // txtDescriptionProduct
            // 
            this.txtDescriptionProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtDescriptionProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDescriptionProduct.ForeColor = System.Drawing.Color.White;
            this.txtDescriptionProduct.Location = new System.Drawing.Point(28, 253);
            this.txtDescriptionProduct.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtDescriptionProduct.MaxLength = 200;
            this.txtDescriptionProduct.Name = "txtDescriptionProduct";
            this.txtDescriptionProduct.Size = new System.Drawing.Size(378, 92);
            this.txtDescriptionProduct.TabIndex = 8;
            this.txtDescriptionProduct.Text = "";
            this.txtDescriptionProduct.TextChanged += new System.EventHandler(this.txtNameProduct_TextChanged);
            // 
            // lblModelProduct
            // 
            this.lblModelProduct.AutoSize = true;
            this.lblModelProduct.Location = new System.Drawing.Point(190, 165);
            this.lblModelProduct.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblModelProduct.Name = "lblModelProduct";
            this.lblModelProduct.Size = new System.Drawing.Size(41, 13);
            this.lblModelProduct.TabIndex = 36;
            this.lblModelProduct.Text = "Model";
            this.lblModelProduct.Visible = false;
            // 
            // txtModelProduct
            // 
            this.txtModelProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtModelProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtModelProduct.ForeColor = System.Drawing.Color.White;
            this.txtModelProduct.Location = new System.Drawing.Point(162, 193);
            this.txtModelProduct.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtModelProduct.MaxLength = 20;
            this.txtModelProduct.Name = "txtModelProduct";
            this.txtModelProduct.Size = new System.Drawing.Size(109, 20);
            this.txtModelProduct.TabIndex = 2;
            this.txtModelProduct.Visible = false;
            this.txtModelProduct.TextChanged += new System.EventHandler(this.txtNameProduct_TextChanged);
            // 
            // lblVersionProduct
            // 
            this.lblVersionProduct.AutoSize = true;
            this.lblVersionProduct.Location = new System.Drawing.Point(323, 165);
            this.lblVersionProduct.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblVersionProduct.Name = "lblVersionProduct";
            this.lblVersionProduct.Size = new System.Drawing.Size(49, 13);
            this.lblVersionProduct.TabIndex = 34;
            this.lblVersionProduct.Text = "Version";
            this.lblVersionProduct.Visible = false;
            // 
            // txtVersionProduct
            // 
            this.txtVersionProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtVersionProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtVersionProduct.ForeColor = System.Drawing.Color.White;
            this.txtVersionProduct.Location = new System.Drawing.Point(297, 193);
            this.txtVersionProduct.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtVersionProduct.MaxLength = 20;
            this.txtVersionProduct.Name = "txtVersionProduct";
            this.txtVersionProduct.Size = new System.Drawing.Size(109, 20);
            this.txtVersionProduct.TabIndex = 4;
            this.txtVersionProduct.Visible = false;
            this.txtVersionProduct.TextChanged += new System.EventHandler(this.txtNameProduct_TextChanged);
            // 
            // lblLicenceProduct
            // 
            this.lblLicenceProduct.AutoSize = true;
            this.lblLicenceProduct.Location = new System.Drawing.Point(183, 165);
            this.lblLicenceProduct.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblLicenceProduct.Name = "lblLicenceProduct";
            this.lblLicenceProduct.Size = new System.Drawing.Size(55, 13);
            this.lblLicenceProduct.TabIndex = 32;
            this.lblLicenceProduct.Text = "Licencia";
            this.lblLicenceProduct.Visible = false;
            // 
            // txtLicenceProduct
            // 
            this.txtLicenceProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtLicenceProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtLicenceProduct.ForeColor = System.Drawing.Color.White;
            this.txtLicenceProduct.Location = new System.Drawing.Point(162, 193);
            this.txtLicenceProduct.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtLicenceProduct.MaxLength = 20;
            this.txtLicenceProduct.Name = "txtLicenceProduct";
            this.txtLicenceProduct.Size = new System.Drawing.Size(109, 20);
            this.txtLicenceProduct.TabIndex = 31;
            this.txtLicenceProduct.Visible = false;
            this.txtLicenceProduct.TextChanged += new System.EventHandler(this.txtNameProduct_TextChanged);
            // 
            // lblMeassuresProduct
            // 
            this.lblMeassuresProduct.AutoSize = true;
            this.lblMeassuresProduct.Location = new System.Drawing.Point(183, 165);
            this.lblMeassuresProduct.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMeassuresProduct.Name = "lblMeassuresProduct";
            this.lblMeassuresProduct.Size = new System.Drawing.Size(54, 13);
            this.lblMeassuresProduct.TabIndex = 30;
            this.lblMeassuresProduct.Text = "Medidas";
            this.lblMeassuresProduct.Visible = false;
            // 
            // txtMeassuresProduct
            // 
            this.txtMeassuresProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtMeassuresProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtMeassuresProduct.ForeColor = System.Drawing.Color.White;
            this.txtMeassuresProduct.Location = new System.Drawing.Point(162, 193);
            this.txtMeassuresProduct.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtMeassuresProduct.MaxLength = 20;
            this.txtMeassuresProduct.Name = "txtMeassuresProduct";
            this.txtMeassuresProduct.Size = new System.Drawing.Size(109, 20);
            this.txtMeassuresProduct.TabIndex = 29;
            this.txtMeassuresProduct.Visible = false;
            this.txtMeassuresProduct.TextChanged += new System.EventHandler(this.txtNameProduct_TextChanged);
            // 
            // lblPriceProduct
            // 
            this.lblPriceProduct.AutoSize = true;
            this.lblPriceProduct.Location = new System.Drawing.Point(190, 103);
            this.lblPriceProduct.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPriceProduct.Name = "lblPriceProduct";
            this.lblPriceProduct.Size = new System.Drawing.Size(43, 13);
            this.lblPriceProduct.TabIndex = 28;
            this.lblPriceProduct.Text = "Precio";
            // 
            // txtPriceProduct
            // 
            this.txtPriceProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtPriceProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPriceProduct.ForeColor = System.Drawing.Color.White;
            this.txtPriceProduct.Location = new System.Drawing.Point(162, 128);
            this.txtPriceProduct.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtPriceProduct.MaxLength = 10;
            this.txtPriceProduct.Name = "txtPriceProduct";
            this.txtPriceProduct.Size = new System.Drawing.Size(109, 20);
            this.txtPriceProduct.TabIndex = 3;
            this.txtPriceProduct.TextChanged += new System.EventHandler(this.txtNameProduct_TextChanged);
            this.txtPriceProduct.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPriceProduct_KeyPress);
            // 
            // lblNameProduct
            // 
            this.lblNameProduct.AutoSize = true;
            this.lblNameProduct.Location = new System.Drawing.Point(61, 103);
            this.lblNameProduct.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNameProduct.Name = "lblNameProduct";
            this.lblNameProduct.Size = new System.Drawing.Size(50, 13);
            this.lblNameProduct.TabIndex = 26;
            this.lblNameProduct.Text = "Nombre";
            // 
            // txtNameProduct
            // 
            this.txtNameProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtNameProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtNameProduct.ForeColor = System.Drawing.Color.White;
            this.txtNameProduct.Location = new System.Drawing.Point(28, 128);
            this.txtNameProduct.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtNameProduct.MaxLength = 20;
            this.txtNameProduct.Name = "txtNameProduct";
            this.txtNameProduct.Size = new System.Drawing.Size(109, 20);
            this.txtNameProduct.TabIndex = 1;
            this.txtNameProduct.TextChanged += new System.EventHandler(this.txtNameProduct_TextChanged);
            this.txtNameProduct.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNameProduct_KeyPress);
            // 
            // lblDescriptionProduct
            // 
            this.lblDescriptionProduct.AutoSize = true;
            this.lblDescriptionProduct.Location = new System.Drawing.Point(48, 227);
            this.lblDescriptionProduct.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDescriptionProduct.Name = "lblDescriptionProduct";
            this.lblDescriptionProduct.Size = new System.Drawing.Size(74, 13);
            this.lblDescriptionProduct.TabIndex = 24;
            this.lblDescriptionProduct.Text = "Descripción";
            // 
            // lblIdProduct
            // 
            this.lblIdProduct.AutoSize = true;
            this.lblIdProduct.Location = new System.Drawing.Point(326, 103);
            this.lblIdProduct.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblIdProduct.Name = "lblIdProduct";
            this.lblIdProduct.Size = new System.Drawing.Size(46, 13);
            this.lblIdProduct.TabIndex = 23;
            this.lblIdProduct.Text = "Código";
            // 
            // txtIdProduct
            // 
            this.txtIdProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtIdProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtIdProduct.Enabled = false;
            this.txtIdProduct.ForeColor = System.Drawing.Color.White;
            this.txtIdProduct.Location = new System.Drawing.Point(297, 128);
            this.txtIdProduct.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtIdProduct.MaxLength = 10;
            this.txtIdProduct.Name = "txtIdProduct";
            this.txtIdProduct.ReadOnly = true;
            this.txtIdProduct.Size = new System.Drawing.Size(109, 20);
            this.txtIdProduct.TabIndex = 5;
            this.txtIdProduct.TextChanged += new System.EventHandler(this.txtNameProduct_TextChanged);
            // 
            // btnModifyProduct
            // 
            this.btnModifyProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.btnModifyProduct.Enabled = false;
            this.btnModifyProduct.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnModifyProduct.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.btnModifyProduct.Location = new System.Drawing.Point(306, 410);
            this.btnModifyProduct.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnModifyProduct.Name = "btnModifyProduct";
            this.btnModifyProduct.Size = new System.Drawing.Size(100, 27);
            this.btnModifyProduct.TabIndex = 11;
            this.btnModifyProduct.Text = "Modificar";
            this.btnModifyProduct.UseVisualStyleBackColor = false;
            this.btnModifyProduct.Click += new System.EventHandler(this.btnModifyProduct_Click);
            // 
            // txtTypeProduct
            // 
            this.txtTypeProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtTypeProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTypeProduct.Enabled = false;
            this.txtTypeProduct.ForeColor = System.Drawing.Color.White;
            this.txtTypeProduct.Location = new System.Drawing.Point(100, 60);
            this.txtTypeProduct.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtTypeProduct.MaxLength = 20;
            this.txtTypeProduct.Name = "txtTypeProduct";
            this.txtTypeProduct.ReadOnly = true;
            this.txtTypeProduct.Size = new System.Drawing.Size(109, 20);
            this.txtTypeProduct.TabIndex = 7;
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.btnCancel.Location = new System.Drawing.Point(28, 410);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(100, 27);
            this.btnCancel.TabIndex = 12;
            this.btnCancel.Text = "Cancelar";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // cbEnabled
            // 
            this.cbEnabled.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.cbEnabled.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbEnabled.ForeColor = System.Drawing.Color.White;
            this.cbEnabled.FormattingEnabled = true;
            this.cbEnabled.Items.AddRange(new object[] {
            "Habilitado",
            "Inhabilitado"});
            this.cbEnabled.Location = new System.Drawing.Point(232, 60);
            this.cbEnabled.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbEnabled.Name = "cbEnabled";
            this.cbEnabled.Size = new System.Drawing.Size(114, 21);
            this.cbEnabled.TabIndex = 9;
            // 
            // lblType
            // 
            this.lblType.AutoSize = true;
            this.lblType.Location = new System.Drawing.Point(125, 38);
            this.lblType.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblType.Name = "lblType";
            this.lblType.Size = new System.Drawing.Size(61, 13);
            this.lblType.TabIndex = 45;
            this.lblType.Text = "Categoria";
            // 
            // pnlTopBorder
            // 
            this.pnlTopBorder.BackColor = System.Drawing.Color.Transparent;
            this.pnlTopBorder.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTopBorder.Location = new System.Drawing.Point(0, 0);
            this.pnlTopBorder.Name = "pnlTopBorder";
            this.pnlTopBorder.Size = new System.Drawing.Size(439, 20);
            this.pnlTopBorder.TabIndex = 67;
            this.pnlTopBorder.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlTopBorder_MouseDown);
            this.pnlTopBorder.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pnlTopBorder_MouseMove);
            this.pnlTopBorder.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pnlTopBorder_MouseUp);
            // 
            // ModifyProduct
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(234)))), ((int)(((byte)(199)))));
            this.ClientSize = new System.Drawing.Size(439, 449);
            this.ControlBox = false;
            this.Controls.Add(this.pnlTopBorder);
            this.Controls.Add(this.lblType);
            this.Controls.Add(this.cbEnabled);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.txtTypeProduct);
            this.Controls.Add(this.btnModifyProduct);
            this.Controls.Add(this.lblCantity);
            this.Controls.Add(this.txtCantityProduct);
            this.Controls.Add(this.txtDescriptionProduct);
            this.Controls.Add(this.lblModelProduct);
            this.Controls.Add(this.txtModelProduct);
            this.Controls.Add(this.lblVersionProduct);
            this.Controls.Add(this.txtVersionProduct);
            this.Controls.Add(this.lblLicenceProduct);
            this.Controls.Add(this.txtLicenceProduct);
            this.Controls.Add(this.lblMeassuresProduct);
            this.Controls.Add(this.txtMeassuresProduct);
            this.Controls.Add(this.lblPriceProduct);
            this.Controls.Add(this.txtPriceProduct);
            this.Controls.Add(this.lblNameProduct);
            this.Controls.Add(this.txtNameProduct);
            this.Controls.Add(this.lblDescriptionProduct);
            this.Controls.Add(this.lblIdProduct);
            this.Controls.Add(this.txtIdProduct);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "ModifyProduct";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.ModifyProduct_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblCantity;
        private System.Windows.Forms.TextBox txtCantityProduct;
        private System.Windows.Forms.RichTextBox txtDescriptionProduct;
        private System.Windows.Forms.Label lblModelProduct;
        private System.Windows.Forms.TextBox txtModelProduct;
        private System.Windows.Forms.Label lblVersionProduct;
        private System.Windows.Forms.TextBox txtVersionProduct;
        private System.Windows.Forms.Label lblLicenceProduct;
        private System.Windows.Forms.TextBox txtLicenceProduct;
        private System.Windows.Forms.Label lblMeassuresProduct;
        private System.Windows.Forms.TextBox txtMeassuresProduct;
        private System.Windows.Forms.Label lblPriceProduct;
        private System.Windows.Forms.TextBox txtPriceProduct;
        private System.Windows.Forms.Label lblNameProduct;
        private System.Windows.Forms.TextBox txtNameProduct;
        private System.Windows.Forms.Label lblDescriptionProduct;
        private System.Windows.Forms.Label lblIdProduct;
        private System.Windows.Forms.TextBox txtIdProduct;
        private System.Windows.Forms.Button btnModifyProduct;
        private System.Windows.Forms.TextBox txtTypeProduct;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.ComboBox cbEnabled;
        private System.Windows.Forms.Label lblType;
        private System.Windows.Forms.Panel pnlTopBorder;
    }
}