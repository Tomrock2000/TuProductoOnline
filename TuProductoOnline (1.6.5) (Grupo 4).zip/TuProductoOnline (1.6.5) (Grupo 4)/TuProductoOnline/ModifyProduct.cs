﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TuProductoOnline
{
    public partial class ModifyProduct : Form
    {
        Product product = new Product();

        public ModifyProduct(Product producttomodify)
        {
            product = producttomodify;
            InitializeComponent();
            LoadProduct();
        }
        public void LoadProduct()
        {
            if (product.Type == "Hardware")
            {
                txtMeassuresProduct.Show();
                lblMeassuresProduct.Show();
                txtModelProduct.Hide();
                lblModelProduct.Hide();
                txtLicenceProduct.Hide();
                lblLicenceProduct.Hide();
                txtVersionProduct.Hide();
                lblVersionProduct.Hide();

                txtIdProduct.Text = product.Id;
                txtNameProduct.Text = product.Name;
                txtPriceProduct.Text = product.Price.ToString();
                txtTypeProduct.Text = product.Type;
                txtDescriptionProduct.Text = product.Description;
                txtCantityProduct.Text = product.Cantity.ToString();
                txtMeassuresProduct.Text = product.Hard.Meassures.ToString();
                if (product.Enabled == true)
                {
                    cbEnabled.SelectedItem = "Habilitado";
                }
                if (product.Enabled == false)
                {
                    cbEnabled.SelectedItem = "Inhabilitado";

                }
            }
            if (product.Type == "Software")
            {
                txtMeassuresProduct.Hide();
                lblMeassuresProduct.Hide();
                txtModelProduct.Hide();
                lblModelProduct.Hide();
                txtLicenceProduct.Show();
                lblLicenceProduct.Show();
                txtVersionProduct.Show();
                lblVersionProduct.Show();

                txtIdProduct.Text = product.Id;
                txtNameProduct.Text = product.Name;
                txtPriceProduct.Text = product.Price.ToString();
                txtTypeProduct.Text = product.Type;
                txtDescriptionProduct.Text = product.Description;
                txtCantityProduct.Text = product.Cantity.ToString();
                txtLicenceProduct.Text = product.Soft.Licence.ToString();
                txtVersionProduct.Text = product.Soft.Version.ToString();
                if (product.Enabled == true)
                {
                    cbEnabled.SelectedItem = "Habilitado";
                }
                if (product.Enabled == false)
                {
                    cbEnabled.SelectedItem = "Inhabilitado";
                }

            }
            if (product.Type == "Device")
            {
                txtMeassuresProduct.Hide();
                lblMeassuresProduct.Hide();
                txtModelProduct.Show();
                lblModelProduct.Show();
                txtLicenceProduct.Hide();
                lblLicenceProduct.Hide();
                txtVersionProduct.Hide();
                lblVersionProduct.Hide();

                txtIdProduct.Text = product.Id;
                txtNameProduct.Text = product.Name;
                txtPriceProduct.Text = product.Price.ToString();
                txtTypeProduct.Text = product.Type;
                txtDescriptionProduct.Text = product.Description;
                txtCantityProduct.Text = product.Cantity.ToString();
                txtModelProduct.Text = product.Devi.Model.ToString();
                if (product.Enabled == true)
                {
                    cbEnabled.SelectedItem = "Habilitado";
                }
                if (product.Enabled == false)
                {
                    cbEnabled.SelectedItem = "Inhabilitado";
                }

            }
        }


        private static string _pathproduct = Path.GetFullPath(Path.Combine(Application.StartupPath, "..\\..", "Products.json"));

        private void btnModifyProduct_Click(object sender, EventArgs e)
        {
            var productsFromFile = ProductManageMenu.GetProductsFromFile();
            var products = JsonConvert.DeserializeObject<List<Product>>(productsFromFile);
            DialogResult result = MessageBox.Show("¿Está seguro de que desea modificar este Producto?", "Confirmación", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {

                string tomodify = product.Id;
                foreach (Product product in products)
                {
                    if (tomodify == product.Id)
                    {
                        product.Name = txtNameProduct.Text;
                        product.Price = float.Parse(txtPriceProduct.Text);
                        product.Description = txtDescriptionProduct.Text;
                        product.Cantity = int.Parse(txtCantityProduct.Text);
                        if (cbEnabled.SelectedItem.ToString() == "Habilitado")
                        {
                            product.Enabled = true;
                        }
                        if (cbEnabled.SelectedItem.ToString() == "Inhabilitado")
                        {
                            product.Enabled = false;
                        }
                    }
                }
                string productsJson = JsonConvert.SerializeObject(products.ToArray(), Formatting.Indented);//Serializa el objeto en forma de users(Una lista) y lo guarda en la variable
                File.WriteAllText(_pathproduct, productsJson);
                MessageBox.Show("El producto se ha modificado correctamente");
                ProductManageMenu pro = new ProductManageMenu();
                foreach (Form form in Application.OpenForms)
                {
                    if (form is ProductManageMenu)
                    {
                        pro = (ProductManageMenu)form;
                        break;
                    }
                }
                pro.ProductLoad();
                this.Close();
            }
        }
        private void txtNameProduct_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsSeparator(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtPriceProduct_KeyPress(object sender, KeyPressEventArgs e)
        {
            OnlyNumber(e, false);
        }
        private static void OnlyNumber(KeyPressEventArgs e, bool isdecimal)
        {
            string accepted;
            if (!isdecimal)
            {
                accepted = "0123456789," + Convert.ToChar(8);

            }
            else
            {
                accepted = "0123456789," + Convert.ToChar(8);

            }
            if (accepted.Contains("" + e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }


        private void txtCantity_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        public void TextChecker()
        {
            if (txtTypeProduct.Text=="Device")
            {
                if (txtNameProduct.Text != string.Empty && txtDescriptionProduct.Text != string.Empty && txtCantityProduct.Text != string.Empty && txtPriceProduct.Text != string.Empty && txtModelProduct.Text != string.Empty && cbEnabled.SelectedItem != null)
                {
                    btnModifyProduct.Enabled = true;
                }
                else { btnModifyProduct.Enabled = false; }
            }
            if (txtTypeProduct.Text == "Hardware")
            {
                if (txtNameProduct.Text != string.Empty && txtDescriptionProduct.Text != string.Empty && txtCantityProduct.Text != string.Empty && txtPriceProduct.Text != string.Empty && txtMeassuresProduct.Text != string.Empty && cbEnabled.SelectedItem!=null)
                {
                    btnModifyProduct.Enabled = true;
                }
                else { btnModifyProduct.Enabled = false; }
            }
            if (txtTypeProduct.Text == "Software")
            {
                if (txtNameProduct.Text != string.Empty && txtDescriptionProduct.Text != string.Empty && txtCantityProduct.Text != string.Empty && txtPriceProduct.Text != string.Empty && txtVersionProduct.Text != string.Empty && txtLicenceProduct.Text != string.Empty && cbEnabled.SelectedItem != null)
                {
                    btnModifyProduct.Enabled = true;
                }
                else { btnModifyProduct.Enabled = false; }
            }
        }

        private void txtNameProduct_TextChanged(object sender, EventArgs e)
        {
            TextChecker();
        }
        int m, mx, my;
        private void pnlTopBorder_MouseDown(object sender, MouseEventArgs e)
        {
            m = 1;
            mx = e.X;
            my = e.Y;
        }

        private void ModifyProduct_Load(object sender, EventArgs e)
        {

        }

        private void pnlTopBorder_MouseMove(object sender, MouseEventArgs e)
        {
            if (m == 1)
            {
                this.SetDesktopLocation(MousePosition.X - mx, MousePosition.Y - my);
            }
        }

        private void pnlTopBorder_MouseUp(object sender, MouseEventArgs e)
        {
            m = 0;
        }
    }
}
