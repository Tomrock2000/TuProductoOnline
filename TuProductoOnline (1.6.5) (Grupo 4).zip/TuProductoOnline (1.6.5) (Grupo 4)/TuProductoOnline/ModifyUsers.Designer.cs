﻿namespace TuProductoOnline
{
    partial class ModifyUsers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ModifyUsers));
            this.label2 = new System.Windows.Forms.Label();
            this.txtModifyPasswordUsers = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtModifyUsersNameCode = new System.Windows.Forms.TextBox();
            this.btnModifyUsers = new System.Windows.Forms.Button();
            this.txtModifyIDUsers = new System.Windows.Forms.TextBox();
            this.lblCédula = new System.Windows.Forms.Label();
            this.txtModifyPhoneUsers = new System.Windows.Forms.TextBox();
            this.lblDirección = new System.Windows.Forms.Label();
            this.txtModifyAdressUsers = new System.Windows.Forms.TextBox();
            this.lblPhone = new System.Windows.Forms.Label();
            this.txtModifySurnameUsers = new System.Windows.Forms.TextBox();
            this.lblApellido = new System.Windows.Forms.Label();
            this.txtModifyNameUsers = new System.Windows.Forms.TextBox();
            this.lblNombre = new System.Windows.Forms.Label();
            this.errorProviderUsers1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProviderUsers2 = new System.Windows.Forms.ErrorProvider(this.components);
            this.pnlTopBorder = new System.Windows.Forms.Panel();
            this.btnCancel = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderUsers1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderUsers2)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(66, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 13);
            this.label2.TabIndex = 79;
            this.label2.Text = "Contraseña";
            // 
            // txtModifyPasswordUsers
            // 
            this.txtModifyPasswordUsers.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtModifyPasswordUsers.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtModifyPasswordUsers.ForeColor = System.Drawing.Color.White;
            this.txtModifyPasswordUsers.Location = new System.Drawing.Point(34, 108);
            this.txtModifyPasswordUsers.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtModifyPasswordUsers.Name = "txtModifyPasswordUsers";
            this.txtModifyPasswordUsers.Size = new System.Drawing.Size(132, 20);
            this.txtModifyPasswordUsers.TabIndex = 2;
            this.txtModifyPasswordUsers.Validating += new System.ComponentModel.CancelEventHandler(this.txtModifyPasswordUsers_Validating);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(44, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(115, 13);
            this.label1.TabIndex = 77;
            this.label1.Text = "Nombre de Usuario";
            // 
            // txtModifyUsersNameCode
            // 
            this.txtModifyUsersNameCode.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtModifyUsersNameCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtModifyUsersNameCode.ForeColor = System.Drawing.Color.White;
            this.txtModifyUsersNameCode.Location = new System.Drawing.Point(34, 55);
            this.txtModifyUsersNameCode.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtModifyUsersNameCode.Name = "txtModifyUsersNameCode";
            this.txtModifyUsersNameCode.Size = new System.Drawing.Size(132, 20);
            this.txtModifyUsersNameCode.TabIndex = 1;
            this.txtModifyUsersNameCode.Validating += new System.ComponentModel.CancelEventHandler(this.txtModifyUsersNameCode_Validating);
            // 
            // btnModifyUsers
            // 
            this.btnModifyUsers.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.btnModifyUsers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnModifyUsers.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.btnModifyUsers.Location = new System.Drawing.Point(220, 263);
            this.btnModifyUsers.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnModifyUsers.Name = "btnModifyUsers";
            this.btnModifyUsers.Size = new System.Drawing.Size(100, 31);
            this.btnModifyUsers.TabIndex = 8;
            this.btnModifyUsers.Text = "Modificar";
            this.btnModifyUsers.UseVisualStyleBackColor = false;
            this.btnModifyUsers.Click += new System.EventHandler(this.btnModifyUsers_Click);
            // 
            // txtModifyIDUsers
            // 
            this.txtModifyIDUsers.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtModifyIDUsers.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtModifyIDUsers.ForeColor = System.Drawing.Color.White;
            this.txtModifyIDUsers.Location = new System.Drawing.Point(188, 165);
            this.txtModifyIDUsers.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtModifyIDUsers.Name = "txtModifyIDUsers";
            this.txtModifyIDUsers.Size = new System.Drawing.Size(132, 20);
            this.txtModifyIDUsers.TabIndex = 7;
            this.txtModifyIDUsers.Validating += new System.ComponentModel.CancelEventHandler(this.txtModifyIDUsers_Validating);
            // 
            // lblCédula
            // 
            this.lblCédula.AutoSize = true;
            this.lblCédula.Location = new System.Drawing.Point(230, 140);
            this.lblCédula.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCédula.Name = "lblCédula";
            this.lblCédula.Size = new System.Drawing.Size(46, 13);
            this.lblCédula.TabIndex = 73;
            this.lblCédula.Text = "Cédula";
            // 
            // txtModifyPhoneUsers
            // 
            this.txtModifyPhoneUsers.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtModifyPhoneUsers.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtModifyPhoneUsers.ForeColor = System.Drawing.Color.White;
            this.txtModifyPhoneUsers.Location = new System.Drawing.Point(38, 165);
            this.txtModifyPhoneUsers.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtModifyPhoneUsers.MaxLength = 11;
            this.txtModifyPhoneUsers.Name = "txtModifyPhoneUsers";
            this.txtModifyPhoneUsers.Size = new System.Drawing.Size(132, 20);
            this.txtModifyPhoneUsers.TabIndex = 5;
            this.txtModifyPhoneUsers.Validating += new System.ComponentModel.CancelEventHandler(this.txtModifyPhoneUsers_Validating);
            // 
            // lblDirección
            // 
            this.lblDirección.AutoSize = true;
            this.lblDirección.Location = new System.Drawing.Point(69, 195);
            this.lblDirección.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDirección.Name = "lblDirección";
            this.lblDirección.Size = new System.Drawing.Size(61, 13);
            this.lblDirección.TabIndex = 71;
            this.lblDirección.Text = "Dirección";
            // 
            // txtModifyAdressUsers
            // 
            this.txtModifyAdressUsers.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtModifyAdressUsers.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtModifyAdressUsers.ForeColor = System.Drawing.Color.White;
            this.txtModifyAdressUsers.Location = new System.Drawing.Point(38, 219);
            this.txtModifyAdressUsers.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtModifyAdressUsers.Name = "txtModifyAdressUsers";
            this.txtModifyAdressUsers.Size = new System.Drawing.Size(132, 20);
            this.txtModifyAdressUsers.TabIndex = 6;
            this.txtModifyAdressUsers.Validating += new System.ComponentModel.CancelEventHandler(this.txtModifyAdressUsers_Validating);
            // 
            // lblPhone
            // 
            this.lblPhone.AutoSize = true;
            this.lblPhone.Location = new System.Drawing.Point(71, 140);
            this.lblPhone.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Size = new System.Drawing.Size(57, 13);
            this.lblPhone.TabIndex = 69;
            this.lblPhone.Text = "Teléfono";
            // 
            // txtModifySurnameUsers
            // 
            this.txtModifySurnameUsers.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtModifySurnameUsers.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtModifySurnameUsers.ForeColor = System.Drawing.Color.White;
            this.txtModifySurnameUsers.Location = new System.Drawing.Point(188, 108);
            this.txtModifySurnameUsers.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtModifySurnameUsers.Name = "txtModifySurnameUsers";
            this.txtModifySurnameUsers.Size = new System.Drawing.Size(132, 20);
            this.txtModifySurnameUsers.TabIndex = 4;
            this.txtModifySurnameUsers.Validating += new System.ComponentModel.CancelEventHandler(this.txtModifySurnameUsers_Validating);
            // 
            // lblApellido
            // 
            this.lblApellido.AutoSize = true;
            this.lblApellido.Location = new System.Drawing.Point(225, 84);
            this.lblApellido.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblApellido.Name = "lblApellido";
            this.lblApellido.Size = new System.Drawing.Size(52, 13);
            this.lblApellido.TabIndex = 67;
            this.lblApellido.Text = "Apellido";
            // 
            // txtModifyNameUsers
            // 
            this.txtModifyNameUsers.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtModifyNameUsers.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtModifyNameUsers.ForeColor = System.Drawing.Color.White;
            this.txtModifyNameUsers.Location = new System.Drawing.Point(188, 55);
            this.txtModifyNameUsers.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtModifyNameUsers.Name = "txtModifyNameUsers";
            this.txtModifyNameUsers.Size = new System.Drawing.Size(132, 20);
            this.txtModifyNameUsers.TabIndex = 3;
            this.txtModifyNameUsers.Validating += new System.ComponentModel.CancelEventHandler(this.txtModifyNameUsers_Validating);
            // 
            // lblNombre
            // 
            this.lblNombre.AutoSize = true;
            this.lblNombre.Location = new System.Drawing.Point(225, 29);
            this.lblNombre.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(50, 13);
            this.lblNombre.TabIndex = 65;
            this.lblNombre.Text = "Nombre";
            // 
            // errorProviderUsers1
            // 
            this.errorProviderUsers1.ContainerControl = this;
            // 
            // errorProviderUsers2
            // 
            this.errorProviderUsers2.ContainerControl = this;
            // 
            // pnlTopBorder
            // 
            this.pnlTopBorder.BackColor = System.Drawing.Color.Transparent;
            this.pnlTopBorder.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTopBorder.Location = new System.Drawing.Point(0, 0);
            this.pnlTopBorder.Name = "pnlTopBorder";
            this.pnlTopBorder.Size = new System.Drawing.Size(361, 20);
            this.pnlTopBorder.TabIndex = 84;
            this.pnlTopBorder.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlTopBorder_MouseDown);
            this.pnlTopBorder.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pnlTopBorder_MouseMove);
            this.pnlTopBorder.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pnlTopBorder_MouseUp);
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.btnCancel.Location = new System.Drawing.Point(38, 263);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(100, 31);
            this.btnCancel.TabIndex = 86;
            this.btnCancel.Text = "Cancelar";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // ModifyUsers
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(234)))), ((int)(((byte)(199)))));
            this.ClientSize = new System.Drawing.Size(361, 322);
            this.ControlBox = false;
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.pnlTopBorder);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtModifyPasswordUsers);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtModifyUsersNameCode);
            this.Controls.Add(this.btnModifyUsers);
            this.Controls.Add(this.txtModifyIDUsers);
            this.Controls.Add(this.lblCédula);
            this.Controls.Add(this.txtModifyPhoneUsers);
            this.Controls.Add(this.lblDirección);
            this.Controls.Add(this.txtModifyAdressUsers);
            this.Controls.Add(this.lblPhone);
            this.Controls.Add(this.txtModifySurnameUsers);
            this.Controls.Add(this.lblApellido);
            this.Controls.Add(this.txtModifyNameUsers);
            this.Controls.Add(this.lblNombre);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "ModifyUsers";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderUsers1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderUsers2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtModifyPasswordUsers;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtModifyUsersNameCode;
        private System.Windows.Forms.Button btnModifyUsers;
        private System.Windows.Forms.TextBox txtModifyIDUsers;
        private System.Windows.Forms.Label lblCédula;
        private System.Windows.Forms.TextBox txtModifyPhoneUsers;
        private System.Windows.Forms.Label lblDirección;
        private System.Windows.Forms.TextBox txtModifyAdressUsers;
        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.TextBox txtModifySurnameUsers;
        private System.Windows.Forms.Label lblApellido;
        private System.Windows.Forms.TextBox txtModifyNameUsers;
        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.ErrorProvider errorProviderUsers1;
        private System.Windows.Forms.ErrorProvider errorProviderUsers2;
        private System.Windows.Forms.Panel pnlTopBorder;
        private System.Windows.Forms.Button btnCancel;
    }
}