﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TuProductoOnline
{
    public partial class ModifyUsers : Form
    {
        Employee user = new Employee();
        Admin admin = new Admin();
        public ModifyUsers(Admin admintomodify,Employee usertomodify)
        {
            user = usertomodify;
            admin = admintomodify;
            InitializeComponent();
            UsersLoad();
            AdminLoad();

        }

        private static string _pathusers = Path.GetFullPath(Path.Combine(Application.StartupPath, "..\\..", "Users.json"));
        public static string _pathadmin = Path.GetFullPath(Path.Combine(Application.StartupPath, "..\\..", "Admins.json"));
        private static string GetUsersFromFile()
        {
            string UsersJsonFromFile;
            using (var reader = new StreamReader(_pathusers))
            {
                UsersJsonFromFile = reader.ReadToEnd();
            }
            return UsersJsonFromFile;
        }
        public static string GetAdminsFromFile()//Este metodo lee el json y lo guarda en una variable
        {
            string adminsJsonfromFile;//Declara la variable en la que se guardará el json
            using (var reader = new StreamReader(_pathadmin))//Mediante el lector, se leerá todo el json y lo guardará en la variable
            {
                adminsJsonfromFile = reader.ReadToEnd();
            }
            return adminsJsonfromFile;//Devuelve el valor de la variable, que sería la lectura del json
        }

        public void UsersLoad()
        {
            if (admin.Name == null && user != null)
            {
                txtModifyNameUsers.Text = user.Name;
                txtModifySurnameUsers.Text = user.LastName;
                txtModifyIDUsers.Text = user.Id.ToString();
                txtModifyAdressUsers.Text = user.Address;
                txtModifyPhoneUsers.Text = user.Phone.ToString();
                txtModifyUsersNameCode.Text = user.User;
                txtModifyPasswordUsers.Text = user.Password.ToString();
            }

        }
        public void AdminLoad()
        {
            if (admin != null & user.Name == null)
            {
                txtModifyNameUsers.Text = admin.Name;
                txtModifySurnameUsers.Text = admin.LastName;
                txtModifyIDUsers.Text = admin.Id.ToString();
                txtModifyAdressUsers.Text = admin.Address;
                txtModifyPhoneUsers.Text = admin.Phone.ToString();
                txtModifyUsersNameCode.Text = admin.User;
                txtModifyPasswordUsers.Text = admin.Password.ToString();
            }
        }
        

        private void btnModifyUsers_Click(object sender, EventArgs e)
        {
            DelteErrorProviderUsers1();
            if (CheckerUsers())
            {
                if (user != null && admin.Name == null)
                {
                    var usersFromFile = GetUsersFromFile();
                    var users = JsonConvert.DeserializeObject<List<Employee>>(usersFromFile);
                    DialogResult result1 = MessageBox.Show("¿Esta seguro que desea modificar este Usuario?", "Confirmación", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (result1 == DialogResult.Yes)
                    {

                        long tomodify1 = user.Id;
                        foreach (Employee employee in users)
                        {
                            if (tomodify1 == employee.Id)
                            {
                                employee.Name = txtModifyNameUsers.Text;
                                employee.LastName = txtModifySurnameUsers.Text;
                                employee.Id = long.Parse(txtModifyIDUsers.Text);
                                employee.Phone = long.Parse(txtModifyPhoneUsers.Text);
                                employee.Address = txtModifyAdressUsers.Text;
                                employee.User = txtModifyUsersNameCode.Text;
                                employee.Password = long.Parse(txtModifyPasswordUsers.Text);
                            }
                        }
                        string userslist = JsonConvert.SerializeObject(users.ToArray(), Formatting.Indented);
                        File.WriteAllText(_pathusers, userslist);
                        UserManageMenu us = new UserManageMenu();
                        foreach (Form form in Application.OpenForms)
                        {
                            if (form is UserManageMenu)
                            {
                                us = (UserManageMenu)form;
                                break;
                            }
                        }
                        us.UsersLoad();
                        this.Close();

                    }
                }
                if (admin != null && user.Name == null)
                {
                    var adminsfromfile = GetAdminsFromFile();//Aplica el metodo antes mencionado
                    var admins = JsonConvert.DeserializeObject<List<Admin>>(adminsfromfile);
                    DialogResult result1 = MessageBox.Show("¿Esta seguro que desea modificar este Admin?", "Confirmación", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (result1 == DialogResult.Yes)
                    {

                        long tomodify1 = admin.Id;
                        foreach (Admin admin in admins)
                        {
                            if (tomodify1 == admin.Id)
                            {
                                admin.Name = txtModifyNameUsers.Text;
                                admin.LastName = txtModifySurnameUsers.Text;
                                admin.Id = long.Parse(txtModifyIDUsers.Text);
                                admin.Phone = long.Parse(txtModifyPhoneUsers.Text);
                                admin.Address = txtModifyAdressUsers.Text;
                                admin.User = txtModifyUsersNameCode.Text;
                                admin.Password = long.Parse(txtModifyPasswordUsers.Text);
                            }
                        }
                        string adminsJson = JsonConvert.SerializeObject(admins.ToArray(), Formatting.Indented);//Serializa el objeto en forma de users(Una lista) y lo guarda en la variable
                        File.WriteAllText(_pathadmin, adminsJson);
                        UserManageMenu us = new UserManageMenu();
                        foreach (Form form in Application.OpenForms)
                        {
                            if (form is UserManageMenu)
                            {
                                us = (UserManageMenu)form;
                                break;
                            }
                        }
                        us.AdminsLoad();
                        this.Close();
                    }
                }
            }
        }

        private void btnComeBackModifyUsers_Click(object sender, EventArgs e)
        {
            this.Close();
            UserManageMenu.ActiveForm.Show();
        }



        public void DelteErrorProviderUsers1()
        {
            errorProviderUsers1.SetError(txtModifyNameUsers, "");
            errorProviderUsers1.SetError(txtModifySurnameUsers, "");
            errorProviderUsers1.SetError(txtModifyIDUsers, "");
            errorProviderUsers1.SetError(txtModifyPhoneUsers, "");
            errorProviderUsers1.SetError(txtModifyAdressUsers, "");
            errorProviderUsers1.SetError(txtModifyUsersNameCode, "");
            errorProviderUsers1.SetError(txtModifyPasswordUsers, "");
        }

        public bool CheckerUsers()
        {
            bool validar = true;
            if (txtModifyNameUsers.Text == string.Empty)
            {
                validar = false;
                errorProviderUsers1.SetError(txtModifyNameUsers, "Ingresar un Nombre");
            }
            if (txtModifyPhoneUsers.Text == string.Empty)
            {
                validar = false;
                errorProviderUsers1.SetError(txtModifyPhoneUsers, "Ingresar un Telefono");
            }
            if (txtModifyIDUsers.Text == string.Empty)
            {
                validar = false;
                errorProviderUsers1.SetError(txtModifyIDUsers, "Ingresar un ID");
            }
            if (txtModifySurnameUsers.Text == string.Empty)
            {
                validar = false;
                errorProviderUsers1.SetError(txtModifySurnameUsers, "Ingresar un Apellido");
            }
            if (txtModifyAdressUsers.Text == string.Empty)
            {
                validar = false;
                errorProviderUsers1.SetError(txtModifyAdressUsers, "Ingresar una Direccion");
            }
            if (txtModifyUsersNameCode.Text == string.Empty)
            {
                validar = false;
                errorProviderUsers1.SetError(txtModifyUsersNameCode, "Ingrese un Usario");
            }
            if (txtModifyPasswordUsers.Text == string.Empty)
            {
                validar = false;
                errorProviderUsers1.SetError(txtModifyPasswordUsers, "Ingrese una contraseña");
            }
            return validar;
        }

        private void txtModifyNameUsers_Validating(object sender, CancelEventArgs e)
        {
            bool istrue2 = true;
            foreach (char c in txtModifyNameUsers.Text)
            {
                if (!Char.IsLetter(c) && !Char.IsWhiteSpace(c))
                {
                    istrue2 = false;
                    break;
                }
            }

            if (!istrue2)
            {
                errorProviderUsers2.SetError(txtModifyNameUsers, "Ingrese Solo Letras");
                btnModifyUsers.Enabled = false;
                return;
            }

            // Si la validación es correcta, limpiar el error provider y habilitar el botón
            errorProviderUsers2.SetError(txtModifyNameUsers, "");
            btnModifyUsers.Enabled = true;
        }

        private void txtModifySurnameUsers_Validating(object sender, CancelEventArgs e)
        {
            bool istrue1 = true;
            foreach (char c in txtModifySurnameUsers.Text)
            {
                if (!Char.IsLetter(c) && !Char.IsWhiteSpace(c))
                {
                    istrue1 = false;
                    break;
                }
            }

            if (!istrue1)
            {
                errorProviderUsers2.SetError(txtModifySurnameUsers, "Ingrese Solo Letras");
                btnModifyUsers.Enabled = false;
                return;
            }

            // Si la validación es correcta, limpiar el error provider y habilitar el botón
            errorProviderUsers2.SetError(txtModifySurnameUsers, "");
            btnModifyUsers.Enabled = true;
        }

        private void txtModifyPhoneUsers_Validating(object sender, CancelEventArgs e)
        {
            long validationPhoneusers;
            if (!long.TryParse(txtModifyPhoneUsers.Text, out validationPhoneusers))
            {
                errorProviderUsers2.SetError(txtModifyPhoneUsers, "Ingrese Solo Numeros");
                btnModifyUsers.Enabled = false;
            }
            else
            {
                errorProviderUsers2.SetError(txtModifyPhoneUsers, "");
                btnModifyUsers.Enabled = true;
            }

        }

        private void txtModifyAdressUsers_Validating(object sender, CancelEventArgs e)
        {
            bool istrue = true;
            foreach (char c in txtModifyAdressUsers.Text)
            {
                if (!Char.IsLetter(c) && !Char.IsDigit(c) && !Char.IsWhiteSpace(c) && !Char.IsPunctuation(c))
                {
                    istrue = false;
                    break;
                }
            }

            if (!istrue)
            {
                errorProviderUsers2.SetError(txtModifyAdressUsers, "Ingrese Solo Letras, Números y Signos");
                btnModifyUsers.Enabled = false;
                return;
            }


            errorProviderUsers2.SetError(txtModifyAdressUsers, "");
            btnModifyUsers.Enabled = true;
        }

        private void txtModifyIDUsers_Validating(object sender, CancelEventArgs e)
        {
            long validationPhoneusers;
            if (!long.TryParse(txtModifyIDUsers.Text, out validationPhoneusers))
            {
                errorProviderUsers2.SetError(txtModifyIDUsers, "Ingrese Solo Numeros");
                btnModifyUsers.Enabled = false;
            }
            else
            {
                errorProviderUsers2.SetError(txtModifyIDUsers, "");
                btnModifyUsers.Enabled = true;
            }
        }

        private void txtModifyPasswordUsers_Validating(object sender, CancelEventArgs e)
        {
            long validationPhoneusers;
            if (!long.TryParse(txtModifyPasswordUsers.Text, out validationPhoneusers))
            {
                errorProviderUsers2.SetError(txtModifyPasswordUsers, "Ingrese Solo Numeros");
                btnModifyUsers.Enabled = false;
            }
            else
            {
                errorProviderUsers2.SetError(txtModifyPasswordUsers, "");
                btnModifyUsers.Enabled = true;
            }
        }

        private void txtModifyUsersNameCode_Validating(object sender, CancelEventArgs e)
        {
            bool istrue3 = true;
            foreach (char c in txtModifyUsersNameCode.Text)
            {
                if (!Char.IsLetter(c) && !Char.IsNumber(c))
                {
                    istrue3 = false;
                    break;
                }
            }

            if (!istrue3)
            {
                errorProviderUsers2.SetError(txtModifyUsersNameCode, "Ingrese Solo Letras y numero sin espacios");
                btnModifyUsers.Enabled = false;
                return;
            }

            errorProviderUsers2.SetError(txtModifyUsersNameCode, "");
            btnModifyUsers.Enabled = true;
        }
        int m, mx, my;
        private void pnlTopBorder_MouseDown(object sender, MouseEventArgs e)
        {
            m = 1;
            mx = e.X;
            my = e.Y;
        }

        
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pnlTopBorder_MouseMove(object sender, MouseEventArgs e)
        {
            if (m == 1)
            {
                this.SetDesktopLocation(MousePosition.X - mx, MousePosition.Y - my);
            }
        }

        private void pnlTopBorder_MouseUp(object sender, MouseEventArgs e)
        {
            m = 0;
        }
    }
}
