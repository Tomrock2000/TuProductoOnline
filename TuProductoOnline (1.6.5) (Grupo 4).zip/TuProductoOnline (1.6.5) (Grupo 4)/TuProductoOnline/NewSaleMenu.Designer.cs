﻿namespace TuProductoOnline
{
    partial class NewSaleMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NewSaleMenu));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.btnAssignClient = new System.Windows.Forms.Button();
            this.lblID = new System.Windows.Forms.Label();
            this.txtIdClientSale = new System.Windows.Forms.TextBox();
            this.txtNameClientSale = new System.Windows.Forms.TextBox();
            this.lblName = new System.Windows.Forms.Label();
            this.txtPhoneClientSale = new System.Windows.Forms.TextBox();
            this.lblPhone = new System.Windows.Forms.Label();
            this.txtAdressClientSale = new System.Windows.Forms.TextBox();
            this.lblAddress = new System.Windows.Forms.Label();
            this.btnBilling = new System.Windows.Forms.Button();
            this.btnAddProductInCar = new System.Windows.Forms.Button();
            this.btnDeleteProductInCar = new System.Windows.Forms.Button();
            this.txtTotalAmount = new System.Windows.Forms.TextBox();
            this.lblTotalAmount = new System.Windows.Forms.Label();
            this.lblTotalProducts = new System.Windows.Forms.Label();
            this.txtTotalProducts = new System.Windows.Forms.TextBox();
            this.lblInform = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.chbContribuidor = new System.Windows.Forms.CheckBox();
            this.dtgvProductsInCar = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pbSummaryFrame = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvProductsInCar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSummaryFrame)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // lblWelcome
            // 
            this.lblWelcome.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.BackColor = System.Drawing.Color.Transparent;
            this.lblWelcome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblWelcome.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWelcome.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblWelcome.Location = new System.Drawing.Point(808, 28);
            this.lblWelcome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(193, 33);
            this.lblWelcome.TabIndex = 28;
            this.lblWelcome.Text = "Nueva Venta";
            this.lblWelcome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnAssignClient
            // 
            this.btnAssignClient.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnAssignClient.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.btnAssignClient.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAssignClient.FlatAppearance.BorderSize = 0;
            this.btnAssignClient.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(73)))), ((int)(((byte)(73)))));
            this.btnAssignClient.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAssignClient.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAssignClient.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.btnAssignClient.Image = global::TuProductoOnline.Properties.Resources.Asignar_Cliente;
            this.btnAssignClient.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAssignClient.Location = new System.Drawing.Point(628, 101);
            this.btnAssignClient.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAssignClient.Name = "btnAssignClient";
            this.btnAssignClient.Size = new System.Drawing.Size(175, 50);
            this.btnAssignClient.TabIndex = 1;
            this.btnAssignClient.Text = "Asignar Cliente";
            this.btnAssignClient.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAssignClient.UseVisualStyleBackColor = false;
            this.btnAssignClient.Click += new System.EventHandler(this.btnAssignClient_Click);
            // 
            // lblID
            // 
            this.lblID.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblID.AutoSize = true;
            this.lblID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblID.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblID.Location = new System.Drawing.Point(395, 42);
            this.lblID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(25, 15);
            this.lblID.TabIndex = 32;
            this.lblID.Text = "ID:";
            // 
            // txtIdClientSale
            // 
            this.txtIdClientSale.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtIdClientSale.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtIdClientSale.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtIdClientSale.Enabled = false;
            this.txtIdClientSale.Location = new System.Drawing.Point(398, 63);
            this.txtIdClientSale.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtIdClientSale.Name = "txtIdClientSale";
            this.txtIdClientSale.Size = new System.Drawing.Size(215, 26);
            this.txtIdClientSale.TabIndex = 2;
            this.txtIdClientSale.TextChanged += new System.EventHandler(this.txtNameClientSale_TextChanged);
            // 
            // txtNameClientSale
            // 
            this.txtNameClientSale.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtNameClientSale.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtNameClientSale.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtNameClientSale.Enabled = false;
            this.txtNameClientSale.Location = new System.Drawing.Point(56, 63);
            this.txtNameClientSale.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtNameClientSale.Name = "txtNameClientSale";
            this.txtNameClientSale.Size = new System.Drawing.Size(334, 26);
            this.txtNameClientSale.TabIndex = 5;
            this.txtNameClientSale.TextChanged += new System.EventHandler(this.txtNameClientSale_TextChanged);
            // 
            // lblName
            // 
            this.lblName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblName.Location = new System.Drawing.Point(56, 42);
            this.lblName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(62, 15);
            this.lblName.TabIndex = 34;
            this.lblName.Text = "Nombre:";
            // 
            // txtPhoneClientSale
            // 
            this.txtPhoneClientSale.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtPhoneClientSale.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtPhoneClientSale.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPhoneClientSale.Enabled = false;
            this.txtPhoneClientSale.Location = new System.Drawing.Point(398, 125);
            this.txtPhoneClientSale.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtPhoneClientSale.Name = "txtPhoneClientSale";
            this.txtPhoneClientSale.Size = new System.Drawing.Size(215, 26);
            this.txtPhoneClientSale.TabIndex = 4;
            this.txtPhoneClientSale.TextChanged += new System.EventHandler(this.txtNameClientSale_TextChanged);
            // 
            // lblPhone
            // 
            this.lblPhone.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblPhone.AutoSize = true;
            this.lblPhone.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhone.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblPhone.Location = new System.Drawing.Point(395, 104);
            this.lblPhone.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Size = new System.Drawing.Size(67, 15);
            this.lblPhone.TabIndex = 36;
            this.lblPhone.Text = "Teléfono:";
            // 
            // txtAdressClientSale
            // 
            this.txtAdressClientSale.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtAdressClientSale.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtAdressClientSale.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAdressClientSale.Enabled = false;
            this.txtAdressClientSale.Location = new System.Drawing.Point(56, 125);
            this.txtAdressClientSale.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtAdressClientSale.Name = "txtAdressClientSale";
            this.txtAdressClientSale.Size = new System.Drawing.Size(334, 26);
            this.txtAdressClientSale.TabIndex = 3;
            this.txtAdressClientSale.TextChanged += new System.EventHandler(this.txtNameClientSale_TextChanged);
            // 
            // lblAddress
            // 
            this.lblAddress.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblAddress.AutoSize = true;
            this.lblAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddress.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblAddress.Location = new System.Drawing.Point(53, 107);
            this.lblAddress.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(72, 15);
            this.lblAddress.TabIndex = 38;
            this.lblAddress.Text = "Dirección:";
            // 
            // btnBilling
            // 
            this.btnBilling.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnBilling.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.btnBilling.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBilling.Enabled = false;
            this.btnBilling.FlatAppearance.BorderSize = 0;
            this.btnBilling.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(73)))), ((int)(((byte)(73)))));
            this.btnBilling.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBilling.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBilling.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.btnBilling.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBilling.Location = new System.Drawing.Point(867, 478);
            this.btnBilling.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnBilling.Name = "btnBilling";
            this.btnBilling.Size = new System.Drawing.Size(103, 33);
            this.btnBilling.TabIndex = 11;
            this.btnBilling.Text = "Facturar";
            this.btnBilling.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnBilling.UseVisualStyleBackColor = false;
            this.btnBilling.Click += new System.EventHandler(this.btnBilling_Click);
            // 
            // btnAddProductInCar
            // 
            this.btnAddProductInCar.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnAddProductInCar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.btnAddProductInCar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddProductInCar.FlatAppearance.BorderSize = 0;
            this.btnAddProductInCar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(73)))), ((int)(((byte)(73)))));
            this.btnAddProductInCar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddProductInCar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.btnAddProductInCar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.btnAddProductInCar.Image = global::TuProductoOnline.Properties.Resources.Asignar_Producto;
            this.btnAddProductInCar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAddProductInCar.Location = new System.Drawing.Point(628, 172);
            this.btnAddProductInCar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAddProductInCar.Name = "btnAddProductInCar";
            this.btnAddProductInCar.Size = new System.Drawing.Size(175, 35);
            this.btnAddProductInCar.TabIndex = 9;
            this.btnAddProductInCar.Text = "Añadir Producto";
            this.btnAddProductInCar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAddProductInCar.UseVisualStyleBackColor = false;
            this.btnAddProductInCar.Click += new System.EventHandler(this.btnAddProduct_Click);
            // 
            // btnDeleteProductInCar
            // 
            this.btnDeleteProductInCar.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnDeleteProductInCar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.btnDeleteProductInCar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDeleteProductInCar.FlatAppearance.BorderSize = 0;
            this.btnDeleteProductInCar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(73)))), ((int)(((byte)(73)))));
            this.btnDeleteProductInCar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDeleteProductInCar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.btnDeleteProductInCar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.btnDeleteProductInCar.Image = ((System.Drawing.Image)(resources.GetObject("btnDeleteProductInCar.Image")));
            this.btnDeleteProductInCar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDeleteProductInCar.Location = new System.Drawing.Point(846, 213);
            this.btnDeleteProductInCar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnDeleteProductInCar.Name = "btnDeleteProductInCar";
            this.btnDeleteProductInCar.Size = new System.Drawing.Size(149, 48);
            this.btnDeleteProductInCar.TabIndex = 10;
            this.btnDeleteProductInCar.Text = "Descartar Producto";
            this.btnDeleteProductInCar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDeleteProductInCar.UseVisualStyleBackColor = false;
            this.btnDeleteProductInCar.Click += new System.EventHandler(this.btnDeleteProductInCar_Click);
            // 
            // txtTotalAmount
            // 
            this.txtTotalAmount.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtTotalAmount.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtTotalAmount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTotalAmount.Enabled = false;
            this.txtTotalAmount.Location = new System.Drawing.Point(846, 362);
            this.txtTotalAmount.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtTotalAmount.Name = "txtTotalAmount";
            this.txtTotalAmount.Size = new System.Drawing.Size(149, 26);
            this.txtTotalAmount.TabIndex = 7;
            // 
            // lblTotalAmount
            // 
            this.lblTotalAmount.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblTotalAmount.AutoSize = true;
            this.lblTotalAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalAmount.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblTotalAmount.Location = new System.Drawing.Point(877, 340);
            this.lblTotalAmount.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTotalAmount.Name = "lblTotalAmount";
            this.lblTotalAmount.Size = new System.Drawing.Size(87, 15);
            this.lblTotalAmount.TabIndex = 49;
            this.lblTotalAmount.Text = "Monto Total:";
            // 
            // lblTotalProducts
            // 
            this.lblTotalProducts.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblTotalProducts.AutoSize = true;
            this.lblTotalProducts.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalProducts.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblTotalProducts.Location = new System.Drawing.Point(864, 279);
            this.lblTotalProducts.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTotalProducts.Name = "lblTotalProducts";
            this.lblTotalProducts.Size = new System.Drawing.Size(107, 15);
            this.lblTotalProducts.TabIndex = 50;
            this.lblTotalProducts.Text = "Total Productos";
            // 
            // txtTotalProducts
            // 
            this.txtTotalProducts.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtTotalProducts.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtTotalProducts.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTotalProducts.Enabled = false;
            this.txtTotalProducts.Location = new System.Drawing.Point(846, 306);
            this.txtTotalProducts.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtTotalProducts.Name = "txtTotalProducts";
            this.txtTotalProducts.Size = new System.Drawing.Size(149, 26);
            this.txtTotalProducts.TabIndex = 6;
            // 
            // lblInform
            // 
            this.lblInform.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblInform.AutoSize = true;
            this.lblInform.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInform.Location = new System.Drawing.Point(311, 514);
            this.lblInform.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblInform.Name = "lblInform";
            this.lblInform.Size = new System.Drawing.Size(242, 15);
            this.lblInform.TabIndex = 52;
            this.lblInform.Text = "No ha seleccionado ningún producto";
            this.lblInform.Visible = false;
            // 
            // textBox1
            // 
            this.textBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold);
            this.textBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.textBox1.Location = new System.Drawing.Point(56, 172);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(557, 35);
            this.textBox1.TabIndex = 71;
            this.textBox1.Text = "Buscar...";
            this.textBox1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.textBox1_MouseClick);
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // chbContribuidor
            // 
            this.chbContribuidor.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.chbContribuidor.AutoSize = true;
            this.chbContribuidor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chbContribuidor.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.chbContribuidor.Location = new System.Drawing.Point(837, 442);
            this.chbContribuidor.Name = "chbContribuidor";
            this.chbContribuidor.Size = new System.Drawing.Size(164, 19);
            this.chbContribuidor.TabIndex = 72;
            this.chbContribuidor.Text = "Contribuidor Especial";
            this.chbContribuidor.UseVisualStyleBackColor = true;
            this.chbContribuidor.CheckedChanged += new System.EventHandler(this.chbContribuidor_CheckedChanged);
            // 
            // dtgvProductsInCar
            // 
            this.dtgvProductsInCar.AllowUserToOrderColumns = true;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvProductsInCar.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle11;
            this.dtgvProductsInCar.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dtgvProductsInCar.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.dtgvProductsInCar.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dtgvProductsInCar.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dtgvProductsInCar.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvProductsInCar.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.dtgvProductsInCar.ColumnHeadersHeight = 45;
            this.dtgvProductsInCar.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dtgvProductsInCar.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.ProductName,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6});
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvProductsInCar.DefaultCellStyle = dataGridViewCellStyle18;
            this.dtgvProductsInCar.EnableHeadersVisualStyles = false;
            this.dtgvProductsInCar.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.dtgvProductsInCar.Location = new System.Drawing.Point(56, 213);
            this.dtgvProductsInCar.Name = "dtgvProductsInCar";
            this.dtgvProductsInCar.ReadOnly = true;
            this.dtgvProductsInCar.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dtgvProductsInCar.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle19.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle19.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle19.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvProductsInCar.RowHeadersDefaultCellStyle = dataGridViewCellStyle19;
            this.dtgvProductsInCar.RowHeadersVisible = false;
            this.dtgvProductsInCar.RowHeadersWidth = 51;
            dataGridViewCellStyle20.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtgvProductsInCar.RowsDefaultCellStyle = dataGridViewCellStyle20;
            this.dtgvProductsInCar.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dtgvProductsInCar.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.dtgvProductsInCar.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Bold);
            this.dtgvProductsInCar.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.dtgvProductsInCar.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            this.dtgvProductsInCar.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.dtgvProductsInCar.RowTemplate.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvProductsInCar.RowTemplate.Height = 40;
            this.dtgvProductsInCar.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvProductsInCar.Size = new System.Drawing.Size(747, 298);
            this.dtgvProductsInCar.TabIndex = 74;
            this.dtgvProductsInCar.MouseEnter += new System.EventHandler(this.dtgvProductsInCar_MouseEnter);
            // 
            // dataGridViewTextBoxColumn1
            // 
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle13;
            this.dataGridViewTextBoxColumn1.HeaderText = "Código Producto";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 125;
            // 
            // ProductName
            // 
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.ProductName.DefaultCellStyle = dataGridViewCellStyle14;
            this.ProductName.HeaderText = "Nombre Producto";
            this.ProductName.MinimumWidth = 6;
            this.ProductName.Name = "ProductName";
            this.ProductName.ReadOnly = true;
            this.ProductName.Width = 125;
            // 
            // dataGridViewTextBoxColumn3
            // 
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.dataGridViewTextBoxColumn3.DefaultCellStyle = dataGridViewCellStyle15;
            this.dataGridViewTextBoxColumn3.HeaderText = "Precio ($) Producto";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 125;
            // 
            // dataGridViewTextBoxColumn4
            // 
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.dataGridViewTextBoxColumn4.DefaultCellStyle = dataGridViewCellStyle16;
            this.dataGridViewTextBoxColumn4.HeaderText = "Categoria Producto";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 125;
            // 
            // dataGridViewTextBoxColumn5
            // 
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.dataGridViewTextBoxColumn5.DefaultCellStyle = dataGridViewCellStyle17;
            this.dataGridViewTextBoxColumn5.HeaderText = "Descripcion Producto";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Width = 125;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.HeaderText = "Cantidad Producto";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            // 
            // pbSummaryFrame
            // 
            this.pbSummaryFrame.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pbSummaryFrame.BackColor = System.Drawing.Color.Transparent;
            this.pbSummaryFrame.Image = global::TuProductoOnline.Properties.Resources.Marco_de_Widgets;
            this.pbSummaryFrame.Location = new System.Drawing.Point(748, 18);
            this.pbSummaryFrame.Name = "pbSummaryFrame";
            this.pbSummaryFrame.Size = new System.Drawing.Size(259, 55);
            this.pbSummaryFrame.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSummaryFrame.TabIndex = 75;
            this.pbSummaryFrame.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox1.Image = global::TuProductoOnline.Properties.Resources.Icono_Nueva_Venta1;
            this.pictureBox1.Location = new System.Drawing.Point(760, 23);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(45, 45);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 76;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.pictureBox2.Image = global::TuProductoOnline.Properties.Resources.Lupa1;
            this.pictureBox2.Location = new System.Drawing.Point(579, 173);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(32, 32);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 80;
            this.pictureBox2.TabStop = false;
            // 
            // NewSaleMenu
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(234)))), ((int)(((byte)(199)))));
            this.ClientSize = new System.Drawing.Size(1030, 560);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.dtgvProductsInCar);
            this.Controls.Add(this.chbContribuidor);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lblInform);
            this.Controls.Add(this.txtTotalProducts);
            this.Controls.Add(this.lblTotalProducts);
            this.Controls.Add(this.lblTotalAmount);
            this.Controls.Add(this.txtTotalAmount);
            this.Controls.Add(this.btnDeleteProductInCar);
            this.Controls.Add(this.btnAddProductInCar);
            this.Controls.Add(this.btnBilling);
            this.Controls.Add(this.txtAdressClientSale);
            this.Controls.Add(this.lblAddress);
            this.Controls.Add(this.txtPhoneClientSale);
            this.Controls.Add(this.lblPhone);
            this.Controls.Add(this.txtNameClientSale);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.txtIdClientSale);
            this.Controls.Add(this.lblID);
            this.Controls.Add(this.btnAssignClient);
            this.Controls.Add(this.lblWelcome);
            this.Controls.Add(this.pbSummaryFrame);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "NewSaleMenu";
            this.Text = "NewSaleMenu";
            ((System.ComponentModel.ISupportInitialize)(this.dtgvProductsInCar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSummaryFrame)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.Button btnAssignClient;
        private System.Windows.Forms.Label lblID;
        private System.Windows.Forms.TextBox txtIdClientSale;
        private System.Windows.Forms.TextBox txtNameClientSale;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.TextBox txtPhoneClientSale;
        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.TextBox txtAdressClientSale;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.Button btnBilling;
        private System.Windows.Forms.Button btnAddProductInCar;
        private System.Windows.Forms.Button btnDeleteProductInCar;
        private System.Windows.Forms.TextBox txtTotalAmount;
        private System.Windows.Forms.Label lblTotalAmount;
        private System.Windows.Forms.Label lblTotalProducts;
        private System.Windows.Forms.TextBox txtTotalProducts;
        private System.Windows.Forms.Label lblInform;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.CheckBox chbContribuidor;
        private System.Windows.Forms.DataGridView dtgvProductsInCar;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductName;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.PictureBox pbSummaryFrame;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}