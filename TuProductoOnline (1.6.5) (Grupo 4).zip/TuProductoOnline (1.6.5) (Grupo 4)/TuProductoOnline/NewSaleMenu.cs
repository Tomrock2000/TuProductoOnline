﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TuProductoOnline
{
    public partial class NewSaleMenu : Form
    {
        //Instancia de objetos que serán asignados y enviados a otro form más adelante
        CarShop carshop = new CarShop();//Este será nuestro carrito de compras, tiene como atributos ProductsInCar(Lista de productos),CantitySale(Cantidad de productos totales) y TotalAmount(Costo total)
        Client client = new Client();//Este será el cliente seleccionado
        Employee employee = new Employee();//Este será el usuario activo
        bool contributor = false;
        public NewSaleMenu()
        {
            InitializeComponent();
            SaleLoad(carshop);
            CheckUser();
        }
        public void CheckUser()//Buscara a el usuario con la sesion activa y asignara sus datos a employee(el objeto Employee instanciado en el principio)
        {
            var usersfromfile = LoginMenu.GetUsersFromFile();
            var users = JsonConvert.DeserializeObject<List<Employee>>(usersfromfile);
            foreach(Employee employee2 in users)
            {
                if (employee2.ActiveSession == true)
                {
                    employee = employee2;
                }
            }
        }

        //Método para obtener el cliente, recibe los datos de el cliente que serán proporcionados en el form "SelectClient"
        //Además, pone cada uno de los datos en los campos correspondientes del menú
        public void SelectClient(string clientName,string clientLastname,string clientId,string clientAdress,string clientPhone )
        {
            txtNameClientSale.Text = clientName+" "+clientLastname;
            txtIdClientSale.Text = clientId;
            txtAdressClientSale.Text = clientAdress;
            txtPhoneClientSale.Text = clientPhone;
            client = new Client //Asigna los datos de el cliente seleccionado a el objeto Client instanciado en el principio del form
            {
                Name = clientName,
                LastName = clientLastname,
                Address = clientAdress,
                Id = long.Parse(clientId),
                Phone = long.Parse(clientPhone),
            };
        }

        private void btnAssignClient_Click(object sender, EventArgs e)//Abre el form para seleccionar el cliente
        {
            SelectClient selectclient = new SelectClient();//Instanciamos un form "SelectClient" donde seleccionaremos el cliente
            selectclient.ShowDialog();
        }

        private void btnAddProduct_Click(object sender, EventArgs e)//Abre el form para añadir productos
        {
            SelectProduct selectproduct = new SelectProduct();//Instancia un form "SelecProduct" que será donde seleccionemos los productos a añadir al carrito
            selectproduct.ShowDialog();
           
        }
        public void CarShopProducts(Product producttosale,int cantitysale)//Este método recibe un Product y un Int de el form de añadir productos, nos servirá para ir añadiendo los productos al carrito
            //productosale es el producto seleccionado para agregar al carrito y cantitysale es la cantidad seleccionada de ese producto
        {
            dtgvProductsInCar.Rows.Clear();//Limpia el dtfv
            producttosale.Cantity = cantitysale;//La cantidad de el producto será la seleccionada
            
            if (carshop.ProductsInCar == null)//En el caso de que no hayan productos en ProductsInCar(productos en el carro)
            {
                carshop.ProductsInCar = new List<Product>();//Crea una nueva lista de productos
                carshop.ProductsInCar.Add(producttosale);//Añade el producto a vender
            }
            else//En el caso de que ya hayan productos en la lista
            {
                foreach (Product product2 in carshop.ProductsInCar.ToList())
                    //Utilizamos ToList() para que nos permita modificar los productos de la lista, es decir carshop.ProductsInCar
                                                                            //Utilizado de esta forma, es como si estuviesemos usando una copia
                                                                            //Ya que si lo usamos sin el ToList(), nos saldrá una excepción
                {
                    if (product2.Id == producttosale.Id)//Verificamos si dentro de la lista, existe ya el producto
                    {
                        producttosale.Cantity += product2.Cantity;//En el caso de que sí, añadiremos la cantidad de el producto que ya existia dentro de el carrito a el producto a vender
                        carshop.ProductsInCar.Remove(product2);//Eliminamos el productos que ya estaba en la lista de el carrito
                        break;
                    }
                }
                    carshop.ProductsInCar.Add(producttosale);//Añadimos el producto a vender a la lista de productos de el carrito
            }
            
            SaleLoad(carshop);//Utilizamos la funcion SaleLoad que recibe como parámetro a carshop(nuestro carrito)
            
        }
        public void SaleLoad(CarShop car,string searchText = "")//Esta función actualizara los datos de el dtgv e informacion sobre los montos y productos
            //Recibe como parámetros un objeto CarShop
        {
            
            dtgvProductsInCar.Rows.Clear();//Limpia el dtgv
            if (car.ProductsInCar == null)//En el caso de que la lista de productos de el objeto recibido esté vacía
            {
                lblInform.Visible = true; ;//Se mostrará este mensaje en el lbl de total amount(Es un ejemplo, deberá ser cambiado donde se mostrará)
            }

            else//En el caso contrario, es decir, que no esté vacío
            {
                lblInform.Visible = false;

                int cantitytosale = 0;//Instancia las variables cantitytosale y
                                      //totalamount que nos ayudarán a obtener la cantidad
                                      //total de productos a vender
                
                float totalamount = 0;//Y el monto total de los productos 

                foreach (Product product in car.ProductsInCar)//Recorrerá todos los productos en la lista de el carrito y los mostrará en el dtgv
                {
                    dtgvProductsInCar.Rows.Add(product.Id, product.Name, product.Price, product.Type, product.Description, product.Cantity);//Añade un nuevo renglon a el dtgv
                    //Muestra el mensaje correcto
                    //dtgvProductsInCar.Rows[n].Cells[0].Value = product.Id;//Carga los datos correspondientes a cada celda
                    //dtgvProductsInCar.Rows[n].Cells[1].Value = product.Name;
                    //dtgvProductsInCar.Rows[n].Cells[2].Value = product.Price;
                    //dtgvProductsInCar.Rows[n].Cells[3].Value = product.Type;
                    //dtgvProductsInCar.Rows[n].Cells[4].Value = product.Description;
                    //dtgvProductsInCar.Rows[n].Cells[5].Value = product.Cantity;
                     totalamount+= (float)product.Cantity * product.Price;//A totalamount le sumamos el resultado de la multiplicación
                    //De la cantidad de el producto y el precio de el producto(Esto para cada producto, se ira sumando)
                     cantitytosale+= product.Cantity;//Este sumará la cantidad de los productos
                }

                if (searchText.Length > 2)
                {

                    car.ProductsInCar = car.ProductsInCar.Where(x => x.Name.Contains(searchText)).ToList();

                }

                car.TotalAmount = totalamount;//El atributo de el carrito TotalAmount será igual a totalamount, representa el costo total de los productos en la lista
                car.CantitySale = cantitytosale;//El atributo de el carrito CantitySale será igual a cantitytosale,representa la cantidad de los productos en la lista
                txtTotalAmount.Text = $"{carshop.TotalAmount}$";//Muestra el costo total en el txt correspondiente
                txtTotalProducts.Text = carshop.CantitySale.ToString();//Muestra la cantidad total en el txt correspondiente
            }
           
            carshop = car;
        }
        public bool ValidateCloseSession()//Esta funcion nos permite verificar si no hay ningun producto en el carrito para evitar que se pierdan los datos, Si está vacío, permitirá cerrar sesión
        {
            if (carshop.ProductsInCar == null ||carshop.ProductsInCar.Count==0) { return true; }
            else { return false; }
        }
        private void btnDeleteProductInCar_Click(object sender, EventArgs e)
        {
            if (carshop.ProductsInCar != null)
            {
                DeleteProductSelect deleteproductselect = new DeleteProductSelect(carshop);//Instancia un form "DeleteProductSelect" que recibirá el carrito de compras que usamos aqí
                                                                                           //Este form será donde eliminemos productos de la lista de el carrito de compras

                deleteproductselect.ShowDialog();
            }
            else
            {
                MessageBox.Show("No hay productos seleccionados");
                
            }
        }

        public void BillCheck()
        {
            //Verifica si la lista de los productos no está vacía, ademas de los txtbox, habilita el boton de facturar, si no, lo deshabilita
            if(carshop.ProductsInCar!=null && carshop.ProductsInCar.Count !=0 && txtIdClientSale.Text!=string.Empty && txtNameClientSale.Text!=string.Empty && txtAdressClientSale.Text!=string.Empty && txtPhoneClientSale.Text != string.Empty)
            {

                btnBilling.Enabled = true;
            }
            else
            {
                btnBilling.Enabled = false;
            }
        }
        
        private void btnBilling_Click(object sender, EventArgs e)
        {

            DialogResult result = MessageBox.Show("¿Está seguro de que desea facturar?", "Confirmación", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                Billing billing = new Billing(employee, client, carshop,contributor);//Instanciamos el form "Billing" que recibirá
                                                                         //los objetos Employee,Client, y CarShop que instanciamos en un principio
                                                                         //A los cuales les asignamos valores a lo largo de el form
                billing.ShowDialog();
                Clear();
                MainMenu main = new MainMenu();
                foreach (Form form in Application.OpenForms)
                {
                    if (form is MainMenu)
                    {
                        main = (MainMenu)form;
                        break;
                    }
                }
               
                main.Refresh();
            }
            
        }
        public void Clear()
        {
            //Limpia los txtbox y el carrito de compras
            txtNameClientSale.Text = string.Empty;
            txtIdClientSale.Text = string.Empty;
            txtAdressClientSale.Text = string.Empty;
            txtPhoneClientSale.Text = string.Empty;
            txtTotalAmount.Text = string.Empty;
            txtTotalProducts.Text = string.Empty;
            carshop.TotalAmount = 0;
            carshop.ProductsInCar = null;
            carshop.CantitySale = 0;
        }
        private void txtNameClientSale_TextChanged(object sender, EventArgs e)
        {
            BillCheck();
        }

        private void dtgvProductsInCar_MouseEnter(object sender, EventArgs e)
        {
            SaleLoad(carshop);//Recarga el dtgv
        }

        private void chbContribuidor_CheckedChanged(object sender, EventArgs e)
        {
            //Asigna el bool correspondiente dependiendo de el checkbox
            if (chbContribuidor.Checked)
            {
                contributor = true;
            }
            else
            {
                contributor = false;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            //Buscador
            string searchText = textBox1.Text.ToLower();

            int columnIndex = dtgvProductsInCar.Columns["ProductName"].Index;//Obtiene el índice correspondiente a la columna "ProductName"

            try
            {
                foreach (DataGridViewRow row in dtgvProductsInCar.Rows)//Por cada Row de el dtgv
                {

                    bool found = false;

                    DataGridViewCell cell = row.Cells[columnIndex];//DataGridViewCell cell será igual la celda en el indice "columnIndex" de el row que estamos evaluando


                    if (cell.Value != null && cell.Value.ToString().ToLower().Contains(searchText))//Si el valor de la celda no es vacio y si el valor de la celda contiene el valor de el string "searchtext" 
                    {
                        found = true;//Devuelve true
                    }
                    row.Visible = found;
                }
            }
            catch (Exception a)
            {

            }
        }

        private void textBox1_MouseClick(object sender, MouseEventArgs e)
        {
            textBox1.Text = "";
        }

         List<Product> OrdenarLista(string campo)
        {

            var productsfromfile = ProductManageMenu.GetProductsFromFile();
            var products = JsonConvert.DeserializeObject<List<Product>>(productsfromfile);


            switch (campo)
            {
                case "Nombre":
                    return products.OrderBy(p => p.Name).ToList();
                case "Cedula":
                    return products.OrderBy(p => p.Id).ToList();
                default:
                    return products;
            }
        }

    }
}
