﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TuProductoOnline
{
    public class Person
    {
        private string _name;
        private string _lastname;
        private long _id;
        private long _phone;
        private string _address;
        private bool _enabled=true;

        public string Name { get { return _name; } set { _name = value; } }
        public string LastName { get { return _lastname; } set { _lastname = value; } }
        public long Id { get { return _id; } set { _id = value; } }
        public long Phone { get { return _phone; } set { _phone = value; } }
        public string Address { get { return _address; } set { _address = value; } }
        public bool Enabled { get { return _enabled; } set { _enabled = value; } }
    }
    public class SuperUser
    {
        private string _user = "Dovahkiin";
        private long _password = 1029384756;

        public string User { get { return _user; } set { _user = value; } }
        public long Password { get { return _password; } set { _password = value; } }
    }
    public class Admin:Person
    {
        private string _user;
        private long _password;
        private bool _activesession = false;

        public string User { get { return _user; } set { _user = value; } }
        public long Password { get { return _password; } set { _password = value; } }
        public bool ActiveSession { get { return _activesession; } set { _activesession = value; } }
    }
    public class Employee : Person
    {
        private string _user;
        private bool _activesession = false;
        private long _password;
        private int _concludedsales=0;
        private float _billedamount=0;
        private int _addedclients=0;
        private Client _lastaddedclient;
        
        private static string _pathusers = Path.GetFullPath(Path.Combine(Application.StartupPath, "..\\..", "Users.json"));
        public string User{ get { return _user; } set { _user = value; } }
        public bool ActiveSession { get { return _activesession; } set { _activesession=value; } }
        public long Password { get { return _password; } set { _password = value; } }
        public int ConcludedSales { get { return _concludedsales; } set { _concludedsales = value; } }
        public float BilledAmount { get { return _billedamount;} set{_billedamount=value;} }
        public int AddedClients { get { return _addedclients; } set { _addedclients = value; } }
        public Client LastAddedClient { get { return _lastaddedclient; } set { _lastaddedclient = value; } }
        public string GetUsersFromFile()
        {

            string usersJsonFromFile;
            using (var reader = new StreamReader(_pathusers))
            {
                usersJsonFromFile = reader.ReadToEnd();
            }
            return usersJsonFromFile;

        }
    }
    public class Client : Person
    {
        private static string _pathclients = Path.GetFullPath(Path.Combine(Application.StartupPath, "..\\..", "Clients.json"));
        public string GetClientsFromFile()
        {

            string clientsJsonFromFile;
            using (var reader = new StreamReader(_pathclients))
            {
                clientsJsonFromFile = reader.ReadToEnd();
            }
            return clientsJsonFromFile;
       
        }
    }
}
