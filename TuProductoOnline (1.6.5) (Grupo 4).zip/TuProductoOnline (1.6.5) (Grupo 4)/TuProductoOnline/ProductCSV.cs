﻿using CsvHelper.Configuration.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TuProductoOnline
{
    internal class ProductCSV          
    {
        //Esta clase ayuda al momento de exportar ya que le indica al programa como 
        //escribir el CSV de salida.
        //Cado uno hace referecia a la estrutura de nuestra clase Product y no hay problema con las anidaciones
        [Name("ID")]
        public string Id { get; set; }

        [Name("Nombre")]
        public string Name { get; set; }

        [Name("Descripción")]
        public string Description { get; set; }

        [Name("Precio")]
        public float Price { get; set; }

        [Name("Hardware")]
        public bool IsHardware { get; set; }

        [Name("Medidas")]
        public string Meassures { get; set; }

        [Name("Software")]
        public bool IsSoftware { get; set; }

        [Name("Licencia")]
        public string Licence { get; set; }

        [Name("Versión")]
        public string Version { get; set; }

        [Name("Dispositivo")]
        public bool IsDevice { get; set; }

        [Name("Modelo")]
        public string Model { get; set; }

        [Name("Cantidad")]
        public int Cantity { get; set; }

        [Name("Tipo")]
        public string Type { get; set; }

        [Name("Habilitado")]
        public bool Enabled { get; set; }

        [Name("Eliminado")]
        public bool Removed { get; set; }

    }
}
