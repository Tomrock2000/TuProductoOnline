﻿
using Newtonsoft.Json.Bson;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TuProductoOnline
{
    
    public class Product
    {
        private string _id;
        private string _name;
        private string _description;
        private float _price;
        private Hardware _hard;
        private Software _soft;
        private Device _devi;
        private int _cantity;
        private string _type;
        private bool _enabled=true;
        private bool _removed = false;

        public static string _pathproducts = Path.GetFullPath(Path.Combine(Application.StartupPath, "..\\..", "Products.json"));

        public  string Id { get { return _id; } set { _id = value; } }
        public  string Name { get { return _name; } set { _name = value; } }
        public string Description { get { return _description; } set { _description = value; } }
        public float Price { get { return _price; } set { _price = value; } }
        public Hardware Hard { get { return _hard; } set { _hard = value; } }
        public Software Soft { get { return _soft; } set { _soft = value; } }
        public Device Devi { get { return _devi; } set { _devi = value; } }
        public int Cantity { get { return _cantity; } set { _cantity = value; } }
        public string Type { get { return _type; } set { _type = value; } }
        public bool Enabled { get { return _enabled; } set { _enabled = value; } }
        public bool Removed { get { return _removed; } set { _removed = value; } }

       
        public string GetProductsFromFile()//Este metodo lee el json y lo guarda en una variable
        {
            string productsJsonfromFile;//Declara la variable en la que se guardará el json
            using (var reader = new StreamReader(_pathproducts))//Mediante el lector, se leerá todo el json y lo guardará en la variable
            {
                productsJsonfromFile = reader.ReadToEnd();
            }
            return productsJsonfromFile;//Devuelve el valor de la variable, que sería la lectura del json
        }

    }

        public class Hardware
        {
            private bool _isHardware = false;
            private string _meassures=null;


            public bool IsHarware { get { return _isHardware; } set { _isHardware = value; } }
            public string Meassures { get { return _meassures; } set { _meassures = value; } }
        }
        public class Software
        {
            private bool _isSoftware = false;
            private string _licence;
            private string _version;
           
            public bool IsSoftware { get { return _isSoftware; } set { _isSoftware = value; } }
            public string Licence { get { return _licence; } set{ _licence = value; }  }
            public string Version { get { return _version; } set { _version = value; } }
        }
        public class Device
        {
            private bool _isDevice = false;
            private string _model;
            public bool IsDevice { get { return _isDevice; } set { _isDevice = value; } }
            public string Model { get { return _model; } set { _model = value; } }
        }
    
}

