﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CsvHelper;
using CsvHelper.Configuration;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Globalization;


namespace TuProductoOnline
{
    public partial class ProductManageMenu : Form
    {
        int pagecount = 0;
        int productsshowed = 0;
        public ProductManageMenu()
        {
            InitializeComponent();
            cumtomizeMenuDesigner();
            this.Click += new EventHandler(MainForm_Click);
            ProductLoad();

        }

        //Mapeo para importar, funciona para asigarnale a los datos ingresados una posicion especifica
        //por lo que el csv importado tiene un formato especifico en su encabezado, en nuetsro caso la primera columna 
        //tendra el nombre de ID una propiedad mencionada en la clase producto
        public sealed class ProductMap : ClassMap<Product>
        {
            public ProductMap()
            {

                Map(p => p.Id).Index(0);
                Map(p => p.Name).Index(1);
                Map(p => p.Description).Index(2);
                Map(p => p.Price).Index(3);
                Map(p => p.Hard.IsHarware).Index(4);
                Map(p => p.Hard.Meassures).Index(5);
                Map(p => p.Soft.IsSoftware).Index(6);
                Map(p => p.Soft.Licence).Index(7);
                Map(p => p.Soft.Version).Index(8);
                Map(p => p.Devi.IsDevice).Index(9);
                Map(p => p.Devi.Model).Index(10);
                Map(p => p.Cantity).Index(11);
                Map(p => p.Type).Index(12);
                Map(p => p.Enabled).Index(13);
                Map(p => p.Removed).Index(14);
            }
        }

        private void btnAddProduct_Click(object sender, EventArgs e)
        {
            AddProduct addproduct = new AddProduct();
            addproduct.ShowDialog();
        }
        private static string _pathproduct = Path.GetFullPath(Path.Combine(Application.StartupPath, "..\\..", "Products.json"));

        //Metodo para leer
        public static string GetProductsFromFile()
        {
            string productsJsonFromFile;
            using (var reader = new StreamReader(_pathproduct))
            {
                productsJsonFromFile = reader.ReadToEnd();
            }
            return productsJsonFromFile;
        }

        public void ProductLoad(string searchText = "")
        {
            dtgvProducts.Rows.Clear();
            var productsFromFile = GetProductsFromFile();
            var products = JsonConvert.DeserializeObject<List<Product>>(productsFromFile);
            IEnumerable<Product> productslist = products.Where(product => product.Enabled == true).Skip(pagecount * 20).Take(20);

            productsshowed = (pagecount * 20) + 20;

            if (products != null)
            {
                foreach (Product product in productslist)
                {
                    if (product.Cantity == 0)
                    {
                        product.Enabled = false;
                    }

                    if (product.Enabled == true && product.Removed == false)
                    {
                        dtgvProducts.Rows.Add(product.Id, product.Name, product.Price, product.Type, product.Description, product.Cantity);

                    }
                }
            }
            if (searchText.Length > 2)
            {
                products = products.Where(x => x.Name.Contains(searchText)).ToList();
            }
        }
        private void dtgvProducts_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            if (e.ColumnIndex >= 0 && this.dtgvProducts.Columns[e.ColumnIndex].Name == "DeleteProduct" && e.RowIndex >= 0)
            {
                e.Paint(e.CellBounds, DataGridViewPaintParts.All);

                var celula = this.dtgvProducts.Rows[e.RowIndex].Cells[e.ColumnIndex];
                var imagen = Properties.Resources.Eliminar; 

                var x = e.CellBounds.Left + (e.CellBounds.Width - imagen.Width) / 2;
                var y = e.CellBounds.Top + (e.CellBounds.Height - imagen.Height) / 2;

                e.Graphics.DrawImage(imagen, new Point(x, y));
                e.Handled = true;
            }
            if (e.ColumnIndex >= 0 && this.dtgvProducts.Columns[e.ColumnIndex].Name == "ModifyProduct" && e.RowIndex >= 0)
            {
                e.Paint(e.CellBounds, DataGridViewPaintParts.All);

                var celula = this.dtgvProducts.Rows[e.RowIndex].Cells[e.ColumnIndex];
                var imagen = Properties.Resources.Modificar; 

                var x = e.CellBounds.Left + (e.CellBounds.Width - imagen.Width) / 2;
                var y = e.CellBounds.Top + (e.CellBounds.Height - imagen.Height) / 2;

                e.Graphics.DrawImage(imagen, new Point(x, y));
                e.Handled = true;
            }
        }

        //Buscador
        private void txtBrowser_TextChanged(object sender, EventArgs e)
        {
            string searchText = txtBrowser.Text.ToLower();

            int columnIndex = dtgvProducts.Columns["ProductName"].Index;

            try
            {

                ProductLoad(searchText);

                if (searchText.Length < 2)
                {
                    return;
                }

                foreach (DataGridViewRow row in dtgvProducts.Rows)
                {

                    bool found = false;

                    DataGridViewCell cell = row.Cells[columnIndex];



                    if (cell.Value != null && cell.Value.ToString().ToLower().Contains(searchText))
                    {
                        found = true;
                    }
                    row.Visible = found;
                }
            }
            catch (Exception a)
            {

            }
        }

        private void dtgvProducts_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            var productsfromfile = ProductManageMenu.GetProductsFromFile();
            var products = JsonConvert.DeserializeObject<List<Product>>(productsfromfile);
            if (e.ColumnIndex == 6)
            {
                Product tomodify = new Product();
                string idtocompare = dtgvProducts.Rows[e.RowIndex].Cells[0].Value.ToString();

                foreach (Product product1 in products)
                {
                    if (idtocompare == product1.Id)
                    {
                        tomodify = product1;
                        break;
                    }
                }
                ModifyProduct modifyproduct = new ModifyProduct(tomodify);
                modifyproduct.ShowDialog();
            }
            if (e.ColumnIndex == 7)
            {
                string productname = dtgvProducts.Rows[e.RowIndex].Cells[1].Value.ToString();
                DialogResult result1 = MessageBox.Show($"¿Esta seguro que desea eliminar {productname}?", "Confirmación", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result1 == DialogResult.Yes)
                {
                    int n = e.RowIndex;

                    string todelete;

                    todelete = (string)dtgvProducts.Rows[n].Cells[0].Value;


                    foreach (Product product in products)
                    {
                        if (todelete == product.Id.ToString())
                        {
                            product.Removed = true;
                            product.Enabled = false;
                            break;
                        }
                    }

                    string productsJson = JsonConvert.SerializeObject(products.ToArray(), Formatting.Indented);
                    File.WriteAllText(_pathproduct, productsJson);
                    MessageBox.Show("El producto ha sido eliminado exitosamente");
                    ProductLoad();
                }
            }
        }

        private void btnPrevPage_Click(object sender, EventArgs e)
        {
            if (pagecount > 0)
            {
                pagecount--;
                ProductLoad();
            }

        }

        private void btnNextPage_Click(object sender, EventArgs e)
        {
            var productsfromfile = ProductManageMenu.GetProductsFromFile();
            var products = JsonConvert.DeserializeObject<List<Product>>(productsfromfile);
            if (productsshowed < products.Count)
            {
                pagecount++;
                ProductLoad();
            }
        }

        private void cumtomizeMenuDesigner()    // es un poco inecesario esta parte porque desde los 
        {                                       //Componentes del control se puede especificar pero es mejor
            pnlSudMenu.Visible = false;         //Hacerlo asi por si queremos modificar especificamente la interfaz
        }

        private void hideSudmenu()
        {
            if (pnlSudMenu.Visible == true)
            {
                pnlSudMenu.Visible = false;
            }
        }

        private void showSudMenu(Panel sudmenu)
        {
            if (sudmenu.Visible == false)
            {
                hideSudmenu();
                sudmenu.Visible = true;
            }
            else
            {
                sudmenu.Visible = false;
            }
        }

        private void btnExportImport_Click(object sender, EventArgs e)
        {
            showSudMenu(pnlSudMenu);
        }

        private void MainForm_Click(object sender, EventArgs e)            //es un pequeño codigo para hacer que se oculte el sud menu si se toca el fondo 
        {
            if (pnlSudMenu.Visible == true && !pnlSudMenu.ClientRectangle.Contains(PointToClient(Cursor.Position)))
            {
                hideSudmenu();
            }
        }
        //fin del sud menu
        private void btnImport_Click(object sender, EventArgs e)
        {
            //Pedir al usuario donde quiere importar el archivo csv 
            var openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "CSV files (*.csv)|*.csv";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                //Modificar las caracteristicas del csvhelper para que no produzca un error
                var config = new CsvConfiguration(CultureInfo.InvariantCulture)
                {
                    Delimiter = ";",                //La separacion
                    NewLine = Environment.NewLine,  //que realice saltos de linea
                    HeaderValidated = null,         //que ignore el encabezado ya que tenemos una clase que mapea (Mas arriba esta)
                    MissingFieldFound = null        //ignore los espacios vacios
                };
                List<Product> records;
                //leer el csv para meterlo en una lista
                using (var reader = new StreamReader(openFileDialog.FileName))
                using (var csv = new CsvReader(reader, config))
                {

                    csv.Context.RegisterClassMap<ProductMap>();
                    records = csv.GetRecords<Product>().ToList();
                }
                //Evita que salga un error al momento de importar por el motivo de las anidaciones 
                //por eso al momento de importar lo importado tiene una diferente forma
                foreach (var record in records)
                {
                    if (record.Hard == null)
                    {
                        record.Hard = new Hardware();
                    }
                    if (record.Soft == null)
                    {
                        record.Soft = new Software();
                    }
                    if (record.Devi == null)
                    {
                        record.Devi = new Device();
                    }
                }
                //se crea una lista para el json
                List<Product> products;
                if (!File.Exists(_pathproduct))
                {
                    File.Create(_pathproduct).Close();
                }
                using (var jsonReader = new JsonTextReader(new StringReader(File.ReadAllText(_pathproduct))))
                {
                    var serializer = new JsonSerializer();
                    products = serializer.Deserialize<List<Product>>(jsonReader);
                }

                // Agrega los registros recién importados de CSV a la lista
                products.AddRange(records);

                // Serializa la lista de nuevo en formato JSON y escribirla en el archivo
                string json = JsonConvert.SerializeObject(products);
                File.WriteAllText(_pathproduct, json);

                MessageBox.Show("Importacion completada con éxito.");

                //Metodo para la asignacion de las ID para que no se repitan
                using (var jsonReader1 = new JsonTextReader(new StringReader(File.ReadAllText(_pathproduct))))
                {
                    var serializer = new JsonSerializer();
                    var productList = serializer.Deserialize<List<Product>>(jsonReader1);
                    var originalProductList = new List<Product>(productList); // Hace una copia de la lista original

                    int countH = 1;
                    int countS = 1;
                    int countD = 1;
                    foreach (Product product in productList)
                    {

                        if (product.Type == "Hardware")
                        {
                            product.Id = "H" + countH.ToString("D4");
                            countH++;
                        }
                        if (product.Type == "Software")
                        {
                            product.Id = "S" + countS.ToString("D4");
                            countS++;
                        }
                        if (product.Type == "Device")
                        {
                            product.Id = "D" + countD.ToString("D4");
                            countD++;
                        }
                    }
                    using (var jsonWriter = new JsonTextWriter(new StreamWriter(_pathproduct)))
                    {
                        serializer.Serialize(jsonWriter, originalProductList); // Escribe la lista original en el archivo original porque estaba invertida
                    }
                }
            }
            hideSudmenu();
            ProductLoad();
        }//fin boton de Importar

        private void btnExport_Click(object sender, EventArgs e)
        {
            //// Abre un diálogo de archivo para que el usuario seleccione la ubicación del archivo CSV de salida
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Archivos CSV (*.csv)|*.csv";
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                // Lee el archivo JSON existente y convierte los datos a una lista de Productos
                var json = GetProductsFromFile();
                List<Product> products = JsonConvert.DeserializeObject<List<Product>>(json);

                // Convierte la lista de Productos a una lista de ProductCsv
                List<ProductCSV> productsCsv = new List<ProductCSV>();

                foreach (var product in products)
                {
                    if (product.Hard != null && product.Hard.IsHarware == true)
                    {
                        ProductCSV productCsv = new ProductCSV
                        {
                            Id = product.Id,
                            Name = product.Name,
                            Description = product.Description,
                            Price = product.Price,
                            Meassures = product.Hard.Meassures,
                            IsHardware = product.Hard.IsHarware,
                            IsSoftware = false,
                            Licence = string.Empty,
                            Version = string.Empty,
                            IsDevice = false,
                            Model = string.Empty,
                            Cantity = product.Cantity,
                            Type = product.Type,
                            Enabled = product.Enabled,
                            Removed = product.Removed,
                        };
                        productsCsv.Add(productCsv);
                    }
                    if (product.Soft != null && product.Soft.IsSoftware == true)
                    {
                        ProductCSV productCsv = new ProductCSV
                        {

                            Id = product.Id,
                            Name = product.Name,
                            Description = product.Description,
                            Price = product.Price,
                            IsHardware = false,
                            Meassures = string.Empty,
                            IsSoftware = product.Soft.IsSoftware,
                            Licence = product.Soft.Licence,
                            Version = product.Soft.Version,
                            IsDevice = false,
                            Model = string.Empty,
                            Cantity = product.Cantity,
                            Type = product.Type,
                            Enabled = product.Enabled,
                            Removed = product.Removed,
                        };
                        productsCsv.Add(productCsv);
                    }
                    if (product.Devi != null && product.Devi.IsDevice == true)
                    {
                        ProductCSV productCsv = new ProductCSV
                        {
                            Id = product.Id,
                            Name = product.Name,
                            Description = product.Description,
                            Price = product.Price,
                            IsHardware = false,
                            Meassures = string.Empty,
                            IsSoftware = false,
                            Licence = string.Empty,
                            Version = string.Empty,
                            IsDevice = product.Devi.IsDevice,
                            Model = product.Devi.Model,
                            Cantity = product.Cantity,
                            Type = product.Type,
                            Enabled = product.Enabled,
                            Removed = product.Removed,
                        };
                        productsCsv.Add(productCsv);
                    }


                }



                // Escribe los objetos ProductCsv en el archivo CSV de salida
                using (StreamWriter writer = new StreamWriter(saveFileDialog.FileName, true)) //modifique
                using (CsvWriter csv = new CsvWriter(writer, System.Globalization.CultureInfo.CurrentCulture))
                {
                    // Escribe los encabezados de columna en el archivo CSV
                    csv.WriteHeader<ProductCSV>();
                    csv.NextRecord();

                    // Escribe los datos de los productos en el archivo CSV
                    foreach (var productCsv in productsCsv)
                    {
                        csv.WriteRecord<ProductCSV>(productCsv);
                        csv.NextRecord();
                    }
                }

                MessageBox.Show("Se ha Exportado Correctamente");


            }
            hideSudmenu();
            ProductLoad();

        }//fin del boton Exportar

        private void txtBrowser_MouseClick(object sender, MouseEventArgs e)
        {
            txtBrowser.Text = "";
        }

        List<Product> OrdenarLista(string campo)
        {

            var productsfromfile = GetProductsFromFile();
            var products = JsonConvert.DeserializeObject<List<Product>>(productsfromfile);


            switch (campo)
            {
                case "Nombre":
                    return products.OrderBy(p => p.Name).ToList();
                case "Cedula":
                    return products.OrderBy(p => p.Id).ToList();
                default:
                    return products;
            }
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtgvProducts.Rows.Clear();

            string campo = comboBox1.SelectedItem.ToString();

            List<Product> orderedroducts = OrdenarLista(campo);

            if (orderedroducts != null)
            {
                foreach (Product product in orderedroducts)
                {
                    if (product.Enabled == true && product.Removed == false)
                    {
                        dtgvProducts.Rows.Add(product.Id, product.Name, product.Price, product.Type, product.Description, product.Cantity);

                    }
                }


            }
        }
    }
}


