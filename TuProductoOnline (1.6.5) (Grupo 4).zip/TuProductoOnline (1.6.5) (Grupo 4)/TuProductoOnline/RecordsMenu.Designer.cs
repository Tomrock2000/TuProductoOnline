﻿namespace TuProductoOnline
{
    partial class RecordsMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.cbCategory = new System.Windows.Forms.ComboBox();
            this.btnOpenPDF = new System.Windows.Forms.Button();
            this.dtgvProducts = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductStatus = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.RemovedProducts = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dtgvClients = new System.Windows.Forms.DataGridView();
            this.ClientName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Lastname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Phone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Adress = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ClientStatus = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dtgvUsers = new System.Windows.Forms.DataGridView();
            this.UsersName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LastnameUsers = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IdUsers = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PhoneUsers = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AdressUsers = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UsersNameCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PassowordUsers = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UsersConcluyedSales = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UsersBilledaccount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UsersAddedClients = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UserStatus = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.pbTitleFrame = new System.Windows.Forms.PictureBox();
            this.BillTotalAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SurnameClientSale = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ClientSell = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UsersSurnameSell = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UsersNameSell = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BillId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dtgvBills = new System.Windows.Forms.DataGridView();
            this.pbIconFrame = new System.Windows.Forms.PictureBox();
            this.pbMenuIcon = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvProducts)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvClients)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvUsers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbTitleFrame)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvBills)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbIconFrame)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMenuIcon)).BeginInit();
            this.SuspendLayout();
            // 
            // lblWelcome
            // 
            this.lblWelcome.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.BackColor = System.Drawing.Color.Transparent;
            this.lblWelcome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblWelcome.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold);
            this.lblWelcome.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblWelcome.Location = new System.Drawing.Point(375, 24);
            this.lblWelcome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(233, 29);
            this.lblWelcome.TabIndex = 46;
            this.lblWelcome.Text = "Menú de Registros";
            this.lblWelcome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbCategory
            // 
            this.cbCategory.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cbCategory.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.cbCategory.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbCategory.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.cbCategory.FormattingEnabled = true;
            this.cbCategory.Items.AddRange(new object[] {
            "Productos",
            "Clientes",
            "Facturas",
            "Usuarios"});
            this.cbCategory.Location = new System.Drawing.Point(392, 93);
            this.cbCategory.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbCategory.Name = "cbCategory";
            this.cbCategory.Size = new System.Drawing.Size(205, 28);
            this.cbCategory.TabIndex = 1;
            this.cbCategory.Text = "Categoría";
            this.cbCategory.SelectedIndexChanged += new System.EventHandler(this.cbCategory_SelectedIndexChanged);
            // 
            // btnOpenPDF
            // 
            this.btnOpenPDF.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnOpenPDF.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.btnOpenPDF.Enabled = false;
            this.btnOpenPDF.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOpenPDF.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.btnOpenPDF.Location = new System.Drawing.Point(409, 485);
            this.btnOpenPDF.Name = "btnOpenPDF";
            this.btnOpenPDF.Size = new System.Drawing.Size(180, 34);
            this.btnOpenPDF.TabIndex = 47;
            this.btnOpenPDF.Text = "Ver Factura";
            this.btnOpenPDF.UseVisualStyleBackColor = false;
            this.btnOpenPDF.Visible = false;
            this.btnOpenPDF.Click += new System.EventHandler(this.btnOpenPDF_Click);
            // 
            // dtgvProducts
            // 
            this.dtgvProducts.AllowUserToAddRows = false;
            this.dtgvProducts.AllowUserToOrderColumns = true;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvProducts.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dtgvProducts.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dtgvProducts.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.dtgvProducts.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dtgvProducts.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dtgvProducts.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvProducts.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dtgvProducts.ColumnHeadersHeight = 45;
            this.dtgvProducts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dtgvProducts.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.ProductStatus,
            this.RemovedProducts});
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvProducts.DefaultCellStyle = dataGridViewCellStyle8;
            this.dtgvProducts.EnableHeadersVisualStyles = false;
            this.dtgvProducts.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.dtgvProducts.Location = new System.Drawing.Point(128, 143);
            this.dtgvProducts.Name = "dtgvProducts";
            this.dtgvProducts.ReadOnly = true;
            this.dtgvProducts.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dtgvProducts.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvProducts.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.dtgvProducts.RowHeadersVisible = false;
            this.dtgvProducts.RowHeadersWidth = 51;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.dtgvProducts.RowsDefaultCellStyle = dataGridViewCellStyle10;
            this.dtgvProducts.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dtgvProducts.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.dtgvProducts.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Bold);
            this.dtgvProducts.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.dtgvProducts.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            this.dtgvProducts.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.dtgvProducts.RowTemplate.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvProducts.RowTemplate.Height = 40;
            this.dtgvProducts.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvProducts.Size = new System.Drawing.Size(747, 312);
            this.dtgvProducts.TabIndex = 73;
            this.dtgvProducts.Visible = false;
            this.dtgvProducts.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgvProducts_CellContentClick_1);
            // 
            // dataGridViewTextBoxColumn1
            // 
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewTextBoxColumn1.HeaderText = "Código Producto";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 125;
            // 
            // dataGridViewTextBoxColumn2
            // 
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.dataGridViewTextBoxColumn2.DefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridViewTextBoxColumn2.HeaderText = "Nombre Producto";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 125;
            // 
            // dataGridViewTextBoxColumn3
            // 
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.dataGridViewTextBoxColumn3.DefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridViewTextBoxColumn3.HeaderText = "Precio ($) Producto";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 125;
            // 
            // dataGridViewTextBoxColumn4
            // 
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.dataGridViewTextBoxColumn4.DefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridViewTextBoxColumn4.HeaderText = "Categoria Producto";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 125;
            // 
            // dataGridViewTextBoxColumn5
            // 
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.dataGridViewTextBoxColumn5.DefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridViewTextBoxColumn5.HeaderText = "Descripcion Producto";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Width = 125;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.HeaderText = "Cantidad Producto";
            this.dataGridViewTextBoxColumn6.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Width = 125;
            // 
            // ProductStatus
            // 
            this.ProductStatus.HeaderText = "Activo";
            this.ProductStatus.MinimumWidth = 6;
            this.ProductStatus.Name = "ProductStatus";
            this.ProductStatus.ReadOnly = true;
            this.ProductStatus.Width = 125;
            // 
            // RemovedProducts
            // 
            this.RemovedProducts.HeaderText = "Removido";
            this.RemovedProducts.MinimumWidth = 6;
            this.RemovedProducts.Name = "RemovedProducts";
            this.RemovedProducts.ReadOnly = true;
            this.RemovedProducts.Width = 125;
            // 
            // dtgvClients
            // 
            this.dtgvClients.AllowUserToAddRows = false;
            this.dtgvClients.AllowUserToOrderColumns = true;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvClients.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle11;
            this.dtgvClients.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dtgvClients.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.dtgvClients.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dtgvClients.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dtgvClients.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvClients.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.dtgvClients.ColumnHeadersHeight = 38;
            this.dtgvClients.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ClientName,
            this.Lastname,
            this.Id,
            this.Phone,
            this.Adress,
            this.ClientStatus});
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvClients.DefaultCellStyle = dataGridViewCellStyle13;
            this.dtgvClients.EnableHeadersVisualStyles = false;
            this.dtgvClients.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.dtgvClients.Location = new System.Drawing.Point(128, 143);
            this.dtgvClients.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dtgvClients.Name = "dtgvClients";
            this.dtgvClients.ReadOnly = true;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvClients.RowHeadersDefaultCellStyle = dataGridViewCellStyle14;
            this.dtgvClients.RowHeadersVisible = false;
            this.dtgvClients.RowHeadersWidth = 51;
            this.dtgvClients.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dtgvClients.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.dtgvClients.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Bold);
            this.dtgvClients.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.dtgvClients.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            this.dtgvClients.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.dtgvClients.RowTemplate.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvClients.RowTemplate.Height = 35;
            this.dtgvClients.Size = new System.Drawing.Size(747, 312);
            this.dtgvClients.TabIndex = 74;
            this.dtgvClients.Visible = false;
            this.dtgvClients.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgvClients_CellContentClick);
            // 
            // ClientName
            // 
            this.ClientName.HeaderText = "Nombre Cliente";
            this.ClientName.MinimumWidth = 6;
            this.ClientName.Name = "ClientName";
            this.ClientName.ReadOnly = true;
            this.ClientName.Width = 125;
            // 
            // Lastname
            // 
            this.Lastname.HeaderText = "Apellido Cliente";
            this.Lastname.MinimumWidth = 6;
            this.Lastname.Name = "Lastname";
            this.Lastname.ReadOnly = true;
            this.Lastname.Width = 125;
            // 
            // Id
            // 
            this.Id.HeaderText = "Cédula Cliente";
            this.Id.MinimumWidth = 6;
            this.Id.Name = "Id";
            this.Id.ReadOnly = true;
            this.Id.Width = 125;
            // 
            // Phone
            // 
            this.Phone.HeaderText = "Teléfono Cliente";
            this.Phone.MinimumWidth = 6;
            this.Phone.Name = "Phone";
            this.Phone.ReadOnly = true;
            this.Phone.Width = 125;
            // 
            // Adress
            // 
            this.Adress.HeaderText = "Dirección Cliente";
            this.Adress.MinimumWidth = 6;
            this.Adress.Name = "Adress";
            this.Adress.ReadOnly = true;
            this.Adress.Width = 125;
            // 
            // ClientStatus
            // 
            this.ClientStatus.HeaderText = "Activo";
            this.ClientStatus.MinimumWidth = 6;
            this.ClientStatus.Name = "ClientStatus";
            this.ClientStatus.ReadOnly = true;
            this.ClientStatus.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.ClientStatus.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.ClientStatus.Width = 125;
            // 
            // dtgvUsers
            // 
            this.dtgvUsers.AllowUserToAddRows = false;
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvUsers.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle15;
            this.dtgvUsers.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dtgvUsers.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.dtgvUsers.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dtgvUsers.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dtgvUsers.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvUsers.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle16;
            this.dtgvUsers.ColumnHeadersHeight = 38;
            this.dtgvUsers.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.UsersName,
            this.LastnameUsers,
            this.IdUsers,
            this.PhoneUsers,
            this.AdressUsers,
            this.UsersNameCode,
            this.PassowordUsers,
            this.UsersConcluyedSales,
            this.UsersBilledaccount,
            this.UsersAddedClients,
            this.UserStatus});
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dtgvUsers.DefaultCellStyle = dataGridViewCellStyle17;
            this.dtgvUsers.EnableHeadersVisualStyles = false;
            this.dtgvUsers.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.dtgvUsers.Location = new System.Drawing.Point(128, 143);
            this.dtgvUsers.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dtgvUsers.Name = "dtgvUsers";
            this.dtgvUsers.ReadOnly = true;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvUsers.RowHeadersDefaultCellStyle = dataGridViewCellStyle18;
            this.dtgvUsers.RowHeadersVisible = false;
            this.dtgvUsers.RowHeadersWidth = 51;
            this.dtgvUsers.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dtgvUsers.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.dtgvUsers.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtgvUsers.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.dtgvUsers.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            this.dtgvUsers.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.dtgvUsers.RowTemplate.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvUsers.RowTemplate.Height = 35;
            this.dtgvUsers.Size = new System.Drawing.Size(747, 312);
            this.dtgvUsers.TabIndex = 84;
            this.dtgvUsers.Visible = false;
            this.dtgvUsers.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgvUsers_CellContentClick);
            // 
            // UsersName
            // 
            this.UsersName.HeaderText = "Nombre ";
            this.UsersName.MinimumWidth = 6;
            this.UsersName.Name = "UsersName";
            this.UsersName.ReadOnly = true;
            this.UsersName.Width = 125;
            // 
            // LastnameUsers
            // 
            this.LastnameUsers.HeaderText = "Apellido ";
            this.LastnameUsers.MinimumWidth = 6;
            this.LastnameUsers.Name = "LastnameUsers";
            this.LastnameUsers.ReadOnly = true;
            this.LastnameUsers.Width = 125;
            // 
            // IdUsers
            // 
            this.IdUsers.HeaderText = "Cédula ";
            this.IdUsers.MinimumWidth = 6;
            this.IdUsers.Name = "IdUsers";
            this.IdUsers.ReadOnly = true;
            this.IdUsers.Width = 125;
            // 
            // PhoneUsers
            // 
            this.PhoneUsers.HeaderText = "Teléfono";
            this.PhoneUsers.MinimumWidth = 6;
            this.PhoneUsers.Name = "PhoneUsers";
            this.PhoneUsers.ReadOnly = true;
            this.PhoneUsers.Width = 125;
            // 
            // AdressUsers
            // 
            this.AdressUsers.HeaderText = "Dirección ";
            this.AdressUsers.MinimumWidth = 6;
            this.AdressUsers.Name = "AdressUsers";
            this.AdressUsers.ReadOnly = true;
            this.AdressUsers.Width = 125;
            // 
            // UsersNameCode
            // 
            this.UsersNameCode.HeaderText = "Nombre del Usuario";
            this.UsersNameCode.MinimumWidth = 6;
            this.UsersNameCode.Name = "UsersNameCode";
            this.UsersNameCode.ReadOnly = true;
            this.UsersNameCode.Width = 125;
            // 
            // PassowordUsers
            // 
            this.PassowordUsers.HeaderText = "Contraseña";
            this.PassowordUsers.MinimumWidth = 6;
            this.PassowordUsers.Name = "PassowordUsers";
            this.PassowordUsers.ReadOnly = true;
            this.PassowordUsers.Width = 125;
            // 
            // UsersConcluyedSales
            // 
            this.UsersConcluyedSales.HeaderText = "Ventas Concretadas";
            this.UsersConcluyedSales.MinimumWidth = 6;
            this.UsersConcluyedSales.Name = "UsersConcluyedSales";
            this.UsersConcluyedSales.ReadOnly = true;
            this.UsersConcluyedSales.Width = 125;
            // 
            // UsersBilledaccount
            // 
            this.UsersBilledaccount.HeaderText = "Cuenta Facturada";
            this.UsersBilledaccount.MinimumWidth = 6;
            this.UsersBilledaccount.Name = "UsersBilledaccount";
            this.UsersBilledaccount.ReadOnly = true;
            this.UsersBilledaccount.Width = 125;
            // 
            // UsersAddedClients
            // 
            this.UsersAddedClients.HeaderText = "Clientes Añadidos";
            this.UsersAddedClients.MinimumWidth = 6;
            this.UsersAddedClients.Name = "UsersAddedClients";
            this.UsersAddedClients.ReadOnly = true;
            this.UsersAddedClients.Width = 125;
            // 
            // UserStatus
            // 
            this.UserStatus.HeaderText = "Activo";
            this.UserStatus.MinimumWidth = 6;
            this.UserStatus.Name = "UserStatus";
            this.UserStatus.ReadOnly = true;
            this.UserStatus.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.UserStatus.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.UserStatus.Width = 125;
            // 
            // pbTitleFrame
            // 
            this.pbTitleFrame.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pbTitleFrame.BackColor = System.Drawing.Color.Transparent;
            this.pbTitleFrame.Image = global::TuProductoOnline.Properties.Resources.Marco_de_Widgets;
            this.pbTitleFrame.Location = new System.Drawing.Point(363, 12);
            this.pbTitleFrame.Name = "pbTitleFrame";
            this.pbTitleFrame.Size = new System.Drawing.Size(255, 55);
            this.pbTitleFrame.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbTitleFrame.TabIndex = 86;
            this.pbTitleFrame.TabStop = false;
            // 
            // BillTotalAmount
            // 
            this.BillTotalAmount.HeaderText = "Monto ($) Total";
            this.BillTotalAmount.MinimumWidth = 6;
            this.BillTotalAmount.Name = "BillTotalAmount";
            this.BillTotalAmount.ReadOnly = true;
            this.BillTotalAmount.Width = 125;
            // 
            // SurnameClientSale
            // 
            this.SurnameClientSale.HeaderText = "Apellido Cliente";
            this.SurnameClientSale.MinimumWidth = 6;
            this.SurnameClientSale.Name = "SurnameClientSale";
            this.SurnameClientSale.ReadOnly = true;
            this.SurnameClientSale.Width = 125;
            // 
            // ClientSell
            // 
            this.ClientSell.HeaderText = "Nombre Cliente";
            this.ClientSell.MinimumWidth = 6;
            this.ClientSell.Name = "ClientSell";
            this.ClientSell.ReadOnly = true;
            this.ClientSell.Width = 125;
            // 
            // UsersSurnameSell
            // 
            this.UsersSurnameSell.HeaderText = "Apellido Usuario";
            this.UsersSurnameSell.MinimumWidth = 6;
            this.UsersSurnameSell.Name = "UsersSurnameSell";
            this.UsersSurnameSell.ReadOnly = true;
            this.UsersSurnameSell.Width = 125;
            // 
            // UsersNameSell
            // 
            this.UsersNameSell.HeaderText = "Nombre Usuario";
            this.UsersNameSell.MinimumWidth = 6;
            this.UsersNameSell.Name = "UsersNameSell";
            this.UsersNameSell.ReadOnly = true;
            this.UsersNameSell.Width = 125;
            // 
            // BillId
            // 
            this.BillId.HeaderText = "Codigo Factura";
            this.BillId.MinimumWidth = 6;
            this.BillId.Name = "BillId";
            this.BillId.ReadOnly = true;
            this.BillId.Width = 125;
            // 
            // dtgvBills
            // 
            this.dtgvBills.AllowUserToOrderColumns = true;
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle19.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle19.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvBills.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle19;
            this.dtgvBills.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dtgvBills.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.dtgvBills.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dtgvBills.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dtgvBills.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle20.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle20.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvBills.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle20;
            this.dtgvBills.ColumnHeadersHeight = 38;
            this.dtgvBills.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.BillId,
            this.UsersNameSell,
            this.UsersSurnameSell,
            this.ClientSell,
            this.SurnameClientSale,
            this.BillTotalAmount});
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle21.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle21.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle21.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvBills.DefaultCellStyle = dataGridViewCellStyle21;
            this.dtgvBills.EnableHeadersVisualStyles = false;
            this.dtgvBills.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.dtgvBills.Location = new System.Drawing.Point(128, 143);
            this.dtgvBills.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dtgvBills.Name = "dtgvBills";
            this.dtgvBills.ReadOnly = true;
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle22.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle22.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle22.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle22.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle22.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvBills.RowHeadersDefaultCellStyle = dataGridViewCellStyle22;
            this.dtgvBills.RowHeadersVisible = false;
            this.dtgvBills.RowHeadersWidth = 51;
            this.dtgvBills.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dtgvBills.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.dtgvBills.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Bold);
            this.dtgvBills.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.dtgvBills.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            this.dtgvBills.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.dtgvBills.RowTemplate.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvBills.RowTemplate.Height = 35;
            this.dtgvBills.Size = new System.Drawing.Size(747, 312);
            this.dtgvBills.TabIndex = 85;
            this.dtgvBills.Visible = false;
            this.dtgvBills.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgvBills_CellClick);
            // 
            // pbIconFrame
            // 
            this.pbIconFrame.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pbIconFrame.BackColor = System.Drawing.Color.Transparent;
            this.pbIconFrame.Image = global::TuProductoOnline.Properties.Resources.Marco_de_Widgets;
            this.pbIconFrame.Location = new System.Drawing.Point(914, 0);
            this.pbIconFrame.Name = "pbIconFrame";
            this.pbIconFrame.Size = new System.Drawing.Size(117, 112);
            this.pbIconFrame.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbIconFrame.TabIndex = 88;
            this.pbIconFrame.TabStop = false;
            // 
            // pbMenuIcon
            // 
            this.pbMenuIcon.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pbMenuIcon.BackColor = System.Drawing.Color.Transparent;
            this.pbMenuIcon.Image = global::TuProductoOnline.Properties.Resources.Icono_de_Registros1;
            this.pbMenuIcon.Location = new System.Drawing.Point(917, 5);
            this.pbMenuIcon.Name = "pbMenuIcon";
            this.pbMenuIcon.Size = new System.Drawing.Size(110, 102);
            this.pbMenuIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbMenuIcon.TabIndex = 89;
            this.pbMenuIcon.TabStop = false;
            // 
            // RecordsMenu
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(234)))), ((int)(((byte)(199)))));
            this.ClientSize = new System.Drawing.Size(1030, 560);
            this.Controls.Add(this.pbMenuIcon);
            this.Controls.Add(this.pbIconFrame);
            this.Controls.Add(this.btnOpenPDF);
            this.Controls.Add(this.cbCategory);
            this.Controls.Add(this.lblWelcome);
            this.Controls.Add(this.pbTitleFrame);
            this.Controls.Add(this.dtgvBills);
            this.Controls.Add(this.dtgvUsers);
            this.Controls.Add(this.dtgvClients);
            this.Controls.Add(this.dtgvProducts);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "RecordsMenu";
            this.Text = "RecordsMenu";
            ((System.ComponentModel.ISupportInitialize)(this.dtgvProducts)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvClients)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvUsers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbTitleFrame)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvBills)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbIconFrame)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMenuIcon)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.ComboBox cbCategory;
        private System.Windows.Forms.Button btnOpenPDF;
        private System.Windows.Forms.DataGridView dtgvProducts;
        private System.Windows.Forms.DataGridView dtgvClients;
        private System.Windows.Forms.DataGridView dtgvUsers;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewCheckBoxColumn ProductStatus;
        private System.Windows.Forms.DataGridViewCheckBoxColumn RemovedProducts;
        private System.Windows.Forms.DataGridViewTextBoxColumn UsersName;
        private System.Windows.Forms.DataGridViewTextBoxColumn LastnameUsers;
        private System.Windows.Forms.DataGridViewTextBoxColumn IdUsers;
        private System.Windows.Forms.DataGridViewTextBoxColumn PhoneUsers;
        private System.Windows.Forms.DataGridViewTextBoxColumn AdressUsers;
        private System.Windows.Forms.DataGridViewTextBoxColumn UsersNameCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn PassowordUsers;
        private System.Windows.Forms.DataGridViewTextBoxColumn UsersConcluyedSales;
        private System.Windows.Forms.DataGridViewTextBoxColumn UsersBilledaccount;
        private System.Windows.Forms.DataGridViewTextBoxColumn UsersAddedClients;
        private System.Windows.Forms.DataGridViewCheckBoxColumn UserStatus;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClientName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Lastname;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id;
        private System.Windows.Forms.DataGridViewTextBoxColumn Phone;
        private System.Windows.Forms.DataGridViewTextBoxColumn Adress;
        private System.Windows.Forms.DataGridViewCheckBoxColumn ClientStatus;
        private System.Windows.Forms.PictureBox pbTitleFrame;
        private System.Windows.Forms.DataGridViewTextBoxColumn BillTotalAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn SurnameClientSale;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClientSell;
        private System.Windows.Forms.DataGridViewTextBoxColumn UsersSurnameSell;
        private System.Windows.Forms.DataGridViewTextBoxColumn UsersNameSell;
        private System.Windows.Forms.DataGridViewTextBoxColumn BillId;
        private System.Windows.Forms.DataGridView dtgvBills;
        private System.Windows.Forms.PictureBox pbIconFrame;
        private System.Windows.Forms.PictureBox pbMenuIcon;
    }
}