﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TuProductoOnline
{

    public partial class RecordsMenu : Form
    {
        string idtosearch;//Este string será a el que le asignaremos el nombre de el pdf, que es el código correspondiente a la factura
        //Lo usaremos como ruta para acceder a el archivo
        public RecordsMenu()
        {
            InitializeComponent();
            ProductLoad();
            ClientLoad();
            UsersLoad();
            BillsLoad();

        }
        //Rutas de los json
        private static string _pathclient = Path.GetFullPath(Path.Combine(Application.StartupPath, "..\\..", "Clients.json"));

        private static string _pathproduct = Path.GetFullPath(Path.Combine(Application.StartupPath, "..\\..", "Products.json"));

        private static string _pathusers = Path.GetFullPath(Path.Combine(Application.StartupPath, "..\\..", "Users.json"));
        
        private static string _pathbills = Path.GetFullPath(Path.Combine(Application.StartupPath, "..\\..", "BillsRegistry.json"));

        public void ClientLoad(string searchText = "")//Carga de los clientes en el dtgv
        {
            dtgvClients.Rows.Clear();
            var clientsFromFile = GetClientsFromFile();
            var clients = JsonConvert.DeserializeObject<List<Client>>(clientsFromFile);

            if (clients != null)
            {
                foreach (Client client in clients)
                {

                    dtgvClients.Rows.Add(client.Name, client.LastName, client.Id, client.Phone, client.Address, client.Enabled);

                    //dtgvClients.Rows[n].Cells[0].Value = client.Name;
                    //dtgvClients.Rows[n].Cells[1].Value = client.LastName;
                    //dtgvClients.Rows[n].Cells[2].Value = client.Id;
                    //dtgvClients.Rows[n].Cells[3].Value = client.Phone;
                    //dtgvClients.Rows[n].Cells[4].Value = client.Address;
                    //dtgvClients.Rows[n].Cells[5].Value = client.Enabled;


                }
            }
            if (searchText.Length > 2)
            {

                clients = clients.Where(x => x.Name.Contains(searchText)).ToList();

            }
        }

        public void ProductLoad(string searchText = "")//Carga de los productos en el dtgv
        {
            dtgvProducts.Rows.Clear();
            var productsFromFile = GetProductsFromFile();
            var products = JsonConvert.DeserializeObject<List<Product>>(productsFromFile);

            if (products != null)
            {
                foreach (Product product in products)
                {
                    if (product.Cantity == 0)
                    {
                        product.Enabled = false;
                    }


                    dtgvProducts.Rows.Add(product.Id, product.Name, product.Price, product.Type, product.Description, product.Cantity, product.Enabled, product.Removed);

                    //    dtgvProducts.Rows[n].Cells[0].Value = product.Id;
                    //    dtgvProducts.Rows[n].Cells[1].Value = product.Name;
                    //    dtgvProducts.Rows[n].Cells[2].Value = product.Price;
                    //    dtgvProducts.Rows[n].Cells[3].Value = product.Type;
                    //    dtgvProducts.Rows[n].Cells[4].Value = product.Description;
                    //    dtgvProducts.Rows[n].Cells[5].Value = product.Cantity;
                    //    dtgvProducts.Rows[n].Cells[6].Value = product.Enabled;
                    //    dtgvProducts.Rows[n].Cells[7].Value = product.Removed;

                    
                }
            }
            if (searchText.Length > 2)
            {

                products = products.Where(x => x.Name.Contains(searchText)).ToList();

            }
        }

        public void UsersLoad(string searchText = "")//Carga de los usuarios en el dtgv
        {
            dtgvUsers.Rows.Clear();
            var usersFromFile = GetUsersFromFile();
            var users = JsonConvert.DeserializeObject<List<Employee>>(usersFromFile);

            if (users != null)
            {
                foreach (Employee employee in users)
                {
                        dtgvUsers.Rows.Add(employee.Name, employee.LastName, employee.Id, employee.Phone, employee.Address, employee.User, employee.Password, employee.ConcludedSales, employee.BilledAmount, employee.AddedClients,employee.Enabled);

                }
            }
            if (searchText.Length > 2)
            {

                users = users.Where(x => x.Name.Contains(searchText)).ToList();

            }
        }

        public void BillsLoad(string searchText = "")//Carga de las facturas en el dtgv
        {
            dtgvBills.Rows.Clear();
            var billsFromFile = GetBillsFromFile();
            var bills = JsonConvert.DeserializeObject<List<Bill>>(billsFromFile);

            if (bills != null)
            {
                foreach (Bill bill in bills)
                {
                    dtgvBills.Rows.Add(bill.BillId, bill.EmployeSale.Name, bill.EmployeSale.LastName, bill.ClientSale.Name, bill.ClientSale.LastName, bill.ProductSale.TotalAmount);

                }
            }
            if (searchText.Length > 2)
            {

                bills = bills.Where(x => x.EmployeSale.Name.Contains(searchText)).ToList();

            }
        }
        //Lecturas de los json
        public static string GetClientsFromFile()
        {
            string clientsJsonFromFile;
            using (var reader = new StreamReader(_pathclient))
            {
                clientsJsonFromFile = reader.ReadToEnd();
            }
            return clientsJsonFromFile;
        }

        public static string GetProductsFromFile()
        {
            string productsJsonFromFile;
            using (var reader = new StreamReader(_pathproduct))
            {
                productsJsonFromFile = reader.ReadToEnd();
            }
            return productsJsonFromFile;
        }
        public static string GetBillsFromFile()
        {
            string BillsJsonFromFile;
            using (var reader = new StreamReader(_pathbills))
            {
                BillsJsonFromFile = reader.ReadToEnd();
            }
            return BillsJsonFromFile;
        }

        private static string GetUsersFromFile()
        {
            string UsersJsonFromFile;
            using (var reader = new StreamReader(_pathusers))
            {
                UsersJsonFromFile = reader.ReadToEnd();
            }
            return UsersJsonFromFile;
        }
        //Al seleccionar el item en el combobox
        private void cbCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            if ((string)cbCategory.SelectedItem == "Productos") 
            {
                dtgvProducts.Visible = true;
                dtgvClients.Visible = false;
                dtgvUsers.Visible = false;
                dtgvBills.Visible = false;
                btnOpenPDF.Visible = false;

            }
            if ((string)cbCategory.SelectedItem == "Clientes")
            {
                dtgvClients.Visible = true;
                dtgvProducts.Visible = false;
                dtgvUsers.Visible = false;
                dtgvBills.Visible = false;
                btnOpenPDF.Visible = false;
            }
            if ((string)cbCategory.SelectedItem == "Facturas")
            {
                dtgvBills.Visible = true;
                dtgvClients.Visible = false;
                dtgvProducts.Visible = false;
                dtgvUsers.Visible = false;
                btnOpenPDF.Visible = true;
            }
            if ((string)cbCategory.SelectedItem == "Usuarios")
            {
                dtgvUsers.Visible = true;
                dtgvClients.Visible = false;
                dtgvProducts.Visible = false;
                dtgvBills.Visible = false;
                btnOpenPDF.Visible = false;
            }
        }


       
        
        
        private static string _pathfolderpdf = Path.GetFullPath(Path.Combine(Application.StartupPath, "..\\..", @"PDF\"));//Ruta de la carpeta donde se guardan los pdf

        public void OpenPDF()//Método para abrir los pdf
        {
            try
            {
                Process process = new Process();//Process proporciona acceso a procesos locales y remotos, y permite iniciar y detener procesos del sistema local.
                process.StartInfo.FileName = Path.Combine(_pathfolderpdf, idtosearch + ".pdf");//StartInfo.FileName obtiene o establece el archivo que se va a iniciar
                //Le asignamos la ruta donde se encuentra el archivo que deseamos abrir: Usamos Path.Combine para combinar rutas de acceso, "_pathfolder" es la ruta de la carpeta PDF
                //"idtosearch" tendrá como valor una cadena que será establecida al momento de seleccionar una celda en el dtgv
                //se agrega ".pdf" ya que es el formato de el archivo

                process.Start();//Inicia el proceso, es decir, abre el archivo
            }
            catch (Win32Exception ex)//Esta excepción ocurre si no se encuentra el archivo correspondiente, la capturamos para evitar que se cierre nuestro programa
            {
                MessageBox.Show("No Se Ha Encontrado El Archivo PDF Correspondiente");
            }

        }

        private void dtgvBills_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //Al seleccionar una casilla, le dará como valor a idtosearch el valor de la cell[0] en el row correspondiente
            //Es decir, el código de la factura
            int n = dtgvBills.CurrentRow.Index;
            if (n != -1 && n != dtgvBills.Rows.Count - 1)
            {
                idtosearch = dtgvBills.Rows[n].Cells[0].Value.ToString();
            }
            //Además, si se ha seleccionado una celda con valor, siendo de esta forma idtosearch diferente de null o vacia
            if (idtosearch != null && idtosearch != string.Empty)
            {
                btnOpenPDF.Enabled = true;//Habilitará el botón de ver factura

            }
            else { btnOpenPDF.Enabled = false; }//En el caso de que no, se deshablita el botón
        }
        private void btnOpenPDF_Click(object sender, EventArgs e)
        {
            //LLama a la función OpenPDF() que abre el pdf correspondiente a la factura seleccionada
            if (idtosearch != null && idtosearch != string.Empty)
            {
                OpenPDF();
            }

        }

        private void dtgvProducts_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 6)
            {
                if (Convert.ToBoolean(dtgvProducts.Rows[e.RowIndex].Cells[7].Value) == false)
                {
                    var productsFromFile = ProductManageMenu.GetProductsFromFile();
                    var products = JsonConvert.DeserializeObject<List<Product>>(productsFromFile);

                    string tomodify = dtgvProducts.Rows[e.RowIndex].Cells[0].Value.ToString();
                    foreach (Product product in products)
                    {
                        if (tomodify == product.Id)
                        {
                            if (product.Enabled == true)
                            {
                                product.Enabled = false;
                            }
                            else
                            {
                                product.Enabled = true;
                            }
                           
                        }
                    }
                    string productsJson = JsonConvert.SerializeObject(products.ToArray(), Formatting.Indented);//Serializa el objeto en forma de users(Una lista) y lo guarda en la variable
                    File.WriteAllText(_pathproduct, productsJson);
                }
                ProductLoad();
                ProductManageMenu pro = new ProductManageMenu();
                foreach (Form form in Application.OpenForms)
                {
                    if (form is ProductManageMenu)
                    {
                        pro = (ProductManageMenu)form;
                        break;
                    }
                }
                pro.ProductLoad();
            }
        }

        private void dtgvUsers_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 10)
            {
                
                var usersFromFile = GetUsersFromFile();
                var users = JsonConvert.DeserializeObject<List<Employee>>(usersFromFile);

                string tomodify = dtgvUsers.Rows[e.RowIndex].Cells[2].Value.ToString();
                foreach (Employee user in users)
                {
                    if (tomodify == user.Id.ToString())
                    {
                        if (user.Enabled == true)
                        {
                            user.Enabled = false;
                        }
                        else
                        {
                            user.Enabled = true;
                        }
                    }
                }
                string userslist = JsonConvert.SerializeObject(users.ToArray(), Formatting.Indented);
                File.WriteAllText(_pathusers, userslist);
                UsersLoad();
                UserManageMenu us = new UserManageMenu();
                foreach (Form form in Application.OpenForms)
                {
                    if (form is UserManageMenu)
                    {
                        us = (UserManageMenu)form;
                        break;
                    }
                }
                us.AdminsLoad();
            }
           
        }

        private void dtgvClients_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 5)
            {
                var clientsFromFile = GetClientsFromFile();
                var clients = JsonConvert.DeserializeObject<List<Client>>(clientsFromFile);
                string tomodify = dtgvClients.Rows[e.RowIndex].Cells[2].Value.ToString();
                foreach (Client client in clients)
                {
                    if (tomodify == client.Id.ToString())
                    {
                        if (client.Enabled == true)
                        {
                            client.Enabled = false;
                        }
                        else
                        {
                           client.Enabled = true;
                        }
                    }
                }
                string clientsJson = JsonConvert.SerializeObject(clients.ToArray(), Formatting.Indented);//Serializa el objeto en forma de users(Una lista) y lo guarda en la variable
                File.WriteAllText(_pathclient, clientsJson);
                ClientLoad();
                ClientManageMenu cli = new ClientManageMenu();
                foreach (Form form in Application.OpenForms)
                {
                    if (form is ClientManageMenu)
                    {
                        cli = (ClientManageMenu)form;
                        break;
                    }
                }
                cli.ClientLoad();
            }
        }

    }

}
