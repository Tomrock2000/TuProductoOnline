﻿using Newtonsoft.Json.Schema;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TuProductoOnline
{
    public class Bill//Clase para la factura
    {
        private Employee _employee;
        private Client _client;
        private CarShop _product;
        private string _billid;
        private bool _contributor;
        private DateTime _billdate;

        public Employee EmployeSale { get { return _employee; } set { _employee = value; } }
        public Client ClientSale { get { return _client; } set { _client = value; } }
        public CarShop ProductSale { get { return _product; } set { _product = value; } }
        public string BillId { get { return _billid; } set { _billid = value; } }
        public bool Contributor { get { return _contributor; } set { _contributor = value; } }
        public DateTime BillDate { get { return _billdate; } set { _billdate = value; } }
    }
    public class CarShop//Clase para el carrito de compras
    {
        private List<Product> _productsInCar;
        private int _cantity;
        private float _totalamount=0;
        public List<Product> ProductsInCar { get { return _productsInCar; } set { _productsInCar = value; } }
        public int CantitySale { get { return _cantity; } set { _cantity = value; } }
        public float TotalAmount { get { return _totalamount; } set { _totalamount = value; } }
    }
}
