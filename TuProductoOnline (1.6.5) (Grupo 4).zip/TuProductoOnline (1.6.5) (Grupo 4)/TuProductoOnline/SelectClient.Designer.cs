﻿namespace TuProductoOnline
{
    partial class SelectClient
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SelectClient));
            this.txtSelectIDClient = new System.Windows.Forms.TextBox();
            this.lblCédula = new System.Windows.Forms.Label();
            this.txtSelectPhoneClient = new System.Windows.Forms.TextBox();
            this.lblDirección = new System.Windows.Forms.Label();
            this.txtSelectAdressClient = new System.Windows.Forms.TextBox();
            this.lblPhone = new System.Windows.Forms.Label();
            this.txtSelectSurnameClient = new System.Windows.Forms.TextBox();
            this.lblApellido = new System.Windows.Forms.Label();
            this.txtSelectNameClient = new System.Windows.Forms.TextBox();
            this.lblNombre = new System.Windows.Forms.Label();
            this.btnSelectClient = new System.Windows.Forms.Button();
            this.pnlTopBorder = new System.Windows.Forms.Panel();
            this.dtgvClients = new System.Windows.Forms.DataGridView();
            this.ClientName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Lastname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Phone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Adress = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btnPrevPage = new System.Windows.Forms.Button();
            this.btnNextPage = new System.Windows.Forms.Button();
            this.pbSearch = new System.Windows.Forms.PictureBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvClients)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSearch)).BeginInit();
            this.SuspendLayout();
            // 
            // txtSelectIDClient
            // 
            this.txtSelectIDClient.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtSelectIDClient.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSelectIDClient.ForeColor = System.Drawing.Color.White;
            this.txtSelectIDClient.Location = new System.Drawing.Point(412, 55);
            this.txtSelectIDClient.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtSelectIDClient.Name = "txtSelectIDClient";
            this.txtSelectIDClient.ReadOnly = true;
            this.txtSelectIDClient.Size = new System.Drawing.Size(132, 26);
            this.txtSelectIDClient.TabIndex = 5;
            this.txtSelectIDClient.TextChanged += new System.EventHandler(this.txtSelectNameClient_TextChanged);
            // 
            // lblCédula
            // 
            this.lblCédula.AutoSize = true;
            this.lblCédula.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblCédula.Location = new System.Drawing.Point(445, 26);
            this.lblCédula.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCédula.Name = "lblCédula";
            this.lblCédula.Size = new System.Drawing.Size(65, 20);
            this.lblCédula.TabIndex = 55;
            this.lblCédula.Text = "Cédula";
            // 
            // txtSelectPhoneClient
            // 
            this.txtSelectPhoneClient.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtSelectPhoneClient.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSelectPhoneClient.ForeColor = System.Drawing.Color.White;
            this.txtSelectPhoneClient.Location = new System.Drawing.Point(240, 55);
            this.txtSelectPhoneClient.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtSelectPhoneClient.MaxLength = 11;
            this.txtSelectPhoneClient.Name = "txtSelectPhoneClient";
            this.txtSelectPhoneClient.ReadOnly = true;
            this.txtSelectPhoneClient.Size = new System.Drawing.Size(132, 26);
            this.txtSelectPhoneClient.TabIndex = 3;
            this.txtSelectPhoneClient.TextChanged += new System.EventHandler(this.txtSelectNameClient_TextChanged);
            // 
            // lblDirección
            // 
            this.lblDirección.AutoSize = true;
            this.lblDirección.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblDirección.Location = new System.Drawing.Point(264, 84);
            this.lblDirección.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDirección.Name = "lblDirección";
            this.lblDirección.Size = new System.Drawing.Size(84, 20);
            this.lblDirección.TabIndex = 53;
            this.lblDirección.Text = "Dirección";
            // 
            // txtSelectAdressClient
            // 
            this.txtSelectAdressClient.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtSelectAdressClient.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSelectAdressClient.ForeColor = System.Drawing.Color.White;
            this.txtSelectAdressClient.Location = new System.Drawing.Point(240, 108);
            this.txtSelectAdressClient.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtSelectAdressClient.Name = "txtSelectAdressClient";
            this.txtSelectAdressClient.ReadOnly = true;
            this.txtSelectAdressClient.Size = new System.Drawing.Size(132, 26);
            this.txtSelectAdressClient.TabIndex = 4;
            this.txtSelectAdressClient.TextChanged += new System.EventHandler(this.txtSelectNameClient_TextChanged);
            // 
            // lblPhone
            // 
            this.lblPhone.AutoSize = true;
            this.lblPhone.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblPhone.Location = new System.Drawing.Point(269, 26);
            this.lblPhone.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Size = new System.Drawing.Size(79, 20);
            this.lblPhone.TabIndex = 51;
            this.lblPhone.Text = "Teléfono";
            // 
            // txtSelectSurnameClient
            // 
            this.txtSelectSurnameClient.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtSelectSurnameClient.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSelectSurnameClient.ForeColor = System.Drawing.Color.White;
            this.txtSelectSurnameClient.Location = new System.Drawing.Point(48, 108);
            this.txtSelectSurnameClient.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtSelectSurnameClient.Name = "txtSelectSurnameClient";
            this.txtSelectSurnameClient.ReadOnly = true;
            this.txtSelectSurnameClient.Size = new System.Drawing.Size(132, 26);
            this.txtSelectSurnameClient.TabIndex = 2;
            this.txtSelectSurnameClient.TextChanged += new System.EventHandler(this.txtSelectNameClient_TextChanged);
            // 
            // lblApellido
            // 
            this.lblApellido.AutoSize = true;
            this.lblApellido.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblApellido.Location = new System.Drawing.Point(81, 84);
            this.lblApellido.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblApellido.Name = "lblApellido";
            this.lblApellido.Size = new System.Drawing.Size(73, 20);
            this.lblApellido.TabIndex = 49;
            this.lblApellido.Text = "Apellido";
            // 
            // txtSelectNameClient
            // 
            this.txtSelectNameClient.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtSelectNameClient.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSelectNameClient.ForeColor = System.Drawing.Color.White;
            this.txtSelectNameClient.Location = new System.Drawing.Point(48, 55);
            this.txtSelectNameClient.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtSelectNameClient.Name = "txtSelectNameClient";
            this.txtSelectNameClient.ReadOnly = true;
            this.txtSelectNameClient.Size = new System.Drawing.Size(132, 26);
            this.txtSelectNameClient.TabIndex = 1;
            this.txtSelectNameClient.TextChanged += new System.EventHandler(this.txtSelectNameClient_TextChanged);
            // 
            // lblNombre
            // 
            this.lblNombre.AutoSize = true;
            this.lblNombre.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblNombre.Location = new System.Drawing.Point(81, 26);
            this.lblNombre.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(71, 20);
            this.lblNombre.TabIndex = 47;
            this.lblNombre.Text = "Nombre";
            // 
            // btnSelectClient
            // 
            this.btnSelectClient.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.btnSelectClient.Enabled = false;
            this.btnSelectClient.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSelectClient.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.btnSelectClient.Location = new System.Drawing.Point(412, 421);
            this.btnSelectClient.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnSelectClient.Name = "btnSelectClient";
            this.btnSelectClient.Size = new System.Drawing.Size(132, 32);
            this.btnSelectClient.TabIndex = 6;
            this.btnSelectClient.Text = "Seleccionar";
            this.btnSelectClient.UseVisualStyleBackColor = false;
            this.btnSelectClient.Click += new System.EventHandler(this.btnSelectClient_Click);
            // 
            // pnlTopBorder
            // 
            this.pnlTopBorder.BackColor = System.Drawing.Color.Transparent;
            this.pnlTopBorder.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTopBorder.Location = new System.Drawing.Point(0, 0);
            this.pnlTopBorder.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pnlTopBorder.Name = "pnlTopBorder";
            this.pnlTopBorder.Size = new System.Drawing.Size(590, 23);
            this.pnlTopBorder.TabIndex = 59;
            this.pnlTopBorder.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlTopBorder_MouseDown);
            this.pnlTopBorder.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pnlTopBorder_MouseMove);
            this.pnlTopBorder.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pnlTopBorder_MouseUp);
            // 
            // dtgvClients
            // 
            this.dtgvClients.AllowUserToOrderColumns = true;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvClients.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dtgvClients.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.dtgvClients.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dtgvClients.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dtgvClients.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvClients.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dtgvClients.ColumnHeadersHeight = 38;
            this.dtgvClients.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ClientName,
            this.Lastname,
            this.Id,
            this.Phone,
            this.Adress});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvClients.DefaultCellStyle = dataGridViewCellStyle3;
            this.dtgvClients.EnableHeadersVisualStyles = false;
            this.dtgvClients.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.dtgvClients.Location = new System.Drawing.Point(48, 190);
            this.dtgvClients.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dtgvClients.Name = "dtgvClients";
            this.dtgvClients.ReadOnly = true;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvClients.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dtgvClients.RowHeadersVisible = false;
            this.dtgvClients.RowHeadersWidth = 51;
            this.dtgvClients.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dtgvClients.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.dtgvClients.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Bold);
            this.dtgvClients.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.dtgvClients.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            this.dtgvClients.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.dtgvClients.RowTemplate.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvClients.RowTemplate.Height = 35;
            this.dtgvClients.Size = new System.Drawing.Size(496, 221);
            this.dtgvClients.TabIndex = 71;
            this.dtgvClients.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgvClientes_CellClick);
            // 
            // ClientName
            // 
            this.ClientName.HeaderText = "Nombre Cliente";
            this.ClientName.MinimumWidth = 6;
            this.ClientName.Name = "ClientName";
            this.ClientName.ReadOnly = true;
            this.ClientName.Width = 125;
            // 
            // Lastname
            // 
            this.Lastname.HeaderText = "Apellido Cliente";
            this.Lastname.MinimumWidth = 6;
            this.Lastname.Name = "Lastname";
            this.Lastname.ReadOnly = true;
            this.Lastname.Width = 125;
            // 
            // Id
            // 
            this.Id.HeaderText = "Cédula Cliente";
            this.Id.MinimumWidth = 6;
            this.Id.Name = "Id";
            this.Id.ReadOnly = true;
            this.Id.Width = 125;
            // 
            // Phone
            // 
            this.Phone.HeaderText = "Teléfono Cliente";
            this.Phone.MinimumWidth = 6;
            this.Phone.Name = "Phone";
            this.Phone.ReadOnly = true;
            this.Phone.Width = 125;
            // 
            // Adress
            // 
            this.Adress.HeaderText = "Dirección Cliente";
            this.Adress.MinimumWidth = 6;
            this.Adress.Name = "Adress";
            this.Adress.ReadOnly = true;
            this.Adress.Width = 125;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.textBox1.Location = new System.Drawing.Point(48, 158);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox1.MaxLength = 100;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(324, 26);
            this.textBox1.TabIndex = 72;
            this.textBox1.Text = "Buscar...";
            this.textBox1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.textBox1_MouseClick);
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // btnPrevPage
            // 
            this.btnPrevPage.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnPrevPage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.btnPrevPage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPrevPage.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold);
            this.btnPrevPage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.btnPrevPage.Location = new System.Drawing.Point(224, 417);
            this.btnPrevPage.Name = "btnPrevPage";
            this.btnPrevPage.Size = new System.Drawing.Size(71, 38);
            this.btnPrevPage.TabIndex = 73;
            this.btnPrevPage.Text = "Pág. Anterior";
            this.btnPrevPage.UseVisualStyleBackColor = false;
            this.btnPrevPage.Click += new System.EventHandler(this.btnPrevPage_Click);
            // 
            // btnNextPage
            // 
            this.btnNextPage.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnNextPage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.btnNextPage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNextPage.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold);
            this.btnNextPage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.btnNextPage.Location = new System.Drawing.Point(301, 417);
            this.btnNextPage.Name = "btnNextPage";
            this.btnNextPage.Size = new System.Drawing.Size(71, 38);
            this.btnNextPage.TabIndex = 74;
            this.btnNextPage.Text = "Pág. Siguiente";
            this.btnNextPage.UseVisualStyleBackColor = false;
            this.btnNextPage.Click += new System.EventHandler(this.btnNextPage_Click);
            // 
            // pbSearch
            // 
            this.pbSearch.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pbSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.pbSearch.Image = global::TuProductoOnline.Properties.Resources.Lupa1;
            this.pbSearch.Location = new System.Drawing.Point(343, 158);
            this.pbSearch.Name = "pbSearch";
            this.pbSearch.Size = new System.Drawing.Size(26, 26);
            this.pbSearch.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSearch.TabIndex = 80;
            this.pbSearch.TabStop = false;
            // 
            // comboBox1
            // 
            this.comboBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.comboBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Cedula",
            "Nombre"});
            this.comboBox1.Location = new System.Drawing.Point(423, 156);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 28);
            this.comboBox1.TabIndex = 86;
            this.comboBox1.Text = "Ordenar por:";
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // SelectClient
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(234)))), ((int)(((byte)(199)))));
            this.ClientSize = new System.Drawing.Size(590, 465);
            this.ControlBox = false;
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.pbSearch);
            this.Controls.Add(this.btnPrevPage);
            this.Controls.Add(this.btnNextPage);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.dtgvClients);
            this.Controls.Add(this.pnlTopBorder);
            this.Controls.Add(this.btnSelectClient);
            this.Controls.Add(this.txtSelectIDClient);
            this.Controls.Add(this.lblCédula);
            this.Controls.Add(this.txtSelectPhoneClient);
            this.Controls.Add(this.lblDirección);
            this.Controls.Add(this.txtSelectAdressClient);
            this.Controls.Add(this.lblPhone);
            this.Controls.Add(this.txtSelectSurnameClient);
            this.Controls.Add(this.lblApellido);
            this.Controls.Add(this.txtSelectNameClient);
            this.Controls.Add(this.lblNombre);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "SelectClient";
            ((System.ComponentModel.ISupportInitialize)(this.dtgvClients)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSearch)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtSelectIDClient;
        private System.Windows.Forms.Label lblCédula;
        private System.Windows.Forms.TextBox txtSelectPhoneClient;
        private System.Windows.Forms.Label lblDirección;
        private System.Windows.Forms.TextBox txtSelectAdressClient;
        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.TextBox txtSelectSurnameClient;
        private System.Windows.Forms.Label lblApellido;
        private System.Windows.Forms.TextBox txtSelectNameClient;
        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.Button btnSelectClient;
        private System.Windows.Forms.Panel pnlTopBorder;
        private System.Windows.Forms.DataGridView dtgvClients;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClientName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Lastname;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id;
        private System.Windows.Forms.DataGridViewTextBoxColumn Phone;
        private System.Windows.Forms.DataGridViewTextBoxColumn Adress;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button btnPrevPage;
        private System.Windows.Forms.Button btnNextPage;
        private System.Windows.Forms.PictureBox pbSearch;
        private System.Windows.Forms.ComboBox comboBox1;
    }
}