﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace TuProductoOnline
{
    public partial class SelectClient : Form
    {
        int pagecount = 0;
        int clientsshowed = 0;
        public SelectClient()
        {
            InitializeComponent();
            ClientLoad();//Carga los datos a el dtgv
        }
        private void dtgvClientes_CellClick(object sender, DataGridViewCellEventArgs e)
            //Esta función nos carga en los txt los datos correspondientes a el cliente seleccionado en el dtgv
        {
            int m = dtgvClients.CurrentRow.Index;
            if (m != -1 && m != dtgvClients.Rows.Count - 1)
            {
                txtSelectNameClient.Text = (string)dtgvClients.Rows[m].Cells[0].Value;
                txtSelectSurnameClient.Text = (string)dtgvClients.Rows[m].Cells[1].Value;
                txtSelectPhoneClient.Text = dtgvClients.Rows[m].Cells[2].Value.ToString();
                txtSelectIDClient.Text = dtgvClients.Rows[m].Cells[3].Value.ToString();
                txtSelectAdressClient.Text = (string)dtgvClients.Rows[m].Cells[4].Value;

            }

        }
        public void ClientLoad(string searchText = "")//Carga los clientes en el dtgv
        {
            dtgvClients.Rows.Clear();
            var clientsFromFile = AddClients.GetClientsFromFile();
            var clients = JsonConvert.DeserializeObject<List<Client>>(clientsFromFile);
            IEnumerable<Client> clientslist = clients.Where(client => client.Enabled == true).Skip(pagecount * 20).Take(20);

            clientsshowed = (pagecount * 20) + 20;
            if (clients != null)
            {
                foreach (Client client in clientslist)
                {
                    if (client.Enabled == true)
                    {
                        dtgvClients.Rows.Add(client.Name, client.LastName, client.Id, client.Phone, client.Address);

                    }
                }
            }
            if (searchText.Length > 2)
            {

                clients = clients.Where(x => x.Name.Contains(searchText)).ToList();

            }

        }

        private void btnSelectClient_Click(object sender, EventArgs e)//Al presionar el botón de seleccionar

        {
            NewSaleMenu newsalemenu = new NewSaleMenu(); //Instanciamos un objeto NewSaleMenu 
            foreach (Form form in Application.OpenForms)//Buscaremos en cada form abierto en la aplicación
            {
                if (form is NewSaleMenu)//Si el form es de tipo NewSaleMenu
                {
                    newsalemenu = (NewSaleMenu)form;//Asignaremos a el objeto instanciado inicialmente el form encontrado en los forms abiertos
                    break;//Rompemos el ciclo
                }
            }//De esta manera podemos referirnos a el form NewSaleMenu activo y podemos trabajar con él mediante newsalemenu
             //En la cual le enviaremos los datos que recibirá y aplicará en ese form

            newsalemenu.BillCheck();
            newsalemenu.SelectClient(txtSelectNameClient.Text, txtSelectSurnameClient.Text,
            txtSelectIDClient.Text,txtSelectAdressClient.Text,txtSelectPhoneClient.Text);
            //Aquí, enviamos los datos de el cliente seleccionado a el form anterior a través
            //de la función establecida en NewSaleForm
            //Pueden ir a NewSaleForm para verificar
            this.Close();
        }
        public void SelectClientChecker()
        {
            if(txtSelectNameClient!=null && txtSelectSurnameClient!=null && txtSelectIDClient!=null && txtSelectPhoneClient!=null && txtSelectAdressClient != null)
            {
                btnSelectClient.Enabled = true;

            }
            else
            {
                btnSelectClient.Enabled = false;
            }
        }

        private void txtSelectNameClient_TextChanged(object sender, EventArgs e)
        {
            SelectClientChecker();
        }
        int m, mx, my;
        private void pnlTopBorder_MouseDown(object sender, MouseEventArgs e)
        {
            m = 1;
            mx = e.X;
            my = e.Y;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string searchText = textBox1.Text.ToLower();

            int columnIndex = dtgvClients.Columns["ClientName"].Index;

            try
            {
                ClientLoad(searchText);

                if (searchText.Length < 2)
                {
                    return;
                }


                foreach (DataGridViewRow row in dtgvClients.Rows)
                {

                    bool found = false;

                    DataGridViewCell cell = row.Cells[columnIndex];



                    if (cell.Value != null && cell.Value.ToString().ToLower().Contains(searchText))
                    {
                        found = true;
                    }
                    row.Visible = found;
                }
            }
            catch (Exception a)
            {

            }
        }

        private void textBox1_MouseClick(object sender, MouseEventArgs e)
        {
            textBox1.Text = "";
        }

        private void pnlTopBorder_MouseMove(object sender, MouseEventArgs e)
        {
            if (m == 1)
            {
                this.SetDesktopLocation(MousePosition.X - mx, MousePosition.Y - my);
            }
        }

        private void pnlTopBorder_MouseUp(object sender, MouseEventArgs e)
        {
            m = 0;
        }


        List<Client> OrdenarLista(string campo)
        {

            var clientsFromFile = AddClients.GetClientsFromFile();
            var clients = JsonConvert.DeserializeObject<List<Client>>(clientsFromFile);


            switch (campo)
            {
                case "Nombre":
                    return clients.OrderBy(p => p.Name).ToList();
                case "Cedula":
                    return clients.OrderBy(p => p.Id).ToList();
                default:
                    return clients;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            dtgvClients.Rows.Clear();

            string campo = comboBox1.SelectedItem.ToString();

            List<Client> orderedclients = OrdenarLista(campo);

            if (orderedclients != null)
            {
                foreach (Client client in orderedclients)
                {
                    if (client.Enabled == true)
                    {

                        dtgvClients.Rows.Add(client.Name, client.LastName, client.Id, client.Phone, client.Address);

                    }
                }


            }
        }

        private void btnPrevPage_Click(object sender, EventArgs e)
        {
            if (pagecount > 0)
            {
                pagecount--;
            }
            ClientLoad();
        }
        private void btnNextPage_Click(object sender, EventArgs e)
        {
            var clientsFromFile = AddClients.GetClientsFromFile();
            var clients = JsonConvert.DeserializeObject<List<Client>>(clientsFromFile);
            if (clientsshowed < clients.Count)
            {
                pagecount++;
                ClientLoad();
            }
        }
    }
}
