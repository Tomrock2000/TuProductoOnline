﻿namespace TuProductoOnline
{
    partial class SelectProduct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SelectProduct));
            this.txtTypeProduct = new System.Windows.Forms.TextBox();
            this.lblCantityAvailable = new System.Windows.Forms.Label();
            this.txtCantityAvailableProduct = new System.Windows.Forms.TextBox();
            this.lblModelProduct = new System.Windows.Forms.Label();
            this.txtModelProduct = new System.Windows.Forms.TextBox();
            this.lblVersionProduct = new System.Windows.Forms.Label();
            this.txtVersionProduct = new System.Windows.Forms.TextBox();
            this.lblLicenceProduct = new System.Windows.Forms.Label();
            this.txtLicenceProduct = new System.Windows.Forms.TextBox();
            this.lblMeassuresProduct = new System.Windows.Forms.Label();
            this.txtMeassuresProduct = new System.Windows.Forms.TextBox();
            this.lblPriceProduct = new System.Windows.Forms.Label();
            this.txtPriceProduct = new System.Windows.Forms.TextBox();
            this.lblNameProduct = new System.Windows.Forms.Label();
            this.txtNameProduct = new System.Windows.Forms.TextBox();
            this.lblDescriptionProduct = new System.Windows.Forms.Label();
            this.lblIdProduct = new System.Windows.Forms.Label();
            this.txtIdProduct = new System.Windows.Forms.TextBox();
            this.btnSelectProduct = new System.Windows.Forms.Button();
            this.txtCantityToSale = new System.Windows.Forms.TextBox();
            this.lblCantityToSale = new System.Windows.Forms.Label();
            this.btnBack = new System.Windows.Forms.Button();
            this.lblType = new System.Windows.Forms.Label();
            this.pnlTopBorder = new System.Windows.Forms.Panel();
            this.txtDescriptionProduct = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.dtgvProducts = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pbSearch = new System.Windows.Forms.PictureBox();
            this.btnPrevPage = new System.Windows.Forms.Button();
            this.btnNextPage = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvProducts)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSearch)).BeginInit();
            this.SuspendLayout();
            // 
            // txtTypeProduct
            // 
            this.txtTypeProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtTypeProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTypeProduct.Enabled = false;
            this.txtTypeProduct.ForeColor = System.Drawing.Color.White;
            this.txtTypeProduct.Location = new System.Drawing.Point(43, 103);
            this.txtTypeProduct.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtTypeProduct.MaxLength = 20;
            this.txtTypeProduct.Name = "txtTypeProduct";
            this.txtTypeProduct.ReadOnly = true;
            this.txtTypeProduct.Size = new System.Drawing.Size(176, 26);
            this.txtTypeProduct.TabIndex = 4;
            this.txtTypeProduct.TextChanged += new System.EventHandler(this.txtNameProduct_TextChanged);
            // 
            // lblCantityAvailable
            // 
            this.lblCantityAvailable.AutoSize = true;
            this.lblCantityAvailable.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.lblCantityAvailable.Location = new System.Drawing.Point(256, 80);
            this.lblCantityAvailable.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCantityAvailable.Name = "lblCantityAvailable";
            this.lblCantityAvailable.Size = new System.Drawing.Size(158, 18);
            this.lblCantityAvailable.TabIndex = 80;
            this.lblCantityAvailable.Text = "Cantidad Disponible";
            // 
            // txtCantityAvailableProduct
            // 
            this.txtCantityAvailableProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtCantityAvailableProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCantityAvailableProduct.Enabled = false;
            this.txtCantityAvailableProduct.ForeColor = System.Drawing.Color.White;
            this.txtCantityAvailableProduct.Location = new System.Drawing.Point(250, 103);
            this.txtCantityAvailableProduct.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtCantityAvailableProduct.MaxLength = 3;
            this.txtCantityAvailableProduct.Name = "txtCantityAvailableProduct";
            this.txtCantityAvailableProduct.ReadOnly = true;
            this.txtCantityAvailableProduct.Size = new System.Drawing.Size(176, 26);
            this.txtCantityAvailableProduct.TabIndex = 5;
            this.txtCantityAvailableProduct.TextChanged += new System.EventHandler(this.txtNameProduct_TextChanged);
            // 
            // lblModelProduct
            // 
            this.lblModelProduct.AutoSize = true;
            this.lblModelProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.lblModelProduct.Location = new System.Drawing.Point(516, 81);
            this.lblModelProduct.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblModelProduct.Name = "lblModelProduct";
            this.lblModelProduct.Size = new System.Drawing.Size(54, 18);
            this.lblModelProduct.TabIndex = 77;
            this.lblModelProduct.Text = "Model";
            this.lblModelProduct.Visible = false;
            // 
            // txtModelProduct
            // 
            this.txtModelProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtModelProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtModelProduct.Enabled = false;
            this.txtModelProduct.ForeColor = System.Drawing.Color.White;
            this.txtModelProduct.Location = new System.Drawing.Point(453, 103);
            this.txtModelProduct.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtModelProduct.MaxLength = 20;
            this.txtModelProduct.Name = "txtModelProduct";
            this.txtModelProduct.ReadOnly = true;
            this.txtModelProduct.Size = new System.Drawing.Size(176, 26);
            this.txtModelProduct.TabIndex = 6;
            this.txtModelProduct.Visible = false;
            this.txtModelProduct.TextChanged += new System.EventHandler(this.txtNameProduct_TextChanged);
            // 
            // lblVersionProduct
            // 
            this.lblVersionProduct.AutoSize = true;
            this.lblVersionProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.lblVersionProduct.Location = new System.Drawing.Point(93, 135);
            this.lblVersionProduct.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblVersionProduct.Name = "lblVersionProduct";
            this.lblVersionProduct.Size = new System.Drawing.Size(65, 18);
            this.lblVersionProduct.TabIndex = 75;
            this.lblVersionProduct.Text = "Versión";
            this.lblVersionProduct.Visible = false;
            // 
            // txtVersionProduct
            // 
            this.txtVersionProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtVersionProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtVersionProduct.Enabled = false;
            this.txtVersionProduct.ForeColor = System.Drawing.Color.White;
            this.txtVersionProduct.Location = new System.Drawing.Point(43, 159);
            this.txtVersionProduct.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtVersionProduct.MaxLength = 20;
            this.txtVersionProduct.Name = "txtVersionProduct";
            this.txtVersionProduct.ReadOnly = true;
            this.txtVersionProduct.Size = new System.Drawing.Size(176, 26);
            this.txtVersionProduct.TabIndex = 7;
            this.txtVersionProduct.Visible = false;
            this.txtVersionProduct.TextChanged += new System.EventHandler(this.txtNameProduct_TextChanged);
            // 
            // lblLicenceProduct
            // 
            this.lblLicenceProduct.AutoSize = true;
            this.lblLicenceProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.lblLicenceProduct.Location = new System.Drawing.Point(508, 81);
            this.lblLicenceProduct.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblLicenceProduct.Name = "lblLicenceProduct";
            this.lblLicenceProduct.Size = new System.Drawing.Size(70, 18);
            this.lblLicenceProduct.TabIndex = 73;
            this.lblLicenceProduct.Text = "Licencia";
            this.lblLicenceProduct.Visible = false;
            // 
            // txtLicenceProduct
            // 
            this.txtLicenceProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtLicenceProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtLicenceProduct.Enabled = false;
            this.txtLicenceProduct.ForeColor = System.Drawing.Color.White;
            this.txtLicenceProduct.Location = new System.Drawing.Point(453, 103);
            this.txtLicenceProduct.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtLicenceProduct.MaxLength = 20;
            this.txtLicenceProduct.Name = "txtLicenceProduct";
            this.txtLicenceProduct.ReadOnly = true;
            this.txtLicenceProduct.Size = new System.Drawing.Size(176, 26);
            this.txtLicenceProduct.TabIndex = 72;
            this.txtLicenceProduct.Visible = false;
            this.txtLicenceProduct.TextChanged += new System.EventHandler(this.txtNameProduct_TextChanged);
            // 
            // lblMeassuresProduct
            // 
            this.lblMeassuresProduct.AutoSize = true;
            this.lblMeassuresProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.lblMeassuresProduct.Location = new System.Drawing.Point(512, 81);
            this.lblMeassuresProduct.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMeassuresProduct.Name = "lblMeassuresProduct";
            this.lblMeassuresProduct.Size = new System.Drawing.Size(71, 18);
            this.lblMeassuresProduct.TabIndex = 71;
            this.lblMeassuresProduct.Text = "Medidas";
            this.lblMeassuresProduct.Visible = false;
            // 
            // txtMeassuresProduct
            // 
            this.txtMeassuresProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtMeassuresProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtMeassuresProduct.Enabled = false;
            this.txtMeassuresProduct.ForeColor = System.Drawing.Color.White;
            this.txtMeassuresProduct.Location = new System.Drawing.Point(453, 103);
            this.txtMeassuresProduct.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtMeassuresProduct.MaxLength = 20;
            this.txtMeassuresProduct.Name = "txtMeassuresProduct";
            this.txtMeassuresProduct.ReadOnly = true;
            this.txtMeassuresProduct.Size = new System.Drawing.Size(176, 26);
            this.txtMeassuresProduct.TabIndex = 70;
            this.txtMeassuresProduct.Visible = false;
            this.txtMeassuresProduct.TextChanged += new System.EventHandler(this.txtNameProduct_TextChanged);
            // 
            // lblPriceProduct
            // 
            this.lblPriceProduct.AutoSize = true;
            this.lblPriceProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.lblPriceProduct.Location = new System.Drawing.Point(310, 28);
            this.lblPriceProduct.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPriceProduct.Name = "lblPriceProduct";
            this.lblPriceProduct.Size = new System.Drawing.Size(57, 18);
            this.lblPriceProduct.TabIndex = 69;
            this.lblPriceProduct.Text = "Precio";
            // 
            // txtPriceProduct
            // 
            this.txtPriceProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtPriceProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPriceProduct.Enabled = false;
            this.txtPriceProduct.ForeColor = System.Drawing.Color.White;
            this.txtPriceProduct.Location = new System.Drawing.Point(250, 51);
            this.txtPriceProduct.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtPriceProduct.MaxLength = 6;
            this.txtPriceProduct.Name = "txtPriceProduct";
            this.txtPriceProduct.ReadOnly = true;
            this.txtPriceProduct.Size = new System.Drawing.Size(176, 26);
            this.txtPriceProduct.TabIndex = 2;
            this.txtPriceProduct.TextChanged += new System.EventHandler(this.txtNameProduct_TextChanged);
            // 
            // lblNameProduct
            // 
            this.lblNameProduct.AutoSize = true;
            this.lblNameProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.lblNameProduct.Location = new System.Drawing.Point(92, 28);
            this.lblNameProduct.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNameProduct.Name = "lblNameProduct";
            this.lblNameProduct.Size = new System.Drawing.Size(68, 18);
            this.lblNameProduct.TabIndex = 67;
            this.lblNameProduct.Text = "Nombre";
            // 
            // txtNameProduct
            // 
            this.txtNameProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtNameProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtNameProduct.Enabled = false;
            this.txtNameProduct.ForeColor = System.Drawing.Color.White;
            this.txtNameProduct.Location = new System.Drawing.Point(43, 51);
            this.txtNameProduct.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtNameProduct.MaxLength = 20;
            this.txtNameProduct.Name = "txtNameProduct";
            this.txtNameProduct.ReadOnly = true;
            this.txtNameProduct.Size = new System.Drawing.Size(176, 26);
            this.txtNameProduct.TabIndex = 1;
            this.txtNameProduct.TextChanged += new System.EventHandler(this.txtNameProduct_TextChanged);
            // 
            // lblDescriptionProduct
            // 
            this.lblDescriptionProduct.AutoSize = true;
            this.lblDescriptionProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.lblDescriptionProduct.Location = new System.Drawing.Point(287, 135);
            this.lblDescriptionProduct.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDescriptionProduct.Name = "lblDescriptionProduct";
            this.lblDescriptionProduct.Size = new System.Drawing.Size(98, 18);
            this.lblDescriptionProduct.TabIndex = 65;
            this.lblDescriptionProduct.Text = "Descripción";
            // 
            // lblIdProduct
            // 
            this.lblIdProduct.AutoSize = true;
            this.lblIdProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.lblIdProduct.Location = new System.Drawing.Point(512, 28);
            this.lblIdProduct.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblIdProduct.Name = "lblIdProduct";
            this.lblIdProduct.Size = new System.Drawing.Size(62, 18);
            this.lblIdProduct.TabIndex = 64;
            this.lblIdProduct.Text = "Código";
            // 
            // txtIdProduct
            // 
            this.txtIdProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtIdProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtIdProduct.Enabled = false;
            this.txtIdProduct.ForeColor = System.Drawing.Color.White;
            this.txtIdProduct.Location = new System.Drawing.Point(456, 51);
            this.txtIdProduct.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtIdProduct.MaxLength = 10;
            this.txtIdProduct.Name = "txtIdProduct";
            this.txtIdProduct.ReadOnly = true;
            this.txtIdProduct.Size = new System.Drawing.Size(176, 26);
            this.txtIdProduct.TabIndex = 3;
            this.txtIdProduct.TextChanged += new System.EventHandler(this.txtNameProduct_TextChanged);
            // 
            // btnSelectProduct
            // 
            this.btnSelectProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.btnSelectProduct.Enabled = false;
            this.btnSelectProduct.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSelectProduct.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.btnSelectProduct.Location = new System.Drawing.Point(512, 354);
            this.btnSelectProduct.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnSelectProduct.Name = "btnSelectProduct";
            this.btnSelectProduct.Size = new System.Drawing.Size(120, 27);
            this.btnSelectProduct.TabIndex = 11;
            this.btnSelectProduct.Text = "Seleccionar";
            this.btnSelectProduct.UseVisualStyleBackColor = false;
            this.btnSelectProduct.Click += new System.EventHandler(this.btnSelectProduct_Click);
            // 
            // txtCantityToSale
            // 
            this.txtCantityToSale.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtCantityToSale.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCantityToSale.ForeColor = System.Drawing.Color.White;
            this.txtCantityToSale.Location = new System.Drawing.Point(512, 313);
            this.txtCantityToSale.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtCantityToSale.Name = "txtCantityToSale";
            this.txtCantityToSale.Size = new System.Drawing.Size(120, 26);
            this.txtCantityToSale.TabIndex = 10;
            this.txtCantityToSale.TextChanged += new System.EventHandler(this.txtCantityToSale_TextChanged);
            this.txtCantityToSale.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCantityToSale_KeyPress);
            // 
            // lblCantityToSale
            // 
            this.lblCantityToSale.AutoSize = true;
            this.lblCantityToSale.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.lblCantityToSale.Location = new System.Drawing.Point(508, 280);
            this.lblCantityToSale.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCantityToSale.Name = "lblCantityToSale";
            this.lblCantityToSale.Size = new System.Drawing.Size(121, 18);
            this.lblCantityToSale.TabIndex = 85;
            this.lblCantityToSale.Text = "Cantidad Venta";
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBack.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.btnBack.Location = new System.Drawing.Point(512, 387);
            this.btnBack.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(120, 27);
            this.btnBack.TabIndex = 12;
            this.btnBack.Text = "Regresar";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // lblType
            // 
            this.lblType.AutoSize = true;
            this.lblType.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.lblType.Location = new System.Drawing.Point(85, 80);
            this.lblType.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblType.Name = "lblType";
            this.lblType.Size = new System.Drawing.Size(81, 18);
            this.lblType.TabIndex = 87;
            this.lblType.Text = "Categoria";
            // 
            // pnlTopBorder
            // 
            this.pnlTopBorder.BackColor = System.Drawing.Color.Transparent;
            this.pnlTopBorder.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTopBorder.Location = new System.Drawing.Point(0, 0);
            this.pnlTopBorder.Name = "pnlTopBorder";
            this.pnlTopBorder.Size = new System.Drawing.Size(673, 20);
            this.pnlTopBorder.TabIndex = 88;
            this.pnlTopBorder.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlTopBorder_MouseDown);
            this.pnlTopBorder.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pnlTopBorder_MouseMove);
            this.pnlTopBorder.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pnlTopBorder_MouseUp);
            // 
            // txtDescriptionProduct
            // 
            this.txtDescriptionProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.txtDescriptionProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDescriptionProduct.Enabled = false;
            this.txtDescriptionProduct.ForeColor = System.Drawing.Color.White;
            this.txtDescriptionProduct.Location = new System.Drawing.Point(250, 159);
            this.txtDescriptionProduct.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtDescriptionProduct.MaxLength = 10;
            this.txtDescriptionProduct.Multiline = true;
            this.txtDescriptionProduct.Name = "txtDescriptionProduct";
            this.txtDescriptionProduct.ReadOnly = true;
            this.txtDescriptionProduct.Size = new System.Drawing.Size(379, 57);
            this.txtDescriptionProduct.TabIndex = 89;
            // 
            // textBox1
            // 
            this.textBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.textBox1.Location = new System.Drawing.Point(43, 222);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(437, 26);
            this.textBox1.TabIndex = 91;
            this.textBox1.Text = "Buscar...";
            this.textBox1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.textBox1_MouseClick);
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // dtgvProducts
            // 
            this.dtgvProducts.AllowUserToOrderColumns = true;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvProducts.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dtgvProducts.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.dtgvProducts.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dtgvProducts.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dtgvProducts.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvProducts.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dtgvProducts.ColumnHeadersHeight = 45;
            this.dtgvProducts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dtgvProducts.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.ProductName,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6});
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvProducts.DefaultCellStyle = dataGridViewCellStyle8;
            this.dtgvProducts.EnableHeadersVisualStyles = false;
            this.dtgvProducts.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.dtgvProducts.Location = new System.Drawing.Point(43, 255);
            this.dtgvProducts.Name = "dtgvProducts";
            this.dtgvProducts.ReadOnly = true;
            this.dtgvProducts.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dtgvProducts.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvProducts.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.dtgvProducts.RowHeadersVisible = false;
            this.dtgvProducts.RowHeadersWidth = 51;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Bold);
            this.dtgvProducts.RowsDefaultCellStyle = dataGridViewCellStyle10;
            this.dtgvProducts.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dtgvProducts.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.dtgvProducts.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Bold);
            this.dtgvProducts.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.dtgvProducts.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            this.dtgvProducts.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.dtgvProducts.RowTemplate.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvProducts.RowTemplate.Height = 40;
            this.dtgvProducts.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvProducts.Size = new System.Drawing.Size(437, 171);
            this.dtgvProducts.TabIndex = 92;
            this.dtgvProducts.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgvProducts_CellClick);
            // 
            // dataGridViewTextBoxColumn1
            // 
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewTextBoxColumn1.HeaderText = "Código Producto";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 125;
            // 
            // ProductName
            // 
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.ProductName.DefaultCellStyle = dataGridViewCellStyle4;
            this.ProductName.HeaderText = "Nombre Producto";
            this.ProductName.MinimumWidth = 6;
            this.ProductName.Name = "ProductName";
            this.ProductName.ReadOnly = true;
            this.ProductName.Width = 125;
            // 
            // dataGridViewTextBoxColumn3
            // 
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.dataGridViewTextBoxColumn3.DefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridViewTextBoxColumn3.HeaderText = "Precio ($) Producto";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 125;
            // 
            // dataGridViewTextBoxColumn4
            // 
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.dataGridViewTextBoxColumn4.DefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridViewTextBoxColumn4.HeaderText = "Categoria Producto";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 125;
            // 
            // dataGridViewTextBoxColumn5
            // 
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.dataGridViewTextBoxColumn5.DefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridViewTextBoxColumn5.HeaderText = "Descripcion Producto";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Width = 125;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.HeaderText = "Cantidad Producto";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            // 
            // pbSearch
            // 
            this.pbSearch.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pbSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.pbSearch.Image = global::TuProductoOnline.Properties.Resources.Lupa1;
            this.pbSearch.Location = new System.Drawing.Point(450, 222);
            this.pbSearch.Name = "pbSearch";
            this.pbSearch.Size = new System.Drawing.Size(26, 26);
            this.pbSearch.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSearch.TabIndex = 93;
            this.pbSearch.TabStop = false;
            // 
            // btnPrevPage
            // 
            this.btnPrevPage.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnPrevPage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.btnPrevPage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPrevPage.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Bold);
            this.btnPrevPage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.btnPrevPage.Location = new System.Drawing.Point(195, 432);
            this.btnPrevPage.Name = "btnPrevPage";
            this.btnPrevPage.Size = new System.Drawing.Size(71, 38);
            this.btnPrevPage.TabIndex = 94;
            this.btnPrevPage.Text = "Pág. Anterior";
            this.btnPrevPage.UseVisualStyleBackColor = false;
            this.btnPrevPage.Click += new System.EventHandler(this.btnPrevPage_Click);
            // 
            // btnNextPage
            // 
            this.btnNextPage.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnNextPage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.btnNextPage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNextPage.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Bold);
            this.btnNextPage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.btnNextPage.Location = new System.Drawing.Point(272, 432);
            this.btnNextPage.Name = "btnNextPage";
            this.btnNextPage.Size = new System.Drawing.Size(71, 38);
            this.btnNextPage.TabIndex = 95;
            this.btnNextPage.Text = "Pág. Siguiente";
            this.btnNextPage.UseVisualStyleBackColor = false;
            this.btnNextPage.Click += new System.EventHandler(this.btnNextPage_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.comboBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Codigo",
            "Nombre"});
            this.comboBox1.Location = new System.Drawing.Point(43, 432);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 28);
            this.comboBox1.TabIndex = 96;
            this.comboBox1.Text = "Ordenar por:";
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // SelectProduct
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(234)))), ((int)(((byte)(199)))));
            this.ClientSize = new System.Drawing.Size(673, 479);
            this.ControlBox = false;
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.btnPrevPage);
            this.Controls.Add(this.btnNextPage);
            this.Controls.Add(this.pbSearch);
            this.Controls.Add(this.dtgvProducts);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.txtDescriptionProduct);
            this.Controls.Add(this.pnlTopBorder);
            this.Controls.Add(this.lblType);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.lblCantityToSale);
            this.Controls.Add(this.txtCantityToSale);
            this.Controls.Add(this.btnSelectProduct);
            this.Controls.Add(this.txtTypeProduct);
            this.Controls.Add(this.lblCantityAvailable);
            this.Controls.Add(this.txtCantityAvailableProduct);
            this.Controls.Add(this.lblModelProduct);
            this.Controls.Add(this.txtModelProduct);
            this.Controls.Add(this.lblVersionProduct);
            this.Controls.Add(this.txtVersionProduct);
            this.Controls.Add(this.lblLicenceProduct);
            this.Controls.Add(this.txtLicenceProduct);
            this.Controls.Add(this.lblMeassuresProduct);
            this.Controls.Add(this.txtMeassuresProduct);
            this.Controls.Add(this.lblPriceProduct);
            this.Controls.Add(this.txtPriceProduct);
            this.Controls.Add(this.lblNameProduct);
            this.Controls.Add(this.txtNameProduct);
            this.Controls.Add(this.lblDescriptionProduct);
            this.Controls.Add(this.lblIdProduct);
            this.Controls.Add(this.txtIdProduct);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "SelectProduct";
            ((System.ComponentModel.ISupportInitialize)(this.dtgvProducts)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSearch)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtTypeProduct;
        private System.Windows.Forms.Label lblCantityAvailable;
        private System.Windows.Forms.TextBox txtCantityAvailableProduct;
        private System.Windows.Forms.Label lblModelProduct;
        private System.Windows.Forms.TextBox txtModelProduct;
        private System.Windows.Forms.Label lblVersionProduct;
        private System.Windows.Forms.TextBox txtVersionProduct;
        private System.Windows.Forms.Label lblLicenceProduct;
        private System.Windows.Forms.TextBox txtLicenceProduct;
        private System.Windows.Forms.Label lblMeassuresProduct;
        private System.Windows.Forms.TextBox txtMeassuresProduct;
        private System.Windows.Forms.Label lblPriceProduct;
        private System.Windows.Forms.TextBox txtPriceProduct;
        private System.Windows.Forms.Label lblNameProduct;
        private System.Windows.Forms.TextBox txtNameProduct;
        private System.Windows.Forms.Label lblDescriptionProduct;
        private System.Windows.Forms.Label lblIdProduct;
        private System.Windows.Forms.TextBox txtIdProduct;
        private System.Windows.Forms.Button btnSelectProduct;
        private System.Windows.Forms.TextBox txtCantityToSale;
        private System.Windows.Forms.Label lblCantityToSale;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Label lblType;
        private System.Windows.Forms.Panel pnlTopBorder;
        private System.Windows.Forms.TextBox txtDescriptionProduct;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.DataGridView dtgvProducts;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductName;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.PictureBox pbSearch;
        private System.Windows.Forms.Button btnPrevPage;
        private System.Windows.Forms.Button btnNextPage;
        private System.Windows.Forms.ComboBox comboBox1;
    }
}