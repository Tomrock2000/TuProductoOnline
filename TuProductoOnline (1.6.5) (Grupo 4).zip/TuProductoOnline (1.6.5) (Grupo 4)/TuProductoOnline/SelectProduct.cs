﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TuProductoOnline
{
    public partial class SelectProduct : Form
    {
        int pagecount = 0;
        int productsshowed = 0;
        Product producttosell = new Product();//Instanciamos un objeto producto que será nuestro producto a vender
        int cantitytosell = 0;//Instanciamos un int, que será la cantidad a vender
        public SelectProduct()
        {
            InitializeComponent();
            ProductLoad();
        }
        public static string GetProductsFromFile()
        {
            string productsJsonFromFile;
            using (var reader = new StreamReader(_pathproduct))
            {
                productsJsonFromFile = reader.ReadToEnd();
            }
            return productsJsonFromFile;
        }
        public void ProductLoad(string searchText = "")//Carga todos los productos a el dtgv
        {
            dtgvProducts.Rows.Clear();
            var productsFromFile = GetProductsFromFile();
            var products = JsonConvert.DeserializeObject<List<Product>>(productsFromFile);
            IEnumerable<Product> productslist = products.Where(product => product.Enabled == true).Skip(pagecount * 20).Take(20);

            productsshowed = (pagecount * 20) + 20;

            if (products != null)
            {
                foreach (Product product in productslist)
                {
                    if (product.Cantity == 0)
                    {
                        product.Enabled = false;
                    }

                    if (product.Enabled == true && product.Removed == false)
                    {
                        dtgvProducts.Rows.Add(product.Id, product.Name, product.Price, product.Type, product.Description, product.Cantity);

                    }
                }
            }
            if (searchText.Length > 2)
            {
                products = products.Where(x => x.Name.Contains(searchText)).ToList();
            }
        }
        private void dtgvProducts_CellClick(object sender, DataGridViewCellEventArgs e)//Permite obtener los datos de el producto en los txt
        {
            var productsFromFile = ProductManageMenu.GetProductsFromFile();
            var products = JsonConvert.DeserializeObject<List<Product>>(productsFromFile);

            int n = dtgvProducts.CurrentRow.Index;
            if (n != -1 && n != dtgvProducts.Rows.Count - 1)
            {
                if (dtgvProducts.Rows[n].Cells[3].Value.ToString() == "Hardware")
                {
                    txtMeassuresProduct.Show();
                    lblMeassuresProduct.Show();
                    txtModelProduct.Hide();
                    lblModelProduct.Hide();
                    txtLicenceProduct.Hide();
                    lblLicenceProduct.Hide();
                    txtVersionProduct.Hide();
                    lblVersionProduct.Hide();

                    foreach (Product product in products)
                    {
                        if (product.Id == dtgvProducts.Rows[n].Cells[0].Value.ToString())
                        {
                            txtIdProduct.Text = (string)dtgvProducts.Rows[n].Cells[0].Value;
                            txtNameProduct.Text = (string)dtgvProducts.Rows[n].Cells[1].Value;
                            txtPriceProduct.Text = dtgvProducts.Rows[n].Cells[2].Value.ToString();
                            txtTypeProduct.Text = (string)dtgvProducts.Rows[n].Cells[3].Value;
                            txtDescriptionProduct.Text = (string)dtgvProducts.Rows[n].Cells[4].Value;
                            txtCantityAvailableProduct.Text = dtgvProducts.Rows[n].Cells[5].Value.ToString();
                            txtMeassuresProduct.Text = product.Hard.Meassures.ToString();

                        }
                    }
                }

                if (dtgvProducts.Rows[n].Cells[3].Value.ToString() == "Software")
                {
                    txtMeassuresProduct.Hide();
                    lblMeassuresProduct.Hide();
                    txtModelProduct.Hide();
                    lblModelProduct.Hide();
                    txtLicenceProduct.Show();
                    lblLicenceProduct.Show();
                    txtVersionProduct.Show();
                    lblVersionProduct.Show();
                    foreach (Product product in products)
                    {
                        if (product.Id == dtgvProducts.Rows[n].Cells[0].Value.ToString())
                        {
                            txtIdProduct.Text = (string)dtgvProducts.Rows[n].Cells[0].Value;
                            txtNameProduct.Text = (string)dtgvProducts.Rows[n].Cells[1].Value;
                            txtPriceProduct.Text = dtgvProducts.Rows[n].Cells[2].Value.ToString();
                            txtTypeProduct.Text = (string)dtgvProducts.Rows[n].Cells[3].Value;
                            txtDescriptionProduct.Text = (string)dtgvProducts.Rows[n].Cells[4].Value;
                            txtCantityAvailableProduct.Text = dtgvProducts.Rows[n].Cells[5].Value.ToString();
                            txtLicenceProduct.Text = product.Soft.Licence.ToString();
                            txtVersionProduct.Text = product.Soft.Version.ToString();

                        }
                    }

                }
                if (dtgvProducts.Rows[n].Cells[3].Value.ToString() == "Device")
                {
                    txtMeassuresProduct.Hide();
                    lblMeassuresProduct.Hide();
                    txtModelProduct.Show();
                    lblModelProduct.Show();
                    txtLicenceProduct.Hide();
                    lblLicenceProduct.Hide();
                    txtVersionProduct.Hide();
                    lblVersionProduct.Hide();
                    foreach (Product product in products)
                    {
                        if (product.Id == dtgvProducts.Rows[n].Cells[0].Value.ToString())
                        {
                            txtIdProduct.Text = (string)dtgvProducts.Rows[n].Cells[0].Value;
                            txtNameProduct.Text = (string)dtgvProducts.Rows[n].Cells[1].Value;
                            txtPriceProduct.Text = dtgvProducts.Rows[n].Cells[2].Value.ToString();
                            txtTypeProduct.Text = (string)dtgvProducts.Rows[n].Cells[3].Value;
                            txtDescriptionProduct.Text = (string)dtgvProducts.Rows[n].Cells[4].Value;
                            txtCantityAvailableProduct.Text = dtgvProducts.Rows[n].Cells[5].Value.ToString();
                            txtModelProduct.Text = product.Devi.Model.ToString();

                        }
                    }
                }
            }
        }
        private static string _pathproduct = Path.GetFullPath(Path.Combine(Application.StartupPath, "..\\..", "Products.json"));
        private void btnSelectProduct_Click(object sender, EventArgs e)//Al presionar el botón de Seleccionar
        {
            
            if (int.Parse(txtCantityToSale.Text) > int.Parse(txtCantityAvailableProduct.Text))
            {
                MessageBox.Show("La cantidad introducida es mayor a la disponible");
                txtCantityToSale.Text = "1";
            }
            if (int.Parse(txtCantityToSale.Text) == 0)
            {
                MessageBox.Show("La cantidad introducida debe ser mayor a 0");

            }
            else
            {
                int n = dtgvProducts.CurrentRow.Index;
                var productsFromFile = ProductManageMenu.GetProductsFromFile();
                var products = JsonConvert.DeserializeObject<List<Product>>(productsFromFile);//Deserializamos el Json

                string tosell;//Este string será dónde guardaremos el id de el producto seleccionado
                if (n != -1 && n != dtgvProducts.Rows.Count - 1)
                {
                    tosell = (string)dtgvProducts.Rows[n].Cells[0].Value;//Asignamos el id producto seleccionado a el string to sell

                    foreach (Product product in products)
                    {
                        if (tosell == product.Id.ToString())//Compararemos con los productos en el Json y si la id coincide con algun producto de el Json
                        {
                            product.Cantity -= int.Parse(txtCantityToSale.Text);//A el producto le restará la cantidad ingresada en el txtCantityToSale
                            producttosell = product;// Aproducttosell(El objeto instanciado en un principio) se le asignara el valor de product(que será el producto que coincidió con la id)
                            cantitytosell = int.Parse(txtCantityToSale.Text);//A cantitytosale(La variable int instanciada en un principio) se le asignara el valor ingresado en el txtCantityToSale
                        }
                    }
                    string productsJson = JsonConvert.SerializeObject(products.ToArray(), Formatting.Indented);//Serializa para guardar los cambios
                    File.WriteAllText(_pathproduct, productsJson);
                }

                NewSaleMenu newsalemenu = new NewSaleMenu(); //Instanciamos un objeto NewSaleMenu 
                foreach (Form form in Application.OpenForms)//Buscaremos en cada form abierto en la aplicación
                {
                    if (form is NewSaleMenu)//Si el form es de tipo NewSaleMenu
                    {
                        newsalemenu = (NewSaleMenu)form;//Asignaremos a el objeto instanciado inicialmente el form encontrado en los forms abiertos
                        break;//Rompemos el ciclo
                    }
                }//De esta manera podemos referirnos a el form NewSaleMenu activo y podemos trabajar con él mediante newsalemenu
                //En la cual le enviaremos los datos que recibirá y aplicará en ese form

                newsalemenu.CarShopProducts(producttosell, cantitytosell);//Utilizamos la funcion establecida en NewSaleMenu
                newsalemenu.BillCheck();                                             //que recibe como parámetro el producto seleccionado en este form y la cantidad de ese producto
                ProductLoad();//Actualiza el dtgv

                producttosell = null;//Aquí vuelve a las instancias y a el txtCantityToSale, a valores iniciales para evitar problemas
                cantitytosell = 0;
                txtCantityToSale.Text = "0";

            }
        }
        private void btnPrevPage_Click(object sender, EventArgs e)
        {
            if (pagecount > 0)
            {
                pagecount--;
                ProductLoad();
            }

        }
        private void btnNextPage_Click(object sender, EventArgs e)
        {
            var productsfromfile = ProductManageMenu.GetProductsFromFile();
            var products = JsonConvert.DeserializeObject<List<Product>>(productsfromfile);
            if (productsshowed < products.Count)
            {
                pagecount++;
                ProductLoad();
            }
        }

        private void txtCantityToSale_TextChanged(object sender, EventArgs e)//Verifica que la cantidad sea correcta
        {
            SelectProductChecker();
        }

        private void txtCantityToSale_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        public void SelectProductChecker()
        {
            if (txtTypeProduct.Text=="Device")
            {
                if (txtNameProduct.Text != string.Empty && txtDescriptionProduct.Text != string.Empty && txtCantityAvailableProduct.Text != string.Empty && txtPriceProduct.Text != string.Empty && txtModelProduct.Text != string.Empty && txtCantityToSale.Text!=string.Empty)
                {
                    btnSelectProduct.Enabled = true;
                }
                else { btnSelectProduct.Enabled = false; }
            }
            if (txtTypeProduct.Text== "Hardware")
            {
                if (txtNameProduct.Text != string.Empty && txtDescriptionProduct.Text != string.Empty && txtCantityAvailableProduct.Text != string.Empty && txtPriceProduct.Text != string.Empty && txtMeassuresProduct.Text != string.Empty && txtCantityToSale.Text != string.Empty)
                {
                    btnSelectProduct.Enabled = true;
                }
                else { btnSelectProduct.Enabled = false; }
            }
            if (txtTypeProduct.Text == "Software")
            {
                if (txtNameProduct.Text != string.Empty && txtDescriptionProduct.Text != string.Empty && txtCantityAvailableProduct.Text != string.Empty && txtPriceProduct.Text != string.Empty && txtVersionProduct.Text != string.Empty && txtLicenceProduct.Text != string.Empty && txtCantityToSale.Text != string.Empty)
                {
                    btnSelectProduct.Enabled = true;
                }
                else { btnSelectProduct.Enabled = false; }
            }
        }

        private void txtNameProduct_TextChanged(object sender, EventArgs e)
        {
            SelectProductChecker();
        }
        int m, mx, my;
        private void pnlTopBorder_MouseDown(object sender, MouseEventArgs e)
        {
            m = 1;
            mx = e.X;
            my = e.Y;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string searchText = textBox1.Text.ToLower();

            int columnIndex = dtgvProducts.Columns["ProductName"].Index;

            try
            {

                ProductLoad(searchText);

                if (searchText.Length < 2)
                {
                    return;
                }


                foreach (DataGridViewRow row in dtgvProducts.Rows)
                {

                    bool found = false;

                    DataGridViewCell cell = row.Cells[columnIndex];



                    if (cell.Value != null && cell.Value.ToString().ToLower().Contains(searchText))
                    {
                        found = true;
                    }
                    row.Visible = found;
                }
            }
            catch (Exception a)
            {

            }
        }

        private void textBox1_MouseClick(object sender, MouseEventArgs e)
        {
            textBox1.Text = "";
        }


        List<Product> OrdenarLista(string campo)
        {

            var productsfromfile = ProductManageMenu.GetProductsFromFile();
            var products = JsonConvert.DeserializeObject<List<Product>>(productsfromfile);


            switch (campo)
            {
                case "Nombre":
                    return products.OrderBy(p => p.Name).ToList();
                case "Cedula":
                    return products.OrderBy(p => p.Id).ToList();
                default:
                    return products;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtgvProducts.Rows.Clear();

            string campo = comboBox1.SelectedItem.ToString();

            List<Product> orderedroducts = OrdenarLista(campo);

            if (orderedroducts != null)
            {
                foreach (Product product in orderedroducts)
                {
                    if (product.Enabled == true && product.Removed == false)
                    {
                        dtgvProducts.Rows.Add(product.Id, product.Name, product.Price, product.Type, product.Description, product.Cantity);

                    }
                }


            }
        }

        private void pnlTopBorder_MouseMove(object sender, MouseEventArgs e)
        {
            if (m == 1)
            {
                this.SetDesktopLocation(MousePosition.X - mx, MousePosition.Y - my);
            }
        }

        private void pnlTopBorder_MouseUp(object sender, MouseEventArgs e)
        {
            m = 0;
        }
    }
}
