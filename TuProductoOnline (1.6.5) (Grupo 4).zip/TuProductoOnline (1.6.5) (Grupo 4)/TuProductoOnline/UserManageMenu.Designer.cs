﻿namespace TuProductoOnline
{
    partial class UserManageMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UserManageMenu));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btnAddUser = new System.Windows.Forms.Button();
            this.tbSearchUser = new System.Windows.Forms.TextBox();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.dtgvUsers = new System.Windows.Forms.DataGridView();
            this.UsersName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LastnameUsers = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IdUsers = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PhoneUsers = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AdressUsers = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UsersNameCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PassowordUsers = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ModifyUser = new System.Windows.Forms.DataGridViewButtonColumn();
            this.DeleteUser = new System.Windows.Forms.DataGridViewButtonColumn();
            this.btnPrevPage = new System.Windows.Forms.Button();
            this.btnNextPage = new System.Windows.Forms.Button();
            this.pnlSudMenu = new System.Windows.Forms.Panel();
            this.btnExport = new System.Windows.Forms.Button();
            this.btnImport = new System.Windows.Forms.Button();
            this.btnExportImport = new System.Windows.Forms.Button();
            this.pbTitleFrame = new System.Windows.Forms.PictureBox();
            this.pbSearch = new System.Windows.Forms.PictureBox();
            this.pbMenuIcon = new System.Windows.Forms.PictureBox();
            this.pbIconFrame = new System.Windows.Forms.PictureBox();
            this.btnChangeToAdmins = new System.Windows.Forms.Button();
            this.btnChangeToUsers = new System.Windows.Forms.Button();
            this.tbSearchAdmin = new System.Windows.Forms.TextBox();
            this.dtgvAdmins = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewButtonColumn1 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.dataGridViewButtonColumn2 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvUsers)).BeginInit();
            this.pnlSudMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbTitleFrame)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSearch)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMenuIcon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbIconFrame)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvAdmins)).BeginInit();
            this.SuspendLayout();
            // 
            // btnAddUser
            // 
            this.btnAddUser.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnAddUser.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.btnAddUser.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddUser.FlatAppearance.BorderSize = 0;
            this.btnAddUser.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(73)))), ((int)(((byte)(73)))));
            this.btnAddUser.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddUser.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.btnAddUser.Image = ((System.Drawing.Image)(resources.GetObject("btnAddUser.Image")));
            this.btnAddUser.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAddUser.Location = new System.Drawing.Point(677, 105);
            this.btnAddUser.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAddUser.Name = "btnAddUser";
            this.btnAddUser.Size = new System.Drawing.Size(198, 48);
            this.btnAddUser.TabIndex = 47;
            this.btnAddUser.Text = "Agregar Usuario";
            this.btnAddUser.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAddUser.UseVisualStyleBackColor = false;
            this.btnAddUser.Click += new System.EventHandler(this.btnAddUser_Click);
            // 
            // tbSearchUser
            // 
            this.tbSearchUser.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tbSearchUser.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.tbSearchUser.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbSearchUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold);
            this.tbSearchUser.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.tbSearchUser.Location = new System.Drawing.Point(128, 117);
            this.tbSearchUser.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.tbSearchUser.Name = "tbSearchUser";
            this.tbSearchUser.Size = new System.Drawing.Size(542, 35);
            this.tbSearchUser.TabIndex = 46;
            this.tbSearchUser.Text = "Buscar...";
            this.tbSearchUser.MouseClick += new System.Windows.Forms.MouseEventHandler(this.tbSearchUser_MouseClick);
            this.tbSearchUser.TextChanged += new System.EventHandler(this.tbSearchUser_TextChanged);
            // 
            // lblWelcome
            // 
            this.lblWelcome.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.BackColor = System.Drawing.Color.Transparent;
            this.lblWelcome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblWelcome.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold);
            this.lblWelcome.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblWelcome.Location = new System.Drawing.Point(375, 24);
            this.lblWelcome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(250, 29);
            this.lblWelcome.TabIndex = 45;
            this.lblWelcome.Text = "Gestión de Usuarios";
            this.lblWelcome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dtgvUsers
            // 
            this.dtgvUsers.AllowUserToAddRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvUsers.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dtgvUsers.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dtgvUsers.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.dtgvUsers.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dtgvUsers.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dtgvUsers.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvUsers.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dtgvUsers.ColumnHeadersHeight = 38;
            this.dtgvUsers.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.UsersName,
            this.LastnameUsers,
            this.IdUsers,
            this.PhoneUsers,
            this.AdressUsers,
            this.UsersNameCode,
            this.PassowordUsers,
            this.ModifyUser,
            this.DeleteUser});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dtgvUsers.DefaultCellStyle = dataGridViewCellStyle3;
            this.dtgvUsers.EnableHeadersVisualStyles = false;
            this.dtgvUsers.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.dtgvUsers.Location = new System.Drawing.Point(128, 158);
            this.dtgvUsers.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dtgvUsers.Name = "dtgvUsers";
            this.dtgvUsers.ReadOnly = true;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvUsers.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dtgvUsers.RowHeadersVisible = false;
            this.dtgvUsers.RowHeadersWidth = 51;
            this.dtgvUsers.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dtgvUsers.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.dtgvUsers.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtgvUsers.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.dtgvUsers.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            this.dtgvUsers.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.dtgvUsers.RowTemplate.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvUsers.RowTemplate.Height = 35;
            this.dtgvUsers.Size = new System.Drawing.Size(747, 312);
            this.dtgvUsers.TabIndex = 50;
            this.dtgvUsers.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgvUsers_CellContentClick);
            this.dtgvUsers.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.dtgvUsers_CellPainting);
            // 
            // UsersName
            // 
            this.UsersName.HeaderText = "Nombre ";
            this.UsersName.MinimumWidth = 6;
            this.UsersName.Name = "UsersName";
            this.UsersName.ReadOnly = true;
            this.UsersName.Width = 125;
            // 
            // LastnameUsers
            // 
            this.LastnameUsers.HeaderText = "Apellido ";
            this.LastnameUsers.MinimumWidth = 6;
            this.LastnameUsers.Name = "LastnameUsers";
            this.LastnameUsers.ReadOnly = true;
            this.LastnameUsers.Width = 125;
            // 
            // IdUsers
            // 
            this.IdUsers.HeaderText = "Cédula ";
            this.IdUsers.MinimumWidth = 6;
            this.IdUsers.Name = "IdUsers";
            this.IdUsers.ReadOnly = true;
            this.IdUsers.Width = 125;
            // 
            // PhoneUsers
            // 
            this.PhoneUsers.HeaderText = "Teléfono";
            this.PhoneUsers.MinimumWidth = 6;
            this.PhoneUsers.Name = "PhoneUsers";
            this.PhoneUsers.ReadOnly = true;
            this.PhoneUsers.Width = 125;
            // 
            // AdressUsers
            // 
            this.AdressUsers.HeaderText = "Dirección ";
            this.AdressUsers.MinimumWidth = 6;
            this.AdressUsers.Name = "AdressUsers";
            this.AdressUsers.ReadOnly = true;
            this.AdressUsers.Width = 125;
            // 
            // UsersNameCode
            // 
            this.UsersNameCode.HeaderText = "Nombre del Usuario";
            this.UsersNameCode.MinimumWidth = 6;
            this.UsersNameCode.Name = "UsersNameCode";
            this.UsersNameCode.ReadOnly = true;
            this.UsersNameCode.Width = 125;
            // 
            // PassowordUsers
            // 
            this.PassowordUsers.HeaderText = "Contraseña";
            this.PassowordUsers.MinimumWidth = 6;
            this.PassowordUsers.Name = "PassowordUsers";
            this.PassowordUsers.ReadOnly = true;
            this.PassowordUsers.Width = 125;
            // 
            // ModifyUser
            // 
            this.ModifyUser.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ModifyUser.HeaderText = "Modificar Usuario";
            this.ModifyUser.MinimumWidth = 6;
            this.ModifyUser.Name = "ModifyUser";
            this.ModifyUser.ReadOnly = true;
            this.ModifyUser.Width = 125;
            // 
            // DeleteUser
            // 
            this.DeleteUser.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DeleteUser.HeaderText = "Eliminar Usuario";
            this.DeleteUser.MinimumWidth = 6;
            this.DeleteUser.Name = "DeleteUser";
            this.DeleteUser.ReadOnly = true;
            this.DeleteUser.Width = 125;
            // 
            // btnPrevPage
            // 
            this.btnPrevPage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.btnPrevPage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPrevPage.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold);
            this.btnPrevPage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.btnPrevPage.Location = new System.Drawing.Point(426, 476);
            this.btnPrevPage.Name = "btnPrevPage";
            this.btnPrevPage.Size = new System.Drawing.Size(71, 38);
            this.btnPrevPage.TabIndex = 76;
            this.btnPrevPage.Text = "Pág Anterior";
            this.btnPrevPage.UseVisualStyleBackColor = false;
            this.btnPrevPage.Click += new System.EventHandler(this.btnPrevPage_Click);
            // 
            // btnNextPage
            // 
            this.btnNextPage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.btnNextPage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNextPage.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold);
            this.btnNextPage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.btnNextPage.Location = new System.Drawing.Point(503, 476);
            this.btnNextPage.Name = "btnNextPage";
            this.btnNextPage.Size = new System.Drawing.Size(71, 38);
            this.btnNextPage.TabIndex = 75;
            this.btnNextPage.Text = "Pág Siguiente";
            this.btnNextPage.UseVisualStyleBackColor = false;
            this.btnNextPage.Click += new System.EventHandler(this.btnNextPage_Click);
            // 
            // pnlSudMenu
            // 
            this.pnlSudMenu.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pnlSudMenu.AutoScroll = true;
            this.pnlSudMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.pnlSudMenu.Controls.Add(this.btnExport);
            this.pnlSudMenu.Controls.Add(this.btnImport);
            this.pnlSudMenu.Location = new System.Drawing.Point(12, 40);
            this.pnlSudMenu.Name = "pnlSudMenu";
            this.pnlSudMenu.Size = new System.Drawing.Size(66, 144);
            this.pnlSudMenu.TabIndex = 80;
            // 
            // btnExport
            // 
            this.btnExport.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.btnExport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExport.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnExport.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.btnExport.Image = global::TuProductoOnline.Properties.Resources.Icono_Exportar1;
            this.btnExport.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnExport.Location = new System.Drawing.Point(0, 73);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(66, 68);
            this.btnExport.TabIndex = 1;
            this.btnExport.Text = "Exportar";
            this.btnExport.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnExport.UseVisualStyleBackColor = false;
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            // 
            // btnImport
            // 
            this.btnImport.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.btnImport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnImport.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnImport.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.btnImport.Image = global::TuProductoOnline.Properties.Resources.Icono_Importar;
            this.btnImport.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnImport.Location = new System.Drawing.Point(0, 3);
            this.btnImport.Name = "btnImport";
            this.btnImport.Size = new System.Drawing.Size(66, 68);
            this.btnImport.TabIndex = 0;
            this.btnImport.Text = "Importar";
            this.btnImport.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnImport.UseVisualStyleBackColor = false;
            this.btnImport.Click += new System.EventHandler(this.btnImport_Click);
            // 
            // btnExportImport
            // 
            this.btnExportImport.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnExportImport.FlatAppearance.BorderSize = 0;
            this.btnExportImport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExportImport.Location = new System.Drawing.Point(12, 12);
            this.btnExportImport.Name = "btnExportImport";
            this.btnExportImport.Size = new System.Drawing.Size(60, 30);
            this.btnExportImport.TabIndex = 79;
            this.btnExportImport.Text = "°°°";
            this.btnExportImport.UseVisualStyleBackColor = true;
            this.btnExportImport.Click += new System.EventHandler(this.btnExportImport_Click);
            // 
            // pbTitleFrame
            // 
            this.pbTitleFrame.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pbTitleFrame.BackColor = System.Drawing.Color.Transparent;
            this.pbTitleFrame.Image = global::TuProductoOnline.Properties.Resources.Marco_de_Widgets;
            this.pbTitleFrame.Location = new System.Drawing.Point(360, 12);
            this.pbTitleFrame.Name = "pbTitleFrame";
            this.pbTitleFrame.Size = new System.Drawing.Size(281, 55);
            this.pbTitleFrame.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbTitleFrame.TabIndex = 81;
            this.pbTitleFrame.TabStop = false;
            // 
            // pbSearch
            // 
            this.pbSearch.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pbSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.pbSearch.Image = global::TuProductoOnline.Properties.Resources.Lupa1;
            this.pbSearch.Location = new System.Drawing.Point(636, 118);
            this.pbSearch.Name = "pbSearch";
            this.pbSearch.Size = new System.Drawing.Size(32, 32);
            this.pbSearch.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSearch.TabIndex = 82;
            this.pbSearch.TabStop = false;
            // 
            // pbMenuIcon
            // 
            this.pbMenuIcon.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pbMenuIcon.BackColor = System.Drawing.Color.Transparent;
            this.pbMenuIcon.Image = global::TuProductoOnline.Properties.Resources.Icono_Gestión_de_Usuarios1;
            this.pbMenuIcon.Location = new System.Drawing.Point(917, 5);
            this.pbMenuIcon.Name = "pbMenuIcon";
            this.pbMenuIcon.Size = new System.Drawing.Size(110, 102);
            this.pbMenuIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbMenuIcon.TabIndex = 88;
            this.pbMenuIcon.TabStop = false;
            // 
            // pbIconFrame
            // 
            this.pbIconFrame.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pbIconFrame.BackColor = System.Drawing.Color.Transparent;
            this.pbIconFrame.Image = global::TuProductoOnline.Properties.Resources.Marco_de_Widgets;
            this.pbIconFrame.Location = new System.Drawing.Point(914, 0);
            this.pbIconFrame.Name = "pbIconFrame";
            this.pbIconFrame.Size = new System.Drawing.Size(117, 112);
            this.pbIconFrame.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbIconFrame.TabIndex = 87;
            this.pbIconFrame.TabStop = false;
            // 
            // btnChangeToAdmins
            // 
            this.btnChangeToAdmins.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnChangeToAdmins.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.btnChangeToAdmins.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnChangeToAdmins.FlatAppearance.BorderSize = 0;
            this.btnChangeToAdmins.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(73)))), ((int)(((byte)(73)))));
            this.btnChangeToAdmins.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnChangeToAdmins.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChangeToAdmins.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.btnChangeToAdmins.Image = ((System.Drawing.Image)(resources.GetObject("btnChangeToAdmins.Image")));
            this.btnChangeToAdmins.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnChangeToAdmins.Location = new System.Drawing.Point(128, 476);
            this.btnChangeToAdmins.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnChangeToAdmins.Name = "btnChangeToAdmins";
            this.btnChangeToAdmins.Size = new System.Drawing.Size(198, 48);
            this.btnChangeToAdmins.TabIndex = 89;
            this.btnChangeToAdmins.Text = "Mostrar Administradores";
            this.btnChangeToAdmins.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnChangeToAdmins.UseVisualStyleBackColor = false;
            this.btnChangeToAdmins.Visible = false;
            this.btnChangeToAdmins.Click += new System.EventHandler(this.btnChangeToAdmins_Click);
            // 
            // btnChangeToUsers
            // 
            this.btnChangeToUsers.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnChangeToUsers.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.btnChangeToUsers.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnChangeToUsers.FlatAppearance.BorderSize = 0;
            this.btnChangeToUsers.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(73)))), ((int)(((byte)(73)))));
            this.btnChangeToUsers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnChangeToUsers.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChangeToUsers.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.btnChangeToUsers.Image = ((System.Drawing.Image)(resources.GetObject("btnChangeToUsers.Image")));
            this.btnChangeToUsers.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnChangeToUsers.Location = new System.Drawing.Point(677, 476);
            this.btnChangeToUsers.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnChangeToUsers.Name = "btnChangeToUsers";
            this.btnChangeToUsers.Size = new System.Drawing.Size(198, 48);
            this.btnChangeToUsers.TabIndex = 90;
            this.btnChangeToUsers.Text = "Mostrar Usuarios";
            this.btnChangeToUsers.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnChangeToUsers.UseVisualStyleBackColor = false;
            this.btnChangeToUsers.Visible = false;
            this.btnChangeToUsers.Click += new System.EventHandler(this.btnChangeToUsers_Click);
            // 
            // tbSearchAdmin
            // 
            this.tbSearchAdmin.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tbSearchAdmin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.tbSearchAdmin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbSearchAdmin.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold);
            this.tbSearchAdmin.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.tbSearchAdmin.Location = new System.Drawing.Point(128, 117);
            this.tbSearchAdmin.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.tbSearchAdmin.Name = "tbSearchAdmin";
            this.tbSearchAdmin.Size = new System.Drawing.Size(542, 35);
            this.tbSearchAdmin.TabIndex = 91;
            this.tbSearchAdmin.Text = "Buscar...";
            this.tbSearchAdmin.Visible = false;
            this.tbSearchAdmin.TextChanged += new System.EventHandler(this.SearchAdmin_TextChanged);
            // 
            // dtgvAdmins
            // 
            this.dtgvAdmins.AllowUserToAddRows = false;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvAdmins.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dtgvAdmins.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dtgvAdmins.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.dtgvAdmins.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dtgvAdmins.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dtgvAdmins.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvAdmins.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dtgvAdmins.ColumnHeadersHeight = 38;
            this.dtgvAdmins.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewButtonColumn1,
            this.dataGridViewButtonColumn2});
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dtgvAdmins.DefaultCellStyle = dataGridViewCellStyle7;
            this.dtgvAdmins.EnableHeadersVisualStyles = false;
            this.dtgvAdmins.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.dtgvAdmins.Location = new System.Drawing.Point(128, 158);
            this.dtgvAdmins.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dtgvAdmins.Name = "dtgvAdmins";
            this.dtgvAdmins.ReadOnly = true;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvAdmins.RowHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.dtgvAdmins.RowHeadersVisible = false;
            this.dtgvAdmins.RowHeadersWidth = 51;
            this.dtgvAdmins.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dtgvAdmins.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.dtgvAdmins.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtgvAdmins.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.dtgvAdmins.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(87)))), ((int)(((byte)(87)))));
            this.dtgvAdmins.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.dtgvAdmins.RowTemplate.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvAdmins.RowTemplate.Height = 35;
            this.dtgvAdmins.Size = new System.Drawing.Size(747, 312);
            this.dtgvAdmins.TabIndex = 92;
            this.dtgvAdmins.Visible = false;
            this.dtgvAdmins.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgvAdmins_CellContentClick);
            this.dtgvAdmins.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.dtgvUsers_CellPainting);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "Nombre ";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 125;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "Apellido ";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 125;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "Cédula ";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 125;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.HeaderText = "Teléfono";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 125;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.HeaderText = "Dirección ";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Width = 125;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.HeaderText = "Nombre del Usuario";
            this.dataGridViewTextBoxColumn6.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Width = 125;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.HeaderText = "Contraseña";
            this.dataGridViewTextBoxColumn7.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.Width = 125;
            // 
            // dataGridViewButtonColumn1
            // 
            this.dataGridViewButtonColumn1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.dataGridViewButtonColumn1.HeaderText = "Modificar Admin";
            this.dataGridViewButtonColumn1.MinimumWidth = 6;
            this.dataGridViewButtonColumn1.Name = "dataGridViewButtonColumn1";
            this.dataGridViewButtonColumn1.ReadOnly = true;
            this.dataGridViewButtonColumn1.Width = 125;
            // 
            // dataGridViewButtonColumn2
            // 
            this.dataGridViewButtonColumn2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.dataGridViewButtonColumn2.HeaderText = "Eliminar Admin";
            this.dataGridViewButtonColumn2.MinimumWidth = 6;
            this.dataGridViewButtonColumn2.Name = "dataGridViewButtonColumn2";
            this.dataGridViewButtonColumn2.ReadOnly = true;
            this.dataGridViewButtonColumn2.Width = 125;
            // 
            // comboBox1
            // 
            this.comboBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.comboBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(103)))), ((int)(((byte)(248)))));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Cedula",
            "Nombre"});
            this.comboBox1.Location = new System.Drawing.Point(127, 81);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 28);
            this.comboBox1.TabIndex = 93;
            this.comboBox1.Text = "Ordenar por:";
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // UserManageMenu
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(234)))), ((int)(((byte)(199)))));
            this.ClientSize = new System.Drawing.Size(1030, 560);
            this.Controls.Add(this.pbSearch);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.dtgvAdmins);
            this.Controls.Add(this.tbSearchAdmin);
            this.Controls.Add(this.btnChangeToUsers);
            this.Controls.Add(this.btnChangeToAdmins);
            this.Controls.Add(this.pbMenuIcon);
            this.Controls.Add(this.pbIconFrame);
            this.Controls.Add(this.pnlSudMenu);
            this.Controls.Add(this.btnExportImport);
            this.Controls.Add(this.btnPrevPage);
            this.Controls.Add(this.btnNextPage);
            this.Controls.Add(this.dtgvUsers);
            this.Controls.Add(this.btnAddUser);
            this.Controls.Add(this.tbSearchUser);
            this.Controls.Add(this.lblWelcome);
            this.Controls.Add(this.pbTitleFrame);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "UserManageMenu";
            this.Text = "UserManageMenu";
            this.Activated += new System.EventHandler(this.UserManageMenu_Activated);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvUsers)).EndInit();
            this.pnlSudMenu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbTitleFrame)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSearch)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMenuIcon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbIconFrame)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvAdmins)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnAddUser;
        private System.Windows.Forms.TextBox tbSearchUser;
        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.DataGridView dtgvUsers;
        private System.Windows.Forms.Button btnPrevPage;
        private System.Windows.Forms.Button btnNextPage;
        private System.Windows.Forms.Panel pnlSudMenu;
        private System.Windows.Forms.Button btnExport;
        private System.Windows.Forms.Button btnImport;
        private System.Windows.Forms.Button btnExportImport;
        private System.Windows.Forms.PictureBox pbTitleFrame;
        private System.Windows.Forms.PictureBox pbSearch;
        private System.Windows.Forms.PictureBox pbMenuIcon;
        private System.Windows.Forms.PictureBox pbIconFrame;
        private System.Windows.Forms.DataGridViewTextBoxColumn UsersName;
        private System.Windows.Forms.DataGridViewTextBoxColumn LastnameUsers;
        private System.Windows.Forms.DataGridViewTextBoxColumn IdUsers;
        private System.Windows.Forms.DataGridViewTextBoxColumn PhoneUsers;
        private System.Windows.Forms.DataGridViewTextBoxColumn AdressUsers;
        private System.Windows.Forms.DataGridViewTextBoxColumn UsersNameCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn PassowordUsers;
        private System.Windows.Forms.DataGridViewButtonColumn ModifyUser;
        private System.Windows.Forms.DataGridViewButtonColumn DeleteUser;
        private System.Windows.Forms.Button btnChangeToAdmins;
        private System.Windows.Forms.Button btnChangeToUsers;
        private System.Windows.Forms.TextBox tbSearchAdmin;
        private System.Windows.Forms.DataGridView dtgvAdmins;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewButtonColumn dataGridViewButtonColumn1;
        private System.Windows.Forms.DataGridViewButtonColumn dataGridViewButtonColumn2;
        private System.Windows.Forms.ComboBox comboBox1;
    }
}