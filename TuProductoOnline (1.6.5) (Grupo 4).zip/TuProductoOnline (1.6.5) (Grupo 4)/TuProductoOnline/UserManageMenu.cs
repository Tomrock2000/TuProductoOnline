﻿using CsvHelper;
using CsvHelper.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace TuProductoOnline
{
    public partial class UserManageMenu : Form
    {
        int pagecount = 0;
        int usersshowed = 0;
        bool modifyadmin = false;
        public UserManageMenu()
        {
            InitializeComponent();
            cumtomizeMenuDesigner();
            this.Click += new EventHandler(MainForm_Click);
            UsersLoad();
            CheckIfSuperUser();
        }
        public static string _pathadmin = Path.GetFullPath(Path.Combine(Application.StartupPath, "..\\..", "Admins.json"));
        public static string GetAdminsFromFile()//Este metodo lee el json y lo guarda en una variable
        {
            string adminsJsonfromFile;//Declara la variable en la que se guardará el json
            using (var reader = new StreamReader(_pathadmin))//Mediante el lector, se leerá todo el json y lo guardará en la variable
            {
                adminsJsonfromFile = reader.ReadToEnd();
            }
            return adminsJsonfromFile;//Devuelve el valor de la variable, que sería la lectura del json
        }
        private void CheckIfSuperUser()
        {
            bool isUserOrAdmin = false;
            var usersFromFile = GetUsersFromFile();
            var users = JsonConvert.DeserializeObject<List<Employee>>(usersFromFile);
            var adminsfromfile = GetAdminsFromFile();//Aplica el metodo antes mencionado
            var admins = JsonConvert.DeserializeObject<List<Admin>>(adminsfromfile);

            if (admins != null)
            {
                foreach (Admin admin in admins)
                {
                    if (admin.ActiveSession == true)
                    {
                        isUserOrAdmin = true;
                    }
                }
            }
            if (users != null)
            {
                foreach (Employee user in users)
                {
                    if (user.ActiveSession == true)
                    {
                        isUserOrAdmin = true;
                    }
                }
            }
            if (isUserOrAdmin == false)
            {
                btnChangeToAdmins.Visible = true;

            }
        }
    
        
        private void btnAddUser_Click(object sender, EventArgs e)
        {
            AddUsers formaddusers = new AddUsers(modifyadmin);
            formaddusers.ShowDialog();
        }
        
        private static string _pathusers = Path.GetFullPath(Path.Combine(Application.StartupPath, "..\\..", "Users.json"));
        private static string GetUsersFromFile()
        {
            string UsersJsonFromFile;
            using (var reader = new StreamReader(_pathusers))
            {
                UsersJsonFromFile = reader.ReadToEnd();
            }
            return UsersJsonFromFile;
        }

        public void UsersLoad(string searchText = "")
        {
            dtgvUsers.Rows.Clear();
            var usersFromFile = GetUsersFromFile();
            var users = JsonConvert.DeserializeObject<List<Employee>>(usersFromFile);
            IEnumerable<Employee>userslist = users.Where(user => user.Enabled == true).Skip(pagecount * 20).Take(20);

            usersshowed = (pagecount * 5) + 5;
            if (users != null)
            {
                foreach (Employee employee in userslist)
                {
                    if (employee.Enabled == true)
                    {
                        dtgvUsers.Rows.Add(employee.Name, employee.LastName, employee.Id, employee.Phone, employee.Address, employee.User, employee.Password);

                    }
                }
            }
            if (searchText.Length > 2)
            {

                users = users.Where(x => x.Name.Contains(searchText)).ToList();

            }
        }

        private void tbSearchUser_TextChanged(object sender, EventArgs e)
        {
            string searchText = tbSearchUser.Text.ToLower();

            int columnIndex = dtgvUsers.Columns["UsersName"].Index;

            try
            {

                UsersLoad(searchText);

                if (searchText.Length < 2)
                {
                    return;
                }

                foreach (DataGridViewRow row in dtgvUsers.Rows)
                {

                    bool found = false;

                    DataGridViewCell cell = row.Cells[columnIndex];



                    if (cell.Value != null && cell.Value.ToString().ToLower().Contains(searchText))
                    {
                        found = true;
                    }
                    row.Visible = found;
                }
            }
            catch (Exception a)
            {

            }
        }

        private void dtgvUsers_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            var usersFromFile = GetUsersFromFile();
            var users = JsonConvert.DeserializeObject<List<Employee>>(usersFromFile);
            if (e.ColumnIndex == 7)
            {
                Employee tomodify = new Employee();
                long idtocompare = (long)dtgvUsers.Rows[e.RowIndex].Cells[2].Value;
                
                foreach (Employee user in users)
                {
                    if (idtocompare == user.Id)
                    {
                        tomodify = user;
                        break;
                    }
                }
                Admin adnull = new Admin();
                ModifyUsers modifyuser = new ModifyUsers(adnull,tomodify);
                modifyuser.ShowDialog();
            }
            if (e.ColumnIndex == 8)
            {
                
                string username = dtgvUsers.Rows[e.RowIndex].Cells[0].Value.ToString()+" "+dtgvUsers.Rows[e.RowIndex].Cells[1].Value.ToString();
                DialogResult result1 = MessageBox.Show($"¿Esta seguro que desea eliminar {username}?", "Confirmación", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result1 == DialogResult.Yes)
                {
                    int n = e.RowIndex;

                    long todelete;
                    
                        todelete = (long)dtgvUsers.Rows[n].Cells[2].Value;

                        foreach (Employee user in users)
                        {
                            if (todelete == user.Id)
                            {
                                user.Enabled = false;
                                break;
                            }
                        }
                    
                    string userslist = JsonConvert.SerializeObject(users.ToArray(), Formatting.Indented);
                    File.WriteAllText(_pathusers, userslist);
                    MessageBox.Show("El Usuario ha sido eliminado exitosamente");
                    UsersLoad();
                }
            }
        }
        private void dtgvUsers_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)//Asignar evento CellPainting
        {
            if (e.ColumnIndex >= 0 && this.dtgvUsers.Columns[e.ColumnIndex].Name == "DeleteUser" && e.RowIndex >= 0)//Recordar cambiar el nombre de el dtgv correspondiente y tambien cambiar el nombre de la columna correspondiente
                                                                                                                    //Ya sea DeleteUser, Delete Client o DeleteProduct
            {
                e.Paint(e.CellBounds, DataGridViewPaintParts.All);

                var celula = this.dtgvUsers.Rows[e.RowIndex].Cells[e.ColumnIndex];
                var imagen = Properties.Resources.Eliminar; 

                var x = e.CellBounds.Left + (e.CellBounds.Width - imagen.Width) / 2;
                var y = e.CellBounds.Top + (e.CellBounds.Height - imagen.Height) / 2;

                e.Graphics.DrawImage(imagen, new Point(x, y));
                e.Handled = true;
            }
            if (e.ColumnIndex >= 0 && this.dtgvUsers.Columns[e.ColumnIndex].Name == "ModifyUser" && e.RowIndex >= 0)                                                                                                                
            {
                e.Paint(e.CellBounds, DataGridViewPaintParts.All);

                var celula = this.dtgvUsers.Rows[e.RowIndex].Cells[e.ColumnIndex];
                var imagen = Properties.Resources.Modificar; 

                var x = e.CellBounds.Left + (e.CellBounds.Width - imagen.Width) / 2;
                var y = e.CellBounds.Top + (e.CellBounds.Height - imagen.Height) / 2;

                e.Graphics.DrawImage(imagen, new Point(x, y));
                e.Handled = true;
            }
        }
        private void btnPrevPage_Click(object sender, EventArgs e)
        {
            if (pagecount > 0)
            {
                pagecount--;
            }
            UsersLoad();
        }

        private void btnNextPage_Click(object sender, EventArgs e)
        {
            var usersFromFile = GetUsersFromFile();
            var users = JsonConvert.DeserializeObject<List<Employee>>(usersFromFile);

            if (usersshowed < users.Count)
            {
                pagecount++;
                UsersLoad();
            }
        }

        private void UserManageMenu_Activated(object sender, EventArgs e)
        {
            UsersLoad();
        }

        //Inicio sud menu
        private void cumtomizeMenuDesigner()    // es un poco inecesario esta parte porque desde los 
        {                                       //Componentes del control se puede especificar pero es mejor
            pnlSudMenu.Visible = false;         //Hacerlo asi por si queremos modificar especificamente la interfaz
        }

        private void hideSudmenu()
        {
            if (pnlSudMenu.Visible == true)
            {
                pnlSudMenu.Visible = false;
            }
        }

        private void showSudMenu(Panel sudmenu)
        {
            if (sudmenu.Visible == false)
            {
                hideSudmenu();
                sudmenu.Visible = true;
            }
            else
            {
                sudmenu.Visible = false;
            }
        }

        private void btnExportImport_Click(object sender, EventArgs e)
        {
            showSudMenu(pnlSudMenu);
        }

        private void MainForm_Click(object sender, EventArgs e)            //es un pequeño codigo para hacer que se oculte el sud menu si se toca el fondo 
        {
            if (pnlSudMenu.Visible == true && !pnlSudMenu.ClientRectangle.Contains(PointToClient(Cursor.Position)))
            {
                hideSudmenu();
            }
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            //// Abre un diálogo de archivo para que el usuario seleccione la ubicación del archivo CSV de salida
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Archivos CSV (*.csv)|*.csv";
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                // Lee el archivo JSON existente y convierte los datos a una lista de Employee
                var json = GetUsersFromFile();
                List<Employee> employees = JsonConvert.DeserializeObject<List<Employee>>(json);

                // Convierte la lista de Employee a una lista de UsersCSV
                List<UsersCSV> usersCsv = new List<UsersCSV>();

                foreach (var employee in employees)
                {
                    UsersCSV userCsv = new UsersCSV
                    {
                        Id = employee.Id,
                        Name = employee.Name,
                        LastName = employee.LastName,
                        Phone = employee.Phone,
                        Address = employee.Address,
                        Enabled = employee.Enabled,
                        User = employee.User,
                        Password = employee.Password,
                        ActiveSession = employee.ActiveSession,
                        ConcludedSales = employee.ConcludedSales,
                        BilledAmount = employee.BilledAmount,
                        AddedClients = employee.AddedClients,


                    };

                    usersCsv.Add(userCsv);
                }

                // Escribe los datos de los usuarios en el archivo CSV
                using (var writer = new StreamWriter(saveFileDialog.FileName, true))
                using (var csv = new CsvWriter(writer, System.Globalization.CultureInfo.CurrentCulture))
                {
                    csv.WriteRecords(usersCsv);
                    csv.NextRecord();
                }

                MessageBox.Show("Se ha Exportado Correctamente");


            }
            hideSudmenu();
            UsersLoad();
        }
        public sealed class UserMap : ClassMap<Employee>
        {
            public UserMap()
            {

                Map(p => p.Id).Index(0);
                Map(p => p.Name).Index(1);
                Map(p => p.LastName).Index(2);
                Map(p => p.Phone).Index(3);
                Map(p => p.Address).Index(4);
                Map(p => p.Enabled).Index(5);
                Map(p => p.User).Index(6);
                Map(p => p.Password).Index(7);
                Map(p => p.ActiveSession).Index(8);
                Map(p => p.BilledAmount).Index(9);
                Map(p => p.ConcludedSales).Index(10);
                Map(p => p.AddedClients).Index(11);


            }
        }
        private void btnImport_Click(object sender, EventArgs e)
        {

            //Pedir al usuario donde quiere importar el archivo csv 
            var openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "CSV files (*.csv)|*.csv";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                //Modificar las caracteristicas del csvhelper para que no produzca un error
                var config = new CsvConfiguration(CultureInfo.InvariantCulture)
                {
                    Delimiter = ";",                //La separacion
                    NewLine = Environment.NewLine,  //que realice saltos de linea
                    HeaderValidated = null,         //que ignore el encabezado ya que tenemos una clase que mapea (Mas arriba esta)
                    MissingFieldFound = null        //ignore los espacios vacios
                };
                List<Employee> records;
                //leer el csv para meterlo en una lista
                using (var reader = new StreamReader(openFileDialog.FileName))
                using (var csv = new CsvReader(reader, config))
                {

                    csv.Context.RegisterClassMap<UserMap>();
                    records = csv.GetRecords<Employee>().ToList();
                }
                //se crea una lista para el json
                List<Employee> Employees;
                if (!File.Exists(_pathusers))
                {
                    File.Create(_pathusers).Close();
                }
                using (var jsonReader = new JsonTextReader(new StringReader(File.ReadAllText(_pathusers))))
                {
                    var serializer = new JsonSerializer();
                    Employees = serializer.Deserialize<List<Employee>>(jsonReader);
                }

                // Agrega los registros recién importados de CSV a la lista
                Employees.AddRange(records);

                // Serializa la lista de nuevo en formato JSON y escribirla en el archivo
                string json = JsonConvert.SerializeObject(Employees);
                File.WriteAllText(_pathusers, json);

                MessageBox.Show("Importación completada con éxito.");              // no le paren a esto

                ////Metodo para la asignacion de las ID para que no se repitan
                using (var jsonReader1 = new JsonTextReader(new StringReader(File.ReadAllText(_pathusers))))
                {
                    var serializer = new JsonSerializer();
                    var userList = serializer.Deserialize<List<Employee>>(jsonReader1);
                    var originalUserList = new List<Employee>(userList); // Hace una copia de la lista original
                    List<long> checkid = new List<long>();//lista para meter los usuarios con cedula repetida

                    foreach (Employee user in userList)
                    {
                        if (!checkid.Contains(user.Id))
                        {
                            int count = 0;
                            foreach (Employee user1 in userList)
                            {
                                if (user.Id == user1.Id)
                                {
                                    count++;
                                }
                            }
                            if (count >= 2)
                            {
                                MessageBox.Show("Dos Usuario Tienen La Cedula Repetida, Por Favor Compruebe los datos del usuario importado");
                            }

                            checkid.Add(user.Id); // agregar la identificación verificada a la lista
                        }

                    }


                    using (var jsonWriter = new JsonTextWriter(new StreamWriter(_pathusers)))
                    {
                        serializer.Serialize(jsonWriter, originalUserList); // Escribe la lista original en el archivo original porque estaba invertida
                    }
                }
            }



            hideSudmenu();
            UsersLoad();
        }

        private void tbSearchUser_MouseClick(object sender, MouseEventArgs e)
        {
            tbSearchUser.Text = "";
        }

        private void btnChangeToAdmins_Click(object sender, EventArgs e)
        {
            AdminsLoad();
            btnChangeToAdmins.Visible = false;
            btnChangeToUsers.Visible = true;
            tbSearchAdmin.Visible = true;
            tbSearchUser.Visible = false;
            dtgvAdmins.Visible = true;
            dtgvUsers.Visible = false;
            modifyadmin = true;
            btnAddUser.Text = "Agregar Admin";

        }
        public void AdminsLoad(string searchText="")
        {
            dtgvAdmins.Rows.Clear();
            var adminsfromfile = GetAdminsFromFile();//Aplica el metodo antes mencionado
            var admins = JsonConvert.DeserializeObject<List<Admin>>(adminsfromfile);
            

            usersshowed = (pagecount * 5) + 5;
            if (admins != null)
            {
                IEnumerable<Admin> adminslist = admins.Where(admin => admin.Enabled == true).Skip(pagecount * 20).Take(20);
                foreach (Admin admin in adminslist)
                {
                    if (admin.Enabled == true)
                    {
                        dtgvAdmins.Rows.Add(admin.Name, admin.LastName, admin.Id, admin.Phone, admin.Address, admin.User, admin.Password);

                    }
                }
            }
            if (searchText.Length > 2)
            {

                admins = admins.Where(x => x.Name.Contains(searchText)).ToList();

            }
        }
        private void SearchAdmin_TextChanged(object sender, EventArgs e)
        {
            string searchText = tbSearchAdmin.Text.ToLower();

            int columnIndex = dtgvAdmins.Columns["UsersName"].Index;

            try
            {

                AdminsLoad(searchText);

                if (searchText.Length < 2)
                {
                    return;
                }

                foreach (DataGridViewRow row in dtgvAdmins.Rows)
                {

                    bool found = false;

                    DataGridViewCell cell = row.Cells[columnIndex];



                    if (cell.Value != null && cell.Value.ToString().ToLower().Contains(searchText))
                    {
                        found = true;
                    }
                    row.Visible = found;
                }
            }
            catch (Exception a)
            {

            }
        }

        private void btnChangeToUsers_Click(object sender, EventArgs e)
        {
            UsersLoad();
            btnChangeToAdmins.Visible = true;
            btnChangeToUsers.Visible = false;
            tbSearchAdmin.Visible = false;
            tbSearchUser.Visible = true;
            dtgvAdmins.Visible = false;
            dtgvUsers.Visible = true;
            modifyadmin = false;
            btnAddUser.Text = "Agregar Usuario";
        }

        private void dtgvAdmins_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            var adminsfromfile = GetAdminsFromFile();//Aplica el metodo antes mencionado
            var admins = JsonConvert.DeserializeObject<List<Admin>>(adminsfromfile);
            if (e.ColumnIndex == 7)
            {
               Admin tomodify = new Admin();
                long idtocompare = (long)dtgvAdmins.Rows[e.RowIndex].Cells[2].Value;

                foreach (Admin admin in admins)
                {
                    if (idtocompare == admin.Id)
                    {
                        tomodify = admin;
                        break;
                    }
                }
                Employee usernull = new Employee();
                ModifyUsers modifyadmin = new ModifyUsers(tomodify, usernull);
                modifyadmin.ShowDialog();
            }
            if (e.ColumnIndex == 8)
            {

                string username = dtgvAdmins.Rows[e.RowIndex].Cells[0].Value.ToString() + " " + dtgvAdmins.Rows[e.RowIndex].Cells[1].Value.ToString();
                DialogResult result1 = MessageBox.Show($"¿Esta seguro que desea eliminar {username}?", "Confirmación", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result1 == DialogResult.Yes)
                {
                    int n = e.RowIndex;

                    long todelete;

                    todelete = (long)dtgvAdmins.Rows[n].Cells[2].Value;

                    foreach (Admin admin in admins)
                    {
                        if (todelete == admin.Id)
                        {
                            admin.Enabled = false;
                            break;
                        }
                    }

                    string adminsJson = JsonConvert.SerializeObject(admins.ToArray(), Formatting.Indented);//Serializa el objeto en forma de users(Una lista) y lo guarda en la variable
                    File.WriteAllText(_pathadmin, adminsJson);
                    MessageBox.Show("El Administrador ha sido eliminado exitosamente");
                   AdminsLoad();
                }
            }
        }

        List<Employee> OrdenarLista(string campo)
        {

            var usersFromFile = GetUsersFromFile();
            var users = JsonConvert.DeserializeObject<List<Employee>>(usersFromFile);


            switch (campo)
            {
                case "Nombre":
                    return users.OrderBy(p => p.Name).ToList();
                case "Cedula":
                    return users.OrderBy(p => p.Id).ToList();
                default:
                    return users;
            }
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtgvUsers.Rows.Clear();

            string campo = comboBox1.SelectedItem.ToString();

            List<Employee> orderedusers = OrdenarLista(campo);

            if (orderedusers != null)
            {
                foreach (Employee user in orderedusers)
                {
                    if (user.Enabled == true)
                    {

                        dtgvUsers.Rows.Add(user.Name, user.LastName, user.Id, user.Phone, user.Address, user.User, user.Password);
                         

                    }
                }


            }

        }
    }
}
