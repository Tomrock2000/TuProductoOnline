﻿using CsvHelper.Configuration.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TuProductoOnline
{
    internal class UsersCSV
    {
        //Esta clase ayuda al momento de exportar ya que le indica al programa como 
        //escribir el CSV de salida.
        //Cado uno hace referecia a la estrutura de nuestra clase users 
        [Name("ID")]
        public long Id { get; set; }

        [Name("Nombre")]
        public string Name { get; set; }

        [Name("Apellido")]
        public string LastName { get; set; }

        [Name("Telefono")]
        public long Phone { get; set; }

        [Name("Direccion")]
        public string Address { get; set; }

        [Name("Activo")]
        public bool Enabled { get; set; }

        [Name("Usuario")]
        public string User { get; set; }

        [Name("Clave")]
        public long Password { get; set; }

        [Name("SeccionActiva")]

        public bool ActiveSession { get; set; }


        [Name("IngresoDelMes")]
        public float BilledAmount { get; set; }

        [Name("NumeroDeVentas")]

        public int ConcludedSales { get; set; }

        [Name("Clientes Agregados")]
        public int AddedClients { get; set; }
    }
}
